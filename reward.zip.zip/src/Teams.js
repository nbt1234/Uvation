import React from 'react'
import * as microsoftTeams from "@microsoft/teams-js";
import { app } from '@microsoft/teams-js';
export const Teams = () => {
    return (<>
        {/* <app
        /> */}
        <div>Teams</div></>
    )
}
