/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { LogLevel } from "@azure/msal-browser";

/**
 * Enter here the user flows and custom policies for your B2C application
 * To learn more about user flows, visit: https://docs.microsoft.com/en-us/azure/active-directory-b2c/user-flow-overview
 * To learn more about custom policies, visit: https://docs.microsoft.com/en-us/azure/active-directory-b2c/custom-policy-overview
 */

export const b2cPolicies = {
  names: {
    // signUpSignIn: "B2C_1A_DEMO1_PROGRESSIVE_PROFILING_SIGNUP_SIGNIN",
    signUpSignIn: " B2C_1A_DEMO1_PROGRESSIVE_SIGNUP_SIGNIN_REFERRAL",
    forgotPassword: "B2C_1A_DEMO1_PASSWORD_RESET",
    deactivate: "B2C_1A_DELETE_MY_ACCOUNT",
    changePassword: "B2C_1A_DEMO1_CHANGE_PASSWORD",
    editmfanumber: "B2C_1A_DEMO1_PROFILEEDIT_MFAPHONENUMBER",
    profileUpdate: "B2C_1A_DEMO1_PROFILEEDIT_ALLUSERDATA",
  },
  authorities: {
    signUpSignIn: {
      authority:
        // "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROGRESSIVE_PROFILING_SIGNUP_SIGNIN",
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROGRESSIVE_SIGNUP_SIGNIN_REFERRAL",
    },
    forgotPassword: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PASSWORD_RESET",
    },
    changePassword: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_CHANGE_PASSWORD",
    },
    profileUpdate: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROFILEEDIT_ALLUSERDATA",
    },
    deactivate: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_DELETE_MY_ACCOUNT",
    },

    editmfanumber: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROFILEEDIT_MFAPHONENUMBER",
    },
  },
  authorityDomain: "uvationidp.b2clogin.com",
};

/**
 * Configuration object to be passed to MSAL instance on creation.
 * For a full list of MSAL.js configuration parameters, visit:
 * https://github.com/AzureAD/microsoft-authentication-library-for-js/blob/dev/lib/msal-browser/docs/configuration.md
 */

export const msalConfig = {
  auth: {
    clientId: "70047577-a5d1-4487-b960-8d3abbf2d5e0", // This is the ONLY mandatory field that you need to supply.
    // clientSecretId: "-kf7Q~ZG4B_UddCaCCdlei4nmFNgZBovtn7WD",
    authority: b2cPolicies.authorities.signUpSignIn.authority, // Use a sign-up/sign-in user-flow as a default authority
    knownAuthorities: [b2cPolicies.authorityDomain], // Mark your B2C tenant's domain as trusted.
    redirectUri: window.location.origin, // Points to window.location.origin. You must register this URI on Azure Portal/App Registration.
    postLogoutRedirectUri:
      "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/b2c_1a_demo1_progressive_signup_signin_referral/oauth2/v2.0/logout?post_logout_redirect_uri=https://rewards.uvation.com/", // Indicates the page to navigate after logout.
    navigateToLoginRequestUrl: true, // If "true", will navigate back to the original request location before processing the auth code response.
  },
  cache: {
    cacheLocation: "sessionStorage", // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
    storeAuthStateInCookie: true, // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            return;
          case LogLevel.Info:
            return;
          case LogLevel.Verbose:
            return;
          case LogLevel.Warning:
            return;
        }
      },
    },
  },
};

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit:
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */

export const loginRequest = {
  scopes: [
    "openid",
    "profile",
    "offline_access",
    "https://uvationidp.onmicrosoft.com/tasks-api/tasks.write",
  ],
};

// export const options = {
//   loginType: LoginType.Redirect,
//   tokenRefreshUri: window.location.origin + "/auth.html",
// };

/**
 * An optional silentRequest object can be used to achieve silent SSO
 * between applications by providing a "login_hint" property.
 */

export const silentRequest = {
  scopes: ["openid", "profile", "offline_access"],
  loginHint: "example@domain.net",
};

export const protectedResources = {
  apiHello: {
    endpoint: "https://appsapi.uvation.com:8080/identity/hello",
    scopes: ["https://uvationidp.onmicrosoft.com/tasks-api/tasks.read"], // e.g. api://xxxxxx/access_as_user
  },
};
