import React from "react";
import ReactDOM from "react-dom";
import {
  EventType,
  InteractionType,
  PublicClientApplication,
} from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { b2cPolicies, msalConfig } from "./authConfig";
import App from "./App.js";
import { Provider } from "react-redux";
import ChatStore from "../src/stores/chatStore";
import "./index.scss";
import { GlobalContext, GlobalProvider } from "../src/ContexApi/GlobalContext";

const msalInstance = new PublicClientApplication(msalConfig);
ReactDOM.render(
  <React.StrictMode>
    <MsalProvider instance={msalInstance}>
      <Provider store={ChatStore}>
        <GlobalProvider>
          <App />
        </GlobalProvider>
      </Provider>
    </MsalProvider>
  </React.StrictMode>,
    document.getElementById("root")
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals

