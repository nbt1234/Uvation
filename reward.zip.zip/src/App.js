import React, { useState, useEffect, useContext } from "react";

import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal,
  useIsAuthenticated,
  useMsalAuthentication,
} from "@azure/msal-react";
import {
  EventType,
  InteractionStatus,
  InteractionType,
} from "@azure/msal-browser";
import { b2cPolicies, loginRequest, silentRequest } from "./authConfig";
import "./App.scss";
import { GlobalContext, GlobalProvider } from "../src/ContexApi/GlobalContext";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Teams } from "./Teams";
import { Loading } from "carbon-components-react";
import { Home } from "./Components/Home/Home";
import { msalConfig } from "./authConfig";
import { io } from "socket.io-client";
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getMessaging, getToken, onMessage } from "firebase/messaging";

function App() {
  const { instance, inProgress, accounts } = useMsal();
  const { login, result, error } = useMsalAuthentication();
  const isAuthenticated = useIsAuthenticated();
  const { userInfo, setuserInfo, socketdata } = useContext(GlobalContext);
  const [IsLogin, setIsLogin] = useState(true);
  useEffect(() => {
    if (error) {
      if (
        error.errorMessage &&
        error.errorMessage.indexOf("AADB2C90118") > -1
      ) {
        instance
          .loginRedirect(b2cPolicies.authorities.forgotPassword)
          .then(() => {
            window.alert(
              "Password has been reset successfully. \nPlease sign-in with your new password."
            );
          });
      } else if (
        error.errorMessage &&
        error.errorMessage.indexOf("AADB2C90091") > -1
      ) {
        instance.loginRedirect(loginRequest);
      }
    } else {
      if (!isAuthenticated && inProgress === InteractionStatus.None) {
        instance.loginRedirect(loginRequest);
      } else if (isAuthenticated && accounts) {
        instance.acquireTokenSilent({
          ...silentRequest,
          account: accounts,
        });
        // setuserInfo({
        //   ...userInfo,
        //   userid: accounts[0].localAccountId,
        //   email: accounts[0].username,
        //   fullname: accounts[0].name,
        // });
      }
    }
  }, [isAuthenticated, inProgress, instance]);
  socketdata?.on("logoutfromcurrentsite", () => {
    instance.logoutRedirect(msalConfig.auth.postLogoutRedirectUri);
  });
  const firebaseConfig = {
    apiKey: "AIzaSyB7iPfmtbLKYtUJkqpiM1pUwO8ylJ9v3x8",
    authDomain: "test-7ee7d.firebaseapp.com",
    projectId: "test-7ee7d",
    storageBucket: "test-7ee7d.appspot.com",
    messagingSenderId: "710152431651",
    appId: "1:710152431651:web:ffa056b10e31e2dcc06996",
    measurementId: "G-F9ZJ9FQ1QZ",
  };
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
  const messaging = getMessaging(app);

  useEffect(() => {
    getToken(messaging, {
      vapidKey:
        "BDZ82di-xS1O1kApecoWhmOvFFR5s3Ay82VXxj3JcSOC8CX92LPvs0wv31EDhMSj59yUCiRbffT7m4AieWotWLA",
    })
      .then((currentToken) => {
        if (currentToken) {
          localStorage.setItem("notification_token", currentToken);
          // axios
          //   .get(
          //     `http://localhost:8000/api/all_notification?currentoken=${currentToken}`
          //   )
          //   .then((res) => {});
        } else {
          // Show permission request UI
          console.log(
            "No registration token available. Request permission to generate one."
          );
          // ...
        }
      })
      .catch((err) => {
        console.log("An error occurred while retrieving token. ", err);
        // ...
      });
  }, []);

  return (
    <>
      <AuthenticatedTemplate>
        <Router>
          <Switch>
            <Route exact path="/" component={Home} />
            <Route exact path="/Teams" component={Teams} />
          </Switch>
        </Router>
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <Loading active withOverlay />
      </UnauthenticatedTemplate>
    </>
  );
}

export default App;
