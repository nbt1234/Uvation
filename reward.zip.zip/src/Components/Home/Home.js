import { Button } from "carbon-components-react";
import React from "react";
import UiHeader from "../Header/UiHeader";
import { useMsal } from "@azure/msal-react";
import { b2cPolicies } from "../../authConfig";
export const Home = () => {
  const { instance, accounts, inProgress } = useMsal();

  return (
    <div>
      <UiHeader />
      <div className="clear"></div>
      <div className="home_data">
        <div className="comming_div">
          <h1>Coming Soon...</h1>
        </div>
      </div>
    </div>
  );
};
