import { Header } from "carbon-components-react";
import React from "react";
import { Link } from "react-router-dom";
import Logo from ".../../../src/img/logo.png";

const MainHeader = () => {

  return (
    <div className="header">
      <Header aria-label="Header">
        <div className="logo">
          <Link to="/">
            <img src={Logo} alt="" />
            <p>Uvation rewards</p>
          </Link>
        </div>
      </Header>
    </div>
  );
};

export default MainHeader;
