import React, { useState, useContext } from "react";
//import Pagination from "react-js-pagination";
import axios from "axios";
import {
  Tabs,
  Tab,
  FormGroup,
  TextInput,
  TextArea,
  Dropdown,
  RadioButtonGroup,
  RadioButton,
  Button,
  FileUploader,
  ContentSwitcher,
  Switch,
  Loading,
  DatePicker,
  DatePickerInput,
  TimePicker,
  ProgressStep,
  ProgressIndicator,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  TableToolbarSearch,
  ButtonSet,
  DataTable,
  TableContainer,
  TableToolbar,
  TableToolbarContent,
  Pagination,
} from "carbon-components-react";
import {
  Help24,
  Chat24,
  Headset24,
  RequestQuote24,
  Launch16,
  Phone32,
  MobileAudio32,
} from "@carbon/icons-react";
import timezonesJson from "timezones.json";
import moment from "moment";
import { countrycode, SeverityList, ServiceList } from "../../Data/DataJson";
import "carbon-components/css/carbon-components.min.css";
import { GlobalContext } from "../../../ContexApi/GlobalContext";
import Widget from "../../Chat-btn/Widget";
import { Link, useHistory } from "react-router-dom";
import { AlphaSenderContext } from "twilio/lib/rest/messaging/v1/service/alphaSender";
let ticketUrl = "https://support.uvation.com";
let backend_url = "https://appsapi.uvation.com:8080";
//var backend_url =  "http://7143-2405-201-5c14-c81b-6dd3-3caf-b123-bf5.ngrok.io/";

const SupportHelp = () => {
  const TWILIO_PHONE_NUMBER = process.env.REACT_APP_TWILIO_PHONE_NUMBER;
  const AUTH_TOKEN = process.env.REACT_APP_AUTH_TOKEN;
  const ACCOUNT_SID = process.env.REACT_APP_ACCOUNT_SID;
  const ZEN_AUTH_TOKEN = process.env.REACT_APP_ZEN_AUTH_TOKEN;
  const history = useHistory();

  const [attachmentToken, setattachmentToken] = useState("");

  const {
    headers,
    account,
    toggle,
    setloadingnotification,
    AlldataWidget,
    TablePagination,
    setTablePagination,
    setAlldataWidget,
    userInfo,
    updatesdetail,
    settoggle,
  } = useContext(GlobalContext);
  const [Data, setData] = useState({
    loading: "",
    loadingCall: false,
    Subject: "",
    Description: "",
    switchValue: "",
    phone: "",
    postalCode: "+1",
    chooseService: "",
    servity: "",
    conframEmail: "",
    contactMethod: "",
    timeZone: "",
    ScheduleDate: "",
    ScheduleTime: "",
    attachFile: "",
    call: "",
  });
  const usernotification_token = localStorage.getItem("notification_token");

  const [resdata, setresdata] = useState([
    {
      id: "",
      timezone: "",
      status: "",
    },
  ]);

  const handleChange = (e) => {
    const value = e.target.value;
    setData({
      ...Data,
      [e.target.name]: value,
    });
  };

  // add twilio calling functionality

  const makeCall = async (e) => {
    e.preventDefault();
    setData({ ...Data, loadingCall: true });
    const token = Buffer.from(`${ACCOUNT_SID}:${AUTH_TOKEN}`, "utf8").toString(
      "base64"
    );

    const fd = new FormData();
    fd.append("From", TWILIO_PHONE_NUMBER);
    fd.append("To", `${Data.postalCode + Data.call}`);
    fd.append("Url", "http://demo.twilio.com/docs/voice.xml");

    await axios
      .post(`${backend_url}/identity/support_call`, fd, {
        headers: {
          "Content-Type": "",
          authorization: `Basic ${token}`,
        },
      })
      .then((response) => {
        // console.log('--response');
        // console.log(response.data.status);
        response.data.status === "success" &&
          setTimeout(() => {
            setData({ ...Data, loadingCall: false });
            document.getElementById("test17").value = "";
          }, 10000);
      });
  };
  const usernameinfo = "zendesk_admin@uvation.com";
  const passwordinfo = "H9dh0DH72gF";

  function attachmentFile(e) {
    if (e) {
      const file = e.target.files[0];
      axios
        .post(
          `https://uvation.zendesk.com/api/v2/uploads?filename=${file.name}`,
          file,
          {
            headers: {
              "Content-Type": "application/binary",
              Authorization: "Basic " + btoa(`${usernameinfo}:${passwordinfo}`),
            },
          }
        )
        .then((res) => {
          setattachmentToken(res.data.upload.token);
        })
        .catch((err) => console.log(err));
    }
  }
  // Handle ticket form data

  const handleSubmit = async (e) => {
    e.preventDefault();
    setData({
      ...Data,
      loading: true,
    });
    const body = {
      ticket: {
        subject: Data.Subject,
        comment: { body: Data.Description, uploads: [`${attachmentToken}`] },
        requester: {
          name: userInfo.fullname.split(" ")[0],
          email: userInfo.email,
        },
        custom_fields: [
          // {
          //   id: 360019118233,
          //   value: "nbt1",
          // },
          {
            id: 360007343594,
            value: userInfo.fullname,
          },
          {
            id: 360029033513,
            value: Data.ScheduleTime,
          },
          {
            id: 360007135793,
            value: Data.postalCode + Data.phone,
          },
          {
            id: 360007135813,
            value: Data.chooseService,
          },
          {
            id: 360029045834,
            value: Data.timeZone,
          },
          {
            id: 360028569473,
            value: Data.contactMethod,
          },
          {
            id: 360029045634,
            value: Data.ScheduleDate,
          },
          {
            id: 360028555173,
            value: Data.servity,
          },
          {
            id: 360029033673,
            value: userInfo.email,
          },
        ],
        ticket_form_id: Data.switchValue,
      },
    };
    const headers = {
      "access-control-allow-origin": "*",
      Authorization: "Basic " + btoa(`${usernameinfo}:${passwordinfo}`),
    };

    const bodydata = new FormData();
    bodydata.append("body", JSON.stringify(body));
    axios
      .post("https://appsapi.uvation.com:8080/identity/create_ticket", bodydata)
      .then((res) => {
        if (res.status == 200) {
          axios
            .post(
              "https://notifications.uvation.com:443/api/action_notification",
              {
                userid: account?.idTokenClaims?.sub,
                zendesk_id: res?.data?.audit?.ticket_id,

                zendesk_id_time: res?.data?.audit?.created_at,
                platform: "uvation reward",
                token: usernotification_token,
              }
            )
            .then((res) => {
              setloadingnotification(true);
            });
        }
        setresdata({
          id: res.data.ticket.id,
          timezone: res.data.ticket.created_at,
          status: res.data.ticket.status,
        });
        setData({
          ...Data,
          loading: false,
        });
      });
  };
  const [activePage, setActivePage] = useState(1);
  const [data, setdata] = useState();

  function handlePageChange(pageNumber) {
    const page = pageNumber.page;
    axios
      .post(`${backend_url}/identity/get_user_ticket`, {
        email: userInfo?.email,
        page_no: page,
        per_page: 9,
      })
      .then((response) => {
        response.data.status !== "failed" && setdata(response);
        setAlldataWidget(
          response.data.data.results.map((tic) => ({
            id: `${tic.id}`,
            datesubject: (
              <div>
                <p
                  style={{
                    fontSize: "14px",
                    lineHeight: "18px",
                    fontWeight: "600",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {tic.subject}
                </p>
                <p
                  style={{
                    width: "130px",
                    fontSize: "12px",
                    lineHeight: "15px",
                    fontWeight: "400",
                    overflow: "hidden",
                    textOverflow: "ellipsis",
                    whiteSpace: "nowrap",
                  }}
                >
                  {moment(tic.created_at).format("llll")}
                </p>
              </div>
            ),
          }))
        );
      });

    setActivePage(pageNumber);
  }
  // console.log("##############")
  // console.log(TablePagination?.totalrow )
  // const userticketparsing=(row)=>{
  //   history.push(`https://support.uvation.com/allticket/${row.id}`);
  // //
  //   location.reload()
  // }
  return (
    <div className="divfortabs">
      <Tabs className="tabs-div" selected={toggle.tabselect}>
        <Tab className="tab-div" href="#" id="tab-1" label={<Help24 />}>
          {Data.loading === false ? (
            <div>
              <div className="submit-ticket">
                <h2>Service request #{resdata.id}</h2>
                <div className="ticStatus">
                  <h5>{Data.Subject}</h5>
                  <p>open</p>
                </div>

                <p className="p_design">
                  Created by {userInfo.fullname} on{" "}
                  {moment(resdata.timeZone).format("LLLL")}
                </p>
                <div className="bx--col bx--no-gutter">
                  <ProgressIndicator
                    vertical
                    currentIndex={
                      resdata.status === "open"
                        ? 1
                        : 0 || resdata.status === "pending"
                        ? 2
                        : 0 || resdata.status === "closed"
                        ? 4
                        : 0
                    }
                  >
                    <ProgressStep
                      label="Service request opened"
                      description="Step 1: Getting started with Carbon Design System"
                      secondaryLabel={moment(resdata.timeZone).format("LLLL")}
                    />
                    <ProgressStep
                      label="Agent assigned"
                      description="Step 3: Getting started with Carbon Design System"
                    />
                    <ProgressStep
                      label="Issue resolved"
                      description="Step 4: Getting started with Carbon Design System"
                    />
                  </ProgressIndicator>
                </div>

                <div className="details">
                  <div className="line"></div>
                  <h5>Services request details</h5>
                  <div className="detail-item ">
                    <li>
                      <p>Name</p>
                    </li>
                    <li>
                      <p>{userInfo.fullname}</p>
                    </li>
                  </div>
                  <div className="detail-item ">
                    <li>
                      <p>Phone</p>
                    </li>
                    <li>
                      <p>{Data.postalCode + Data.phone}</p>
                    </li>
                  </div>

                  <div className="detail-item ">
                    <li>
                      <p>Email</p>
                    </li>
                    <li>
                      <p>{userInfo.email}</p>
                    </li>
                  </div>
                  <div className="detail-item ">
                    <li>
                      <p>Service</p>
                    </li>
                    <li>
                      <p>{Data.chooseService}</p>
                    </li>
                  </div>
                  <div className="detail-item ">
                    <li>
                      <p>Severity</p>
                    </li>
                    <li>
                      <p>{Data.servity}</p>
                    </li>
                  </div>
                  <div className="detail-item ">
                    <li>
                      <p>Timezone</p>
                    </li>
                    <li>
                      <p>{Data.timeZone}</p>
                    </li>
                  </div>
                  <ButtonSet stacked>
                    <Button
                      kind="primary"
                      as={Link}
                      to={`/ticketdetail/${resdata.id}`}
                      // target="_blank"
                      onClick={() => {
                        settoggle({
                          ...toggle,
                          Quick: false,
                          Support: false,
                          Notification: false,
                          Account: false,
                          tabselect: 0,
                          switcher: false,
                          viewSummary: false,
                        });
                        localStorage.setItem("ticidstore", resdata.id);
                      }}
                    >
                      View case page
                    </Button>
                    <Button
                      kind="tertiary"
                      onClick={() => setData({ loading: null })}
                    >
                      Open new ticket
                    </Button>
                  </ButtonSet>
                </div>
              </div>
            </div>
          ) : Data.loading === true ? (
            <div className="box-block">
              <Loading
                withOverlay={false}
                small
                style={{ width: "100px", height: "100px" }}
              />
            </div>
          ) : (
            <div className="support-tab-content">
              <div className="bx--telephone">
                <h2>Open new ticket</h2>
                <FormGroup legendText="">
                  <div className="Switcher">
                    <ContentSwitcher
                      selectionMode="manual"
                      onChange={(obj) => {
                        let { index, name, text, value } = obj;
                        setData({
                          ...Data,
                          switchValue: `${name}`,
                        });
                      }}
                    >
                      <Switch
                        name="360001970193"
                        text="Technical Request"
                        value="tech"
                      />
                      <Switch name="1500000007241" text="Customer Request" />
                    </ContentSwitcher>
                  </div>

                  <div className="spacing-inner">
                    <TextInput
                      id="test1"
                      invalidText="A valid value is required"
                      required
                      labelText="Subject*"
                      placeholder="Add a subject"
                      name="Subject"
                      onChange={handleChange}
                    />
                  </div>
                  <div className="spacing-inner">
                    <TextArea
                      cols={50}
                      id="test14"
                      invalidText="A valid value is required"
                      labelText="Description*"
                      placeholder="Describe your issue in detail"
                      rows={4}
                      name="Description"
                      onChange={handleChange}
                    />
                  </div>
                  <div className="spacing-inner">
                    <div className="bx--row" style={{ alignItems: "flex-end" }}>
                      <div className="bx--col-1 bx--no-gutter">
                        <Dropdown
                          label="+ 91 "
                          ariaLabel="Dropdown"
                          id="carbon-dropdown-example"
                          value="+1"
                          items={countrycode}
                          itemToElement={(countrycode) =>
                            countrycode ? (
                              <>
                                <span style={{ marginRight: "0.5rem" }}>
                                  {countrycode.dial_code}
                                </span>
                                <span>{countrycode.code}</span>
                              </>
                            ) : (
                              ""
                            )
                          }
                          titleText="Telephone*"
                          selectedItem={Data.postalCode}
                          onChange={({ selectedItem }) =>
                            setData({
                              ...Data,
                              postalCode: selectedItem.dial_code,
                            })
                          }
                        />
                      </div>
                      <div className="bx--col bx--no-gutter">
                        <TextInput
                          labelText=""
                          id="test323"
                          invalidText="A valid value is required"
                          placeholder="Enter your telephone number"
                          name="phone"
                          onChange={handleChange}
                        />
                      </div>
                    </div>
                  </div>

                  <div className="form-divider"></div>

                  <h2>Choose options</h2>

                  <div className="spacing-inner">
                    <Dropdown
                      id="drop-1"
                      ariaLabel="Dropdown"
                      items={ServiceList}
                      label="Choose a service...."
                      titleText="Choose service"
                      selectedItem={Data.chooseService}
                      onChange={({ selectedItem }) =>
                        setData({
                          ...Data,
                          chooseService: selectedItem.label,
                        })
                      }
                    />
                  </div>
                  <div className="spacing-inner">
                    <Dropdown
                      id="drop-2"
                      ariaLabel="Dropdown"
                      items={SeverityList}
                      label="Select a severity...."
                      titleText="Severity"
                      selectedItem={Data.servity}
                      onChange={({ selectedItem }) =>
                        setData({ ...Data, servity: selectedItem.label })
                      }
                    />
                  </div>
                  <div className="spacing-inner">
                    <TextInput
                      labelText={
                        <>
                          <legend>Confirm your email*</legend>
                          <legend style={{ fontSize: "11px" }}>
                            (use semicolons to separate multiple email
                            addresses)
                          </legend>
                        </>
                      }
                      id="test16"
                      invalidText="A valid value is required"
                      required
                      value={account?.idTokenClaims?.email}
                      placeholder="serbantudorvlad@gmail.com"
                      name="conframEmail"
                      onChange={handleChange}
                    />
                  </div>

                  <FormGroup legendText="Prefered contact method:">
                    <RadioButtonGroup
                      className="radio_btn"
                      orientation="vertical"
                      labelPosition="right"
                      legend="Group Legend"
                      name="radio-button-group"
                      valueSelected={Data.contactMethod}
                      onChange={(valueSelected) =>
                        setData({ ...Data, contactMethod: valueSelected })
                      }
                    >
                      <RadioButton
                        id="radio-1"
                        labelText="Phone"
                        value="Phone"
                      />
                      <RadioButton
                        id="radio-2"
                        labelText="Email"
                        value="Email"
                      />
                      <RadioButton
                        id="radio-3"
                        labelText="Schedule a call"
                        value="Callback"
                      />
                    </RadioButtonGroup>
                  </FormGroup>
                  <div
                    className="DateTimepicker"
                    style={{
                      display: Data.contactMethod === "Callback" ? "" : "none",
                    }}
                  >
                    <DatePicker
                      dateFormat="m/d/Y"
                      datePickerType="single"
                      id="date-picker"
                      locale="en"
                      short={true}
                    >
                      <DatePickerInput
                        className="some-class"
                        iconDescription="Date Calendar icon"
                        id="date-picker-input"
                        invalid={false}
                        invalidText="A valid due date is required"
                        labelText=""
                        pattern="\d{1,2}/\d{1,2}/\d{4}"
                        placeholder="mm/dd/yyyy"
                        type="date"
                        name="ScheduleDate"
                        value={Data.ScheduleDate}
                        valueSelected={Data.ScheduleDate}
                        onInput={(e) =>
                          setData({ ...Data, ScheduleDate: e.target.value })
                        }
                      ></DatePickerInput>
                    </DatePicker>
                    <TimePicker
                      labelText=""
                      id="time-picker"
                      placeholder="HH:MM"
                      type="time"
                      name="ScheduleTime"
                      onChange={handleChange}
                    />
                  </div>
                  <div className="spacing-inner">
                    <Dropdown
                      ariaLabel="Dropdown"
                      label="Select a time zone"
                      id="drop-3"
                      items={timezonesJson}
                      itemToElement={(timezonesJson) =>
                        timezonesJson ? timezonesJson.text : ""
                      }
                      titleText="Choose a new time zone"
                      selectedItem={Data.timeZone}
                      onChange={({ selectedItem }) =>
                        setData({ ...Data, timeZone: selectedItem.text })
                      }
                    />
                  </div>
                </FormGroup>

                <div className="form-divider"></div>
                <div className="div-row-center spacing-inner-second">
                  <div className="bx--col bx--no-gutter--left">
                    <h3>Attach files</h3>
                    <p>Files must be less than 5MB in size.</p>
                  </div>
                  <div className="bx--col bx--no-gutter">
                    <div className="bx--col bx--no-gutter">
                      <FileUploader
                        labelText="Attach File"
                        id="file-01"
                        buttonLabel="Attach File"
                        accept={[".jpg", ".png", ".jpeg"]}
                        buttonKind="tertiary"
                        size="field"
                        role="button"
                        disableLabelChanges={true}
                        filenameStatus={
                          attachmentToken !== "" ? "complete" : `uploading`
                        }
                        onChange={(e) => attachmentFile(e)}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="" style={{ marginTop: "4.5rem" }}>
                <Button
                  className="btnwidth"
                  onClick={handleSubmit}
                  kind="primary"
                >
                  Submit request
                </Button>
              </div>
            </div>
          )}
        </Tab>
        <Tab className="tab-div" href="#" id="tab-2" label={<Chat24 />}>
          <div className="support-tab-content">
            <div className="bx--telephone">
              <h2>Chat with an agent</h2>
              <p>
                Our Support staff is available 24/7/365 to assist you via chat
                with any services related questions.
              </p>
              <div className="box-block">
                <div className="column"></div>
              </div>
            </div>
            <Widget />
            <div className="btn-down"></div>
          </div>
        </Tab>
        <Tab className="tab-div" href="#" id="tab-3" label={<Headset24 />}>
          <div className="support-tab-content">
            <div className="bx--telephone">
              <h2>Talk with an agent</h2>
              <p>
                Our Support staff is available 24/7/365 to assist you via phone
                with any services related questions.
              </p>
              <div className="box-block">
                {Data.loadingCall ? (
                  <div class="call-animation">
                    <Phone32 fill="#fff" />
                  </div>
                ) : (
                  <div className="circle74">
                    <MobileAudio32 fill="#555" />
                  </div>
                )}
              </div>
              <div
                style={{
                  position: "absolute",
                  bottom: "2.5rem",
                  right: "1.5rem",
                  left: "1.5rem",
                }}
              >
                <div className="spacing-inner-one">
                  <p>Telephone*</p>
                </div>
                <div className="bx--row spacing-inner">
                  <div className="bx--col-1 bx--no-gutter">
                    <Dropdown
                      label="+ 00"
                      ariaLabel="Dropdown"
                      id="drop-4"
                      direction="top"
                      initialSelectedItem={countrycode[5]}
                      items={countrycode}
                      itemToElement={(countrycode) =>
                        countrycode ? (
                          <>
                            <span style={{ marginRight: "0.5rem" }}>
                              {countrycode.dial_code}
                            </span>
                            <span>{countrycode.code}</span>
                          </>
                        ) : (
                          ""
                        )
                      }
                      selectedItem={Data.postalCode}
                      onChange={({ selectedItem }) =>
                        setData({
                          ...Data,
                          postalCode: selectedItem.dial_code,
                        })
                      }
                    />
                  </div>
                  <div className="bx--col bx--no-gutter">
                    <TextInput
                      labelText=""
                      id="test17"
                      invalidText="A valid value is required"
                      placeholder="Enter your telephone number"
                      name="call"
                      onChange={handleChange}
                    />
                  </div>
                </div>
              </div>
            </div>
            <div className="btn-down">
              <Button className="btnwidth" kind="primary" onClick={makeCall}>
                Initiate a phone call
              </Button>
            </div>
          </div>
        </Tab>
        <Tab className="tab-div" href="#" id="tab-3" label={<RequestQuote24 />}>
          <div className="support-tab-content">
            <div className="bx--telephone">
              <h2>My requests</h2>
              <DataTable rows={AlldataWidget} headers={headerData} size="tall">
                {({
                  rows,
                  headers,
                  getHeaderProps,
                  getRowProps,
                  getTableProps,
                  onInputChange,
                }) => (
                  <TableContainer>
                    <TableToolbar>
                      <TableToolbarContent>
                        <TableToolbarSearch onChange={onInputChange} expanded />
                      </TableToolbarContent>
                    </TableToolbar>
                    <Table {...getTableProps()} useZebraStyles>
                      <TableHead>
                        <TableRow>
                          {headers.map((header) => (
                            <TableHeader
                              key={header.key}
                              {...getHeaderProps({ header })}
                            >
                              {header.header}
                            </TableHeader>
                          ))}
                          <TableHeader />
                        </TableRow>
                      </TableHead>
                      <TableBody>
                        {rows.map((row) => (
                          <TableRow key={row.id} {...getRowProps({ row })}>
                            {row.cells.map((cell) => (
                              <TableCell key={cell.id}>{cell.value}</TableCell>
                            ))}
                            <TableCell className="bx--table-column-menu">
                              <div
                                style={{
                                  paddingTop: "1rem",
                                }}
                                // onClick={()=>userticketparsing(row)}
                              >
                                {/* <a target="_blank"
                                  href={`https://support.uvation.com/support/ticketdetail/${row.id}`}
                                  onClick={(e) =>
                                    localStorage.setItem("ticidstore", row.id)
                                  }
                                > */}
                                <Link
                                  to={"/"}
                                  onClick={() => {
                                    settoggle({
                                      ...toggle,

                                      tabselect: 3,
                                    });
                                  }}
                                >
                                  <Launch16 />
                                </Link>
                                {/* </a> */}
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </TableContainer>
                )}
              </DataTable>
            </div>
            <div className="pagination-set">
              {/* <div className="row text-center PaginationRow">
                    <Pagination
                    activePage={activePage}
                    itemsCountPerPage={10}
                    totalItemsCount={50}
                    pageRangeDisplayed={5}
                    onChange={handlePageChange}
                    />
                </div> */}
              <div style={{ width: "100%" }}>
                <Pagination
                  backwardText="Previous page"
                  forwardText="Next page"
                  itemsPerPageText="Items per page:"
                  page={1}
                  pageNumberText="Page Number"
                  pageSize={10}
                  pageSizes={[10]}
                  totalItems={TablePagination?.totalrow}
                  onChange={handlePageChange}
                />
              </div>
            </div>
          </div>
        </Tab>
      </Tabs>
    </div>
  );
};

export default SupportHelp;

const headerData = [
  {
    header: "Request#",
    key: "id",
  },
  {
    header: "Subject/Date created",
    key: "datesubject",
  },
];
