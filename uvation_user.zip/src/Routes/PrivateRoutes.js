/* eslint-disable react/jsx-filename-extension */
import { lazy } from 'react';
import {
  DASHBOARD,
  CHARITY,
  GET_FREE_GIFT_CARD,
  LOYALTY_DETAILS,
  MY_LOYALTY,
  MY_PROMOTIONS,
  MY_REDEMPTIONS,
  MY_REFERRALS,
  PROMOTION_DETAILS,
  REFERRAL_DETAILS,
  ROOT,
  MY_DONATIONS,
} from './Routes';

const Dashboard = lazy(() => import('../Containers/Dashboard/Dashboard'));
const PromotionDetails = lazy(() =>
  import('../Containers/PromotionDetails/PromotionDetails')
);
const MyPromotions = lazy(() =>
  import('../Containers/MyPromotions/MyPromotions')
);
const MyLoyalty = lazy(() => import('../Containers/MyLoyalty/MyLoyalty'));
const MyReferral = lazy(() => import('../Containers/MyReferral/MyReferral'));
const ReferralDetails = lazy(() =>
  import('../Containers/ReferralDetails/ReferralDetails')
);
const LoyaltyDetails = lazy(() =>
  import('../Containers/LoyaltyDetails/LoyaltyDetails')
);
const DefaultRoute = lazy(() => import('./DefaultRoute'));
const GetFreeGiftCard = lazy(() =>
  import('../Components/GetFreeGiftCard/GetFreeGiftCard')
);
const MyRedemptions = lazy(() =>
  import('../Containers/MyRedemptions/MyRedemptions')
);
const MyDonations = lazy(() => import('../Containers/MyDonations/MyDonations'));
const Charity = lazy(() => import('../Containers/Charity/Charity'));

export const privateRoutes = [
  {
    id: 1,
    path: ROOT,
    component: <DefaultRoute />,
  },
  {
    id: 2,
    path: DASHBOARD,
    component: <Dashboard />,
  },
  { id: 3, path: MY_PROMOTIONS, component: <MyPromotions /> },
  {
    id: 4,
    path: MY_LOYALTY,
    component: <MyLoyalty />,
  },
  {
    id: 5,
    path: MY_REFERRALS,
    component: <MyReferral />,
  },
  {
    id: 6,
    path: PROMOTION_DETAILS,
    component: <PromotionDetails />,
  },
  {
    id: 7,
    path: LOYALTY_DETAILS,
    component: <LoyaltyDetails />,
  },
  { id: 8, path: REFERRAL_DETAILS, component: <ReferralDetails /> },
  { id: 9, path: GET_FREE_GIFT_CARD, component: <GetFreeGiftCard /> },
  { id: 10, path: MY_REDEMPTIONS, component: <MyRedemptions /> },
  { id: 11, path: MY_DONATIONS, component: <MyDonations /> },
  { id: 12, path: CHARITY, component: <Charity /> },
];
