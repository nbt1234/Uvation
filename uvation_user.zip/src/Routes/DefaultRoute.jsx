import { Navigate } from 'react-router-dom';

import { DASHBOARD } from './Routes';

const DefaultRoute = () => {
  return <Navigate to={DASHBOARD} />;
};

export default DefaultRoute;
