import axiosInstance from '../../API/axiosInstance';
import { GET_ADMIN_CONFIG } from '../../Constants/apiEndpoints';

const GetAdminConfig = async () => {
  try {
    const response = await axiosInstance.get(GET_ADMIN_CONFIG);
    const requiredRes = {
      myLoyaltyPageNewCustomerMessage:
        response?.data?.data?.myLoyaltyPageNewCustomerMessage,
      myPromotionPageNewCustomerMessage:
        response?.data?.data?.myPromotionPageNewCustomerMessage,
      myReferralsPageNewCustomerMessage:
        response?.data?.data?.myReferralsPageNewCustomerMessage,
      referrerLoyaltyPoints: response?.data?.data?.referrerLoyaltyPoints,
    };
    return requiredRes;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const GetAdminConfigService = { GetAdminConfig };

export default GetAdminConfigService;
