import { UvationAPI } from '../../API/axios';
import { GENERATE_TOKEN_API } from '../../Constants/apiEndpoints';

const loginUser = async (data) => {
  try {
    const response = await UvationAPI.put(
      `${GENERATE_TOKEN_API}?azureId=${data?.azureId}`
    );
    return response?.data?.data;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const SingleSignOnService = { loginUser };

export default SingleSignOnService;
