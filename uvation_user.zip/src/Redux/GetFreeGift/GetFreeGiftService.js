import axiosInstance from '../../API/axiosInstance';
import { LOYALTY_FREE_ITEM_API } from '../../Constants/apiEndpoints';
import { getQsValues } from '../../Constants/getQsValues';

const getFreeGiftsList = async (data) => {
  try {
    const newQsValue = getQsValues(data);
    const response = await axiosInstance.get(
      `${LOYALTY_FREE_ITEM_API}?${newQsValue}`
    );
    return response?.data?.data;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const GetFreeGiftService = { getFreeGiftsList };

export default GetFreeGiftService;
