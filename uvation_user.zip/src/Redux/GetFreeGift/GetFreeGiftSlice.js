import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

import getFreeGiftService from './GetFreeGiftService';

const initialState = {
  getFreeGiftsListData: {
    isLoading: false,
    isSuccess: false,
    isError: false,
    data: null,
    message: '',
  },
};

export const getFreeGiftsList = createAsyncThunk(
  'getFreeGift/list',
  async (data, thunkAPI) => {
    try {
      return await getFreeGiftService.getFreeGiftsList(data);
    } catch (error) {
      const message = JSON.parse(error?.message)?.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const GetFreeGiftSlice = createSlice({
  name: 'getFreeGift',
  initialState,
  reducers: {
    resetDetail: (state) => {
      state.getFreeGiftsListData.isLoading = false;
      state.getFreeGiftsListData.isError = false;
      state.getFreeGiftsListData.isSuccess = false;
      state.getFreeGiftsListData.data = null;
      state.getFreeGiftsListData.message = '';
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getFreeGiftsList.pending, (state) => {
        state.getFreeGiftsListData.isLoading = true;
        state.getFreeGiftsListData.isError = false;
        state.getFreeGiftsListData.isSuccess = false;
        state.getFreeGiftsListData.data = null;
        state.getFreeGiftsListData.message = '';
      })
      .addCase(getFreeGiftsList.rejected, (state, action) => {
        state.getFreeGiftsListData.isLoading = false;
        state.getFreeGiftsListData.isError = true;
        state.getFreeGiftsListData.isSuccess = false;
        state.getFreeGiftsListData.data = null;
        state.getFreeGiftsListData.message = action.payload;
      })
      .addCase(getFreeGiftsList.fulfilled, (state, action) => {
        state.getFreeGiftsListData.isLoading = false;
        state.getFreeGiftsListData.isError = false;
        state.getFreeGiftsListData.isSuccess = true;
        state.getFreeGiftsListData.data = action.payload;
        state.getFreeGiftsListData.message = '';
      });
  },
});

export const { resetDetail } = GetFreeGiftSlice.actions;
export default GetFreeGiftSlice.reducer;
