import axiosInstance from '../../API/axiosInstance';
import { MY_LOYALTY_LIST_API } from '../../Constants/apiEndpoints';
import { getQsValues } from '../../Constants/getQsValues';

const getMyLoyaltyList = async (data) => {
  try {
    const newQsValue = getQsValues(data);
    const response = await axiosInstance.get(
      `${MY_LOYALTY_LIST_API}?${newQsValue}`
    );
    return response?.data?.data;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const MyLoyaltyService = { getMyLoyaltyList };

export default MyLoyaltyService;
