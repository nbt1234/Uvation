import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

import MyLoyaltyService from './MyLoyaltyService';

const initialState = {
  myLoyaltyListData: {
    isLoading: false,
    isSuccess: false,
    isError: false,
    data: null,
    message: '',
  },
};

export const getMyLoyaltyList = createAsyncThunk(
  'loyalty/list',
  async (data, thunkAPI) => {
    try {
      return await MyLoyaltyService.getMyLoyaltyList(data);
    } catch (error) {
      const message = JSON.parse(error?.message)?.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const MyLoyaltySlice = createSlice({
  name: 'loyalty',
  initialState,
  reducers: {
    resetDetail: (state) => {
      state.myLoyaltyListData.isLoading = false;
      state.myLoyaltyListData.isError = false;
      state.myLoyaltyListData.isSuccess = false;
      state.myLoyaltyListData.data = null;
      state.myLoyaltyListData.message = '';
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getMyLoyaltyList.pending, (state) => {
        state.myLoyaltyListData.isLoading = true;
        state.myLoyaltyListData.isError = false;
        state.myLoyaltyListData.isSuccess = false;
        state.myLoyaltyListData.data = null;
        state.myLoyaltyListData.message = '';
      })
      .addCase(getMyLoyaltyList.rejected, (state) => {
        state.myLoyaltyListData.isLoading = false;
        state.myLoyaltyListData.isError = true;
        state.myLoyaltyListData.isSuccess = false;
        state.myLoyaltyListData.data = null;
        state.myLoyaltyListData.message = '';
      })
      .addCase(getMyLoyaltyList.fulfilled, (state, action) => {
        state.myLoyaltyListData.isLoading = false;
        state.myLoyaltyListData.isError = false;
        state.myLoyaltyListData.isSuccess = true;
        state.myLoyaltyListData.data = action.payload;
        state.myLoyaltyListData.message = '';
      });
  },
});

export const { resetDetail } = MyLoyaltySlice.actions;
export default MyLoyaltySlice.reducer;
