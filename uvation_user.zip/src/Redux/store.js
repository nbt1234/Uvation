import { configureStore } from '@reduxjs/toolkit';

import myPromotionsReducer from './MyPromotions/MyPromotionsSlice';
import singleSignOnReducer from './SingleSignOn/SingleSignOnSlice';
import loyaltyReducer from './MyLoyalty/MyLoyaltySlice';
import GetFreeGiftReducer from './GetFreeGift/GetFreeGiftSlice';
import MyRedemptionReducer from './MyRedemption/MyRedemptionSlice';
import OrderCartReducer from './OrderCart/OrderCartSlice';
import MyDonationsReducer from './MyDonations/MyDonationsSlice';
import myReferralsReducer from './MyReferrals/MyReferralsSlice';
import GetAdminCongifReducer from './GetAdminConfig/GetAdminCongifSlice';

export const store = configureStore({
  reducer: {
    myPromotions: myPromotionsReducer,
    singleSignOn: singleSignOnReducer,
    myLoyalty: loyaltyReducer,
    getFreeGift: GetFreeGiftReducer,
    myRedemption: MyRedemptionReducer,
    orderCart: OrderCartReducer,
    myDonations: MyDonationsReducer,
    myReferrals: myReferralsReducer,
    getAdminConfig: GetAdminCongifReducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware({
      serializableCheck: false,
    }),
});
