import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

import MyDonationsService from './MyDonationsService';

const initialState = {
  myCharityListData: {
    isLoading: false,
    isSuccess: false,
    isError: false,
    data: null,
    message: '',
  },
  myDonationListData: {
    isLoading: false,
    isSuccess: false,
    isError: false,
    data: null,
    message: '',
  },
};

export const getMyCharityList = createAsyncThunk(
  'donation/charity-list',
  async (data, thunkAPI) => {
    try {
      return await MyDonationsService.getMyCharityList(data);
    } catch (error) {
      const message = JSON.parse(error?.message)?.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const getMyDonationsList = createAsyncThunk(
  'donation/list',
  async (data, thunkAPI) => {
    try {
      return await MyDonationsService.getMyDonationsList(data);
    } catch (error) {
      const message = JSON.parse(error?.message)?.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const MyDonationsSlice = createSlice({
  name: 'donation',
  initialState,
  reducers: {
    resetDetail: (state) => {
      state.myDonationListData.isLoading = false;
      state.myDonationListData.isError = false;
      state.myDonationListData.isSuccess = false;
      state.myDonationListData.data = null;
      state.myDonationListData.message = '';
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getMyDonationsList.pending, (state) => {
        state.myDonationListData.isLoading = true;
        state.myDonationListData.isError = false;
        state.myDonationListData.isSuccess = false;
        state.myDonationListData.data = null;
        state.myDonationListData.message = '';
      })
      .addCase(getMyDonationsList.rejected, (state) => {
        state.myDonationListData.isLoading = false;
        state.myDonationListData.isError = true;
        state.myDonationListData.isSuccess = false;
        state.myDonationListData.data = null;
        state.myDonationListData.message = '';
      })
      .addCase(getMyDonationsList.fulfilled, (state, action) => {
        state.myDonationListData.isLoading = false;
        state.myDonationListData.isError = false;
        state.myDonationListData.isSuccess = true;
        state.myDonationListData.data = action.payload;
        state.myDonationListData.message = '';
      })
      .addCase(getMyCharityList.pending, (state) => {
        state.myCharityListData.isLoading = true;
        state.myCharityListData.isError = false;
        state.myCharityListData.isSuccess = false;
        state.myCharityListData.data = null;
        state.myCharityListData.message = '';
      })
      .addCase(getMyCharityList.rejected, (state) => {
        state.myCharityListData.isLoading = false;
        state.myCharityListData.isError = true;
        state.myCharityListData.isSuccess = false;
        state.myCharityListData.data = null;
        state.myCharityListData.message = '';
      })
      .addCase(getMyCharityList.fulfilled, (state, action) => {
        state.myCharityListData.isLoading = false;
        state.myCharityListData.isError = false;
        state.myCharityListData.isSuccess = true;
        state.myCharityListData.data = action.payload;
        state.myCharityListData.message = '';
      });
  },
});

export const { resetDetail } = MyDonationsSlice.actions;
export default MyDonationsSlice.reducer;
