import axiosInstance from '../../API/axiosInstance';
import { MY_CHARITY_API, MY_DONATIONS_API } from '../../Constants/apiEndpoints';
import { getQsValues } from '../../Constants/getQsValues';

const getMyCharityList = async (data) => {
  try {
    const newQsValue = getQsValues(data);
    const response = await axiosInstance.get(`${MY_CHARITY_API}?${newQsValue}`);
    return response?.data?.data;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const getMyDonationsList = async (data) => {
  try {
    const newQsValue = getQsValues(data);
    const response = await axiosInstance.get(
      `${MY_DONATIONS_API}?${newQsValue}`
    );
    return response?.data?.data;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const MyDonationsService = {
  getMyDonationsList,
  getMyCharityList,
};

export default MyDonationsService;
