import axiosInstance from '../../API/axiosInstance';
import { MY_REDEMPTIONS_LIST_API } from '../../Constants/apiEndpoints';
import { getQsValues } from '../../Constants/getQsValues';

const getMyRedemptionList = async (data) => {
  try {
    const newQsValue = getQsValues(data);
    const response = await axiosInstance.get(
      `${MY_REDEMPTIONS_LIST_API}?${newQsValue}`
    );
    return response?.data?.data;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const MyRedemptionService = { getMyRedemptionList };

export default MyRedemptionService;
