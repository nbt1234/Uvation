import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

import MyRedemptionService from './MyRedemptionService';

const initialState = {
  myRedemptionListData: {
    isLoading: false,
    isSuccess: false,
    isError: false,
    data: null,
    message: '',
  },
};

export const getMyRedemptionList = createAsyncThunk(
  'Redemption/list',
  async (data, thunkAPI) => {
    try {
      return await MyRedemptionService.getMyRedemptionList(data);
    } catch (error) {
      const message = JSON.parse(error?.message)?.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const MyRedemptionSlice = createSlice({
  name: 'Redemption',
  initialState,
  reducers: {
    resetDetail: (state) => {
      state.myRedemptionListData.isLoading = false;
      state.myRedemptionListData.isError = false;
      state.myRedemptionListData.isSuccess = false;
      state.myRedemptionListData.data = null;
      state.myRedemptionListData.message = '';
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getMyRedemptionList.pending, (state) => {
        state.myRedemptionListData.isLoading = true;
        state.myRedemptionListData.isError = false;
        state.myRedemptionListData.isSuccess = false;
        state.myRedemptionListData.data = null;
        state.myRedemptionListData.message = '';
      })
      .addCase(getMyRedemptionList.rejected, (state) => {
        state.myRedemptionListData.isLoading = false;
        state.myRedemptionListData.isError = true;
        state.myRedemptionListData.isSuccess = false;
        state.myRedemptionListData.data = null;
        state.myRedemptionListData.message = '';
      })
      .addCase(getMyRedemptionList.fulfilled, (state, action) => {
        state.myRedemptionListData.isLoading = false;
        state.myRedemptionListData.isError = false;
        state.myRedemptionListData.isSuccess = true;
        state.myRedemptionListData.data = action.payload;
        state.myRedemptionListData.message = '';
      });
  },
});

export const { resetDetail } = MyRedemptionSlice.actions;
export default MyRedemptionSlice.reducer;
