import { createAsyncThunk, createSlice } from '@reduxjs/toolkit';

import MyReferralsService from './MyReferralsService';

const initialState = {
  myReferralsListData: {
    isLoading: false,
    isSuccess: false,
    isError: false,
    data: null,
    message: '',
  },
};

export const getMyReferralsList = createAsyncThunk(
  'myReferrals/list',
  async (data, thunkAPI) => {
    try {
      return await MyReferralsService.getMyReferralsList(data);
    } catch (error) {
      const message = JSON.parse(error?.message)?.message;
      return thunkAPI.rejectWithValue(message);
    }
  }
);

export const myReferralsSlice = createSlice({
  name: 'myReferrals',
  initialState,
  reducers: {
    resetDetail: (state) => {
      state.myReferralsListData.isLoading = false;
      state.myReferralsListData.isError = false;
      state.myReferralsListData.isSuccess = false;
      state.myReferralsListData.data = null;
      state.myReferralsListData.message = '';
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(getMyReferralsList.pending, (state) => {
        state.myReferralsListData.isLoading = true;
        state.myReferralsListData.isError = false;
        state.myReferralsListData.isSuccess = false;
        state.myReferralsListData.data = null;
        state.myReferralsListData.message = '';
      })
      .addCase(getMyReferralsList.rejected, (state, action) => {
        state.myReferralsListData.isLoading = false;
        state.myReferralsListData.isError = true;
        state.myReferralsListData.isSuccess = false;
        state.myReferralsListData.data = null;
        state.myReferralsListData.message = action.payload;
      })
      .addCase(getMyReferralsList.fulfilled, (state, action) => {
        state.myReferralsListData.isLoading = false;
        state.myReferralsListData.isError = false;
        state.myReferralsListData.isSuccess = true;
        state.myReferralsListData.data = action.payload;
        state.myReferralsListData.message = action.payload;
      });
  },
});

export const { resetDetail } = myReferralsSlice.actions;
export default myReferralsSlice.reducer;
