import axiosInstance from '../../API/axiosInstance';
import { getQsValues } from '../../Constants/getQsValues';
import { MY_REFERRALS_API } from '../../Constants/apiEndpoints';

const getMyReferralsList = async (data) => {
  try {
    const newQsValues = getQsValues(data);
    const response = await axiosInstance.get(
      `${MY_REFERRALS_API}?${newQsValues}`
    );
    return response?.data?.data;
  } catch (err) {
    const error = JSON.stringify(err);
    throw Error(error);
  }
};

const MyPromotionsService = { getMyReferralsList };

export default MyPromotionsService;
