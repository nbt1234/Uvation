/* eslint-disable consistent-return */
/* eslint-disable array-callback-return */
import { createSlice, current } from '@reduxjs/toolkit';
import { getItem, setItem } from '../../Services/localStorageService';

const initialState = {
  orderCartData: {
    data: getItem('orderCart') || [],
  },
  orderCartToggleData: false,
};

export const OrderCartSlice = createSlice({
  name: 'orderCart',
  initialState,
  reducers: {
    addProductToCart: (state, action) => {
      state.orderCartData.data = action.payload;
      setItem('orderCart', action.payload);
    },
    removeProductFromCart: (state, action) => {
      const data = current(state.orderCartData.data);
      const newData = data?.filter((item) => {
        if (item?.id !== action.payload?.id) {
          return item;
        }
      });
      state.orderCartData.data = newData;
      setItem('orderCart', newData);
    },
    toggleOrderCart: (state, action) => {
      state.orderCartToggleData = action.payload;
    },
  },
});

export const { addProductToCart, removeProductFromCart, toggleOrderCart } =
  OrderCartSlice.actions;
export default OrderCartSlice.reducer;
