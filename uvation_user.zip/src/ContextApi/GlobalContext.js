/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/jsx-no-constructed-context-values */
/* eslint-disable no-restricted-syntax */
/* eslint-disable guard-for-in */
/* eslint-disable no-plusplus */
/* eslint-disable eqeqeq */
/* eslint-disable react/jsx-no-useless-fragment */
/* eslint-disable no-unused-expressions */
/* eslint-disable react/jsx-filename-extension */
/* eslint-disable no-nested-ternary */
/* eslint-disable no-empty */
/* eslint-disable no-var */
/* eslint-disable vars-on-top */
/* eslint-disable object-shorthand */
/* eslint-disable prefer-template */
/* eslint-disable no-unused-vars */
/* eslint-disable prefer-const */
/* eslint-disable camelcase */
import { createContext, useState, useEffect } from 'react';
import axios from 'axios';
import moment from 'moment';
// import qs from 'qs';
// import { Loading } from 'carbon-components-react';
import { io } from 'socket.io-client';
import {
  // MsalAuthenticationTemplate,
  useMsal,
  useAccount,
} from '@azure/msal-react';
import {
  InteractionRequiredAuthError,
  // InteractionType,
} from '@azure/msal-browser';
// import { callApiWithToken } from "../fetch";
import { loginRequest, protectedResources } from '../authConfig';

let backend_url = 'https://appsapi.uvation.com:8080';
// let token_url = 'https://uvatiocnidp.azurewebsites.net';
// var backend_url =  "http://7143-2405-201-5c14-c81b-6dd3-3caf-b123-bf5.ngrok.io/";
const userdataajj = localStorage.getItem('font');

export const GlobalContext = createContext();
// const HelloContent = () => {

//   return(
//       <div>
//       {/* {account && account.idTokenClaims && <UserIdTokenClaims idTokenClaims={account.idTokenClaims} />}
//           { helloData ? <HelloData helloData={helloData} /> : null } */}
//           </div>
//       );

// };

export const GlobalProvider = (props) => {
  const [siginlogs, setsiginlogs] = useState();
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  localStorage.setItem('supportusermail', account?.idTokenClaims?.email);
  localStorage.setItem(
    'supportusername',
    `${account?.idTokenClaims?.given_name}${' '}${
      account?.idTokenClaims?.family_name
    }`
  );
  const [helloData, setHelloData] = useState(null);
  const [ankitdat, setankitdat] = useState(null);
  const [contactinfodata, setcontactinfodata] = useState();
  const [contactdata, setcontactdata] = useState();
  const [notificationuser, setnotificationuser] = useState();
  const [loadingnotification, setloadingnotification] = useState(false);
  const [systemnotificationuser, setsystemnotificationuser] = useState([]);
  const [base64Prefix, setBase64Prefix] = useState('data:image/png;base64,');
  const [getsalesforcedata, setgetsalesforcedata] = useState(false);
  const [imagedata, setimagedata] = useState(false);
  const [contactsalesforce, setcontactsalesforce] = useState([]);
  const [companyname, setcompanyname] = useState();
  const [MsAccessToken, setMsAccessToken] = useState('');
  const [isUserSignUp, setIsUserSignUp] = useState(false);

  // const [userupdateinfoaccount,setuserupdateinfoaccount] = useState(

  // );

  const usernameinfo = 'zendesk_admin@uvation.com';
  const passwordinfo = 'H9dh0DH72gF';
  const headers = {
    Authorization: 'Basic ' + btoa(`${usernameinfo}:${passwordinfo}`),
  };

  // useEffect(()=>{

  //   setuserupdateinfoaccount(account);
  // },[account])

  const accountdata = account;

  const callApiWithToken = async (accessToken, useremail, apiEndpoint) => {
    const headers = new Headers();
    const bearer = `Bearer ${accessToken}`;
    headers.append('Authorization', bearer);
    var newData = JSON.stringify({ email: useremail, optionid: userdataajj });
    const options = {
      method: 'POST',
      headers: headers,
      body: newData,
    };

    return fetch(apiEndpoint, options)
      .then((response) => {
        response.json().then((result) => {
          setsiginlogs(result?.data?.user_info);

          return result;
        });
      })
      .catch((error) => console.log(error));
  };

  useEffect(() => {
    if (account && inProgress === 'none' && !helloData) {
      instance
        .acquireTokenSilent({
          scopes: protectedResources.apiHello.scopes,
          account: account,
        })
        .then((response) => {
          setankitdat(response);

          callApiWithToken(
            response.accessToken,
            account?.idTokenClaims?.email,
            protectedResources.apiHello.endpoint
          ).then((response) => setHelloData(response));
        })
        .catch((error) => {
          // in case if silent token acquisition fails, fallback to an interactive method
          if (error instanceof InteractionRequiredAuthError) {
            if (account && inProgress === 'none') {
              instance
                .acquireTokenPopup({
                  scopes: protectedResources.apiHello.scopes,
                })
                .then((response) => {
                  callApiWithToken(
                    response.accessToken,
                    account?.idTokenClaims?.email,
                    protectedResources.apiHello.endpoint
                  ).then((response) => {});
                })
                .catch((error) => error);
            }
          }
        });
    }
  }, [account, inProgress, instance]);

  useEffect(() => {
    axios
      .post('https://appsapi.uvation.com:8080/identity/access_token')
      .then((res) => {
        setMsAccessToken(res);
        if (res?.data?.status === 'success') {
        }
      });
  }, []);
  const [toggle, settoggle] = useState({
    Quick: false,
    Support: false,
    Notification: false,
    Account: false,
    openHide: '',
    closedHide: '',
    pendingHide: '',
    newHide: '',
    tabselect: '',
  });
  const [AlldataWidget, setAlldataWidget] = useState([
    {
      id: '',
      datesubject: '',
    },
  ]);
  const [TablePagination, setTablePagination] = useState({
    totalrow: '',
    page: 1,
    per_page: 10,
    widget_page: 1,
    widget_per_page:
      window.innerHeight <= 800
        ? Math.floor((window.innerHeight - 275) / 80)
        : window.innerHeight > 800
        ? Math.floor((window.innerHeight - 295) / 76)
        : 10,
  });

  const [socketdata, setsocketdata] = useState();
  const [fetchdata, setfetchdata] = useState();

  const [photo, setphoto] = useState({
    photo: '',
    updatephoto: '',
  });

  const [userInfo, setuserInfo] = useState({
    status: null,
    userid: null,
    fullname: null,
    email: null,
    phone: null,
    country: null,
    address: null,
    city: null,
    state: null,
    postalCode: null,
    companyName: null,
    taxId: null,
  });

  const [updateUserInfo, setupdateUserInfo] = useState({
    fullname: null,
    email: null,
    phone: null,
    country: null,
    address: null,
    city: null,
    state: null,
    postalCode: null,
    companyName: null,
    taxId: null,
  });

  const [ToggleBtnMode, setToggleBtnMode] = useState({
    ToggleBtnModeon: '',
    TileOption: '',
    CloseModal: '',
    SelectedTile: '',
    EditTileOption: '',
  });
  const [Modalset, setModalset] = useState({
    personal: '',
    address: '',
    company: '',
  });
  // useEffect(() => {
  //   axios
  //     .get("https://appsapi.uvation.com:8080/identity/image_show", {
  //       params: {
  //         userid: userInfo?.userid,
  //       },
  //     })
  //     .then((res) => {
  //       // localStorage.setItem("")
  //       setphoto(res);
  //     });
  // }, [userInfo]);
  useEffect(() => {
    setuserInfo({
      ...userInfo,
      userid: account?.idTokenClaims?.sub,
      // surname:account?.idTokenClaims?.family_name,
      fullname: `${account?.idTokenClaims?.given_name}${' '}${
        account?.idTokenClaims?.family_name
      }`,
      email: account?.idTokenClaims?.email,
      phone: account?.idTokenClaims?.MobileNumber,
      country: account?.idTokenClaims?.country,
      address: account?.idTokenClaims?.streetAddress,
      city: account?.idTokenClaims?.city,
      state: account?.idTokenClaims?.state,
      postalCode: account?.idTokenClaims?.postalCode,
      companyName: account?.idTokenClaims?.extension_CompanyName,
      taxId: account?.idTokenClaims?.extension_TaxId,
    });
    // setupdateUserInfo({
    //   ...updateUserInfo,
    //   // surname:account?.idTokenClaims?.family_name,
    //   fullname: `${account?.idTokenClaims?.given_name}${" "}${account?.idTokenClaims?.family_name}`,
    //   email: account?.idTokenClaims?.email,
    //   phone: account?.idTokenClaims?.MobileNumber,
    //   country: account?.idTokenClaims?.country,
    //   address: account?.idTokenClaims?.streetAddress,
    //   city: account?.idTokenClaims?.city,
    //   state: account?.idTokenClaims?.state,
    //   postalCode: account?.idTokenClaims?.postalCode,
    //   companyName: account?.idTokenClaims?.extension_CompanyName,
    //   taxId: account?.idTokenClaims?.extension_TaxId,

    // });
  }, [account]);
  useEffect(() => {
    setupdateUserInfo({
      ...updateUserInfo,
      // surname:account?.idTokenClaims?.family_name,
      fullname: userInfo?.fullname,
      email: userInfo?.email,
      phone: userInfo?.phone,
      country: userInfo?.country,
      address: userInfo?.address,
      city: userInfo?.city,
      state: userInfo?.state,
      postalCode: userInfo?.postalCode,
      companyName: userInfo?.companyName,
      taxId: userInfo?.taxId,
    });
  }, [userInfo]);

  const countFetch = async () => {
    const responeall = await axios.post(
      `${backend_url}/identity/get_user_ticket`,
      { email: userInfo?.email },
      {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      }
    );

    const responeallWidget = await axios
      .post(`${backend_url}/identity/get_user_ticket`, {
        email: userInfo?.email,
        page_no: 1,
        per_page: 9,
      })
      .then((response) => {
        response.data.status !== 'failed' &&
          setAlldataWidget(
            response?.data?.data?.results.map((tic) => ({
              id: `${tic.id}`,
              datesubject: (
                <div>
                  <p
                    style={{
                      fontSize: '14px',
                      lineHeight: '18px',
                      fontWeight: '600',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {tic.subject}
                  </p>
                  <p
                    style={{
                      width: '130px',
                      fontSize: '12px',
                      lineHeight: '15px',
                      fontWeight: '400',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {moment(tic.created_at).format('llll')}
                  </p>
                </div>
              ),
            }))
          );
      });
    setTablePagination({
      ...TablePagination,
      totalrow: responeall.data?.data?.count,
    });
  };
  useEffect(() => {
    userInfo?.email && countFetch();
  }, [userInfo]);

  useEffect(() => {
    if (userInfo?.userid) {
      countFetch();
    }
  }, [
    TablePagination.widget_page,
    TablePagination.widget_per_page,
    userInfo.userid,
  ]);
  useEffect(() => {
    var socket = io.connect('https://notifications.uvation.com:443/');
    socket.on('connected', (i) => {
      // alert("awdaiwdhawuigdahiwd");
    });
    socket.emit('join', { userid: account?.idTokenClaims?.sub });
    setsocketdata(socket);
  }, [account]);
  let userdaat = {};

  const daass = accounts.map((value) => {
    if (value.idTokenClaims.auth_time) {
      userdaat.login = new Date(
        value.idTokenClaims.auth_time * 1000
      ).toUTCString();
    }
    if (value.idTokenClaims.ProfileEdit_DateTime) {
      userdaat.profile_edit_time = new Date(
        value.idTokenClaims.ProfileEdit_DateTime * 1000
      ).toUTCString();
    }
    if (value.idTokenClaims.PasswordResetDateTime) {
      userdaat.PasswordResetDateTimeu = new Date(
        value.idTokenClaims.PasswordResetDateTime * 1000
      ).toUTCString();
    }
    if (value.idTokenClaims.ChangeMFAphnNo_DateTime) {
      userdaat.ChangeMFAphnNo_DateTimeuser = new Date(
        value.idTokenClaims.ChangeMFAphnNo_DateTime * 1000
      ).toUTCString();
    }
    if (value.idTokenClaims.ForgotPasswordDateTime) {
      userdaat.ForgotPasswordDateTime = new Date(
        value.idTokenClaims.ForgotPasswordDateTime * 1000
      ).toUTCString();
    }

    if (value.idTokenClaims.isForgotPassword) {
      userdaat.isForgotPasswords = value.idTokenClaims.isForgotPassword;
    }
    return <></>;
  });

  const usernotification_token = localStorage.getItem('notification_token');
  useEffect(() => {
    if (userdaat) {
      axios
        .post('https://notifications.uvation.com:443/api/user_signup', {
          userid: account?.idTokenClaims?.sub,
          login_time: userdaat?.login,
          forgot_password_time: userdaat?.ForgotPasswordDateTime,
          change_password_time: userdaat?.PasswordResetDateTimeu,
          change_mfa_time: userdaat?.ChangeMFAphnNo_DateTimeuser,
          profile_edit_time: userdaat?.profile_edit_time,
          platform: 'uvation reward',
          new_user: account?.idTokenClaims?.newUser,
          forgot_password: userdaat.isForgotPasswords,
          token: usernotification_token,
        })
        .then((res) => {
          axios
            .post(
              'https://notifications.uvation.com:443/api/all_notifications',
              {
                userid: account?.idTokenClaims?.sub,
                platform: 'uvation reward',
              }
            )
            .then((res) => {
              setloadingnotification(false);
              setnotificationuser(res?.data?.data);
            });
        });
    }
  }, [account, loadingnotification]);
  useEffect(() => {
    axios
      .post('https://notifications.uvation.com:443/api/show_notification', {
        userid: account?.idTokenClaims?.sub,
        platform: 'uvation reward',
      })
      .then((res) => {
        setsystemnotificationuser(res?.data?.data);
      });
  }, [account]);
  let fetchtime;
  let timeout;
  let fetchtimeset;
  const rewardCreateContact = (response) => {
    axios
      .post('https://appsapi.uvation.com:8080/reward/contact', {
        azureId: account?.idTokenClaims?.sub,
        firstName: account?.idTokenClaims?.given_name,
        lastName: account?.idTokenClaims?.family_name,
        email: account?.idTokenClaims?.email,
        referral: account?.idTokenClaims?.referralCode,
        phoneNo: `${account?.idTokenClaims?.extension_CountryCode}${account?.idTokenClaims?.MobileNumber}`,
        ssContactId: response?.id,
      })
      .then((res) => {
        setIsUserSignUp(true);
      });
  };

  const createSalesforceContact = (response, timeout) => {
    axios
      .post(
        `${response?.response?.instance_url}/services/data/v43.0/sobjects/Contact`,
        {
          FirstName: account?.idTokenClaims?.given_name,
          LastName: account?.idTokenClaims?.family_name,
          Phone: '',
          email: account?.idTokenClaims?.email,
          MailingCity: '',
          MailingCountry: '',
          MailingState: '',
          MailingStreet: '',
          MailingPostalCode: '',
          Company_Name__c: '',
          Azure_User_ID__c: account?.idTokenClaims?.sub,
        },
        {
          headers: {
            Authorization: `Bearer ${response?.response?.access_token}`,
            'Access-Control-Allow-Origin': '*',
          },
        }
      )
      .then((res) => {
        if (res?.status == 201) {
          clearInterval(timeout);
          fetchtimeset = setInterval(() => {
            setgetsalesforcedata(true);
          }, 5000);
          rewardCreateContact(res?.data);
        }
      });
  };

  const checkUserExists = (response1) => {
    axios
      .get(
        `${response1?.response?.instance_url}/services/apexrest/userExists?azureId=${account?.idTokenClaims?.sub}`,
        {
          headers: {
            Authorization: `Bearer ${response1?.response?.access_token}`,
            'Access-Control-Allow-Origin': '*',
          },
        }
      )
      .then((res) => {
        if (res?.data?.Exists == false) {
          timeout = setInterval(() => {
            createSalesforceContact(response1, timeout);
          }, 5000);
        }
      });
  };
  const salesforcetoken = () => {
    axios
      .post('https://appsapi.uvation.com:8080/identity/sftoken')
      .then((res) => {
        setfetchdata(res.data);
        checkUserExists(res.data);
        // createSalesforceContact(res.data);
      });
  };

  useEffect(() => {
    if (account) {
      salesforcetoken();
    }
  }, [account]);

  useEffect(() => {
    if (fetchdata) {
      axios
        .get(
          `${fetchdata?.response?.instance_url}/services/apexrest/ContactInfo?azureId=${account?.idTokenClaims?.sub}`,
          {
            headers: {
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              'Access-Control-Allow-Origin': '*',
            },
          }
        )
        .then((res) => {
          if (res?.data?.status == 'Success') {
            clearInterval(fetchtime);
            setcontactinfodata(res?.data?.contactInfo);
            setcontactsalesforce(res?.data?.companyInfo);
          }
        });
    }
  }, [fetchdata, account, getsalesforcedata]);

  const rewarddat_edit = () => {
    axios
      .post('https://appsapi.uvation.com:8080/reward/edit_contact', {
        azureId: account?.idTokenClaims?.sub,
        firstName: account?.idTokenClaims?.given_name,
        lastName: account?.idTokenClaims?.family_name,
        email: account?.idTokenClaims?.email,
        // ssContactId: contactinfodata?.recordId,
        phoneNo: `${account?.idTokenClaims?.extension_CountryCode}${account?.idTokenClaims?.MobileNumber}`,
      })
      .then(() => {
        setIsUserSignUp(true);
      });
  };
  useEffect(() => {
    if (contactinfodata?.recordId && fetchdata) {
      axios
        .patch(
          `${fetchdata?.response?.instance_url}/services/data/v41.0/sobjects/contact/${contactinfodata?.recordId}`,
          {
            FirstName: account?.idTokenClaims?.given_name,
            LastName: account?.idTokenClaims?.family_name,
            Email: account?.idTokenClaims?.email,
            Phone: account?.idTokenClaims?.MobileNumber,
            MailingStreet: account?.idTokenClaims?.streetAddress,
            MailingCity: account?.idTokenClaims?.city,
            MailingState: account?.idTokenClaims?.state,
            MailingCountry: account?.idTokenClaims?.country,
            MailingPostalCode: account?.idTokenClaims?.postalCode,
          },
          {
            headers: {
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              'Access-Control-Allow-Origin': '*',
            },
          }
        )
        .then((res) => {});
    }
  }, [contactinfodata, fetchdata, account]);
  useEffect(() => {
    if (contactinfodata?.recordId !== undefined) {
      axios
        .get(
          `${fetchdata?.response?.instance_url}/services/apexrest/ProfileImage?contactId=${contactinfodata?.recordId}`,
          {
            headers: {
              'Content-Type': 'application/json',
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              'Access-Control-Allow-Origin': '*',
            },
          }
        )
        .then((res) => {
          setphoto(res);
          setBase64Prefix('data:image/png;base64,');
        });
    }
    // }
  }, [contactinfodata, fetchdata, imagedata]);
  useEffect(() => {
    axios
      .get(
        `${fetchdata?.response?.instance_url}/services/apexrest/GetAccounts`,
        {
          headers: {
            Authorization: `Bearer ${fetchdata?.response?.access_token}`,
            'Access-Control-Allow-Origin': '*',
          },
        }
      )
      .then((res) => {
        let keys = Object.keys(res?.data?.accounts);
        let data = [];
        let i = 0;
        for (let x in res?.data?.accounts) {
          i++;
          data.push({ key: keys[i], value: res?.data?.accounts[keys[i]] });
        }
        setcompanyname(data);
      });
  }, [contactdata]);
  useEffect(() => {
    if (account && contactinfodata) {
      rewarddat_edit();
    }
  }, [account, contactinfodata]);
  return (
    <>
      <GlobalContext.Provider
        value={{
          base64Prefix,
          headers,
          socketdata,
          account,
          isUserSignUp,
          notificationuser,
          systemnotificationuser,
          setsystemnotificationuser,
          setloadingnotification,
          helloData,
          toggle,
          settoggle,
          AlldataWidget,
          setAlldataWidget,
          TablePagination,
          setTablePagination,
          MsAccessToken,
          setMsAccessToken,
          userInfo,
          setuserInfo,
          updateUserInfo,
          setupdateUserInfo,
          ToggleBtnMode,
          setToggleBtnMode,
          Modalset,
          setModalset,
          photo,
          accountdata,
          setphoto,
        }}
      >
        {props.children}
      </GlobalContext.Provider>
    </>
  );
};

export const GlobalConsumer = GlobalContext.Consumer;
