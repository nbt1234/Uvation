/* eslint-disable import/no-cycle */
import axios from 'axios';
import { getToken } from '../Auth/getToken';
import {
  logoutUserHandler,
  clearStorageData,
  redirectLogout,
} from '../Utils/logoutUserHandler';
import { UNAUTHORIZED_USER } from '../Constants/statusCodes';
import { getAzureId } from '../Auth/getAzureId';

const axiosInstance = axios.create({
  baseURL: process.env.REACT_APP_API_BASE_URL,
});

axiosInstance.interceptors.request.use((config) => {
  config.headers['Content-Type'] = 'application/json';
  config.headers.Authorization = getToken();
  config.params = {
    azureId: getAzureId(),
    ...config.params,
  };
  return config;
});

axiosInstance.interceptors.response.use(
  (response) => {
    if (response.status === UNAUTHORIZED_USER) {
      clearStorageData();
      redirectLogout();
    }
    return response;
  },
  (error) => {
    const { response } = error;
    if (response?.status === UNAUTHORIZED_USER) {
      logoutUserHandler();
      redirectLogout();
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
