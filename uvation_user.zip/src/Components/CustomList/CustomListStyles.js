import { CHRISTMAS_SILVER, BLUEROCRATIC } from '../../Constants/colors';

export const styles = {
  mainContainer: {
    padding: '30px',
  },
  mainListContainer: {
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    gap: '30px',
  },
  imageContainer: {
    display: 'flex',
    alignItems: 'start',
    lineHeight: '0.9rem',
    gap: '5px',
    width: '18%',
  },
  imageStyle: {
    width: '15px',
    height: '15px',
  },
  listImageStyle: {
    width: '120px',
    height: '100px',
  },
  mainContantContainer: {
    boxSizing: 'border-box',
    border: `1px solid ${CHRISTMAS_SILVER}`,
    padding: '30px',
    width: '100%',
  },
  mainHeader: {
    marginBottom: '40px',
  },
  subHeaderWrapper: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  mainHeaderStyle: {
    fontSize: '24px',
    lineHeight: '20px',
  },
  recordCountStyle: {
    display: 'flex',
    height: '100%',
    flexDirection: 'column',
    justifyContent: 'flex-end',
    textAlign: 'end',
    marginBottom: '10px',
  },
  innerFieldsContainer: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '20px',
    marginBottom: '20px',
  },
  rightContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    width: '80%',
    flexWrap: 'wrap',
    gap: '20px',
  },
  fieldsWrapper: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: '20px',
    flexWrap: 'wrap',
    columnGap: '20px',
    rowGap: '20px',
  },
  subHeadingText: {
    marginBottom: '20px',
    fontSize: '20px',
  },
  biggerText: {
    fontSize: '17px',
    fontWeight: '500',
    lineHeight: '0.9rem',
  },
  priceText: {
    fontSize: '17px',
    fontWeight: '500',
  },
  buttonStyles: {
    width: '150px',
    border: `2px solid ${BLUEROCRATIC}`,
    borderRadius: '0',
    '&: hover': {
      border: `2px solid ${BLUEROCRATIC}`,
      borderRadius: '0',
    },
  },
  imagesInnerBox: {
    display: 'flex',
    alignItem: 'center',
    flexWrap: 'wrap',
    gap: '10px',
  },
  extraImageContainer: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: '10px',
  },
  extraImageText: {
    fontSize: '24px',
    color: 'grey',
  },
  buttonContainer: {
    display: 'flex',
    alignItems: 'end',
  },
  imageStyleText: {
    marginTop: '10px',
    display: 'flex',
    justifyContent: 'center',
    width: '80%',
    maxWidth: '500px',
    textAlign: 'center',
  },
  errorStyle: {
    fontSize: '25px',
    fontWeight: '600',
  },
  loaderStyles: {
    height: '500px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    flexDirection: 'column',
  },
};
