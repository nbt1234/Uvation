/* eslint-disable react/no-array-index-key */
/* eslint-disable no-unsafe-optional-chaining */
import { Box, Typography, Divider } from '@mui/material';

import FieldNameAndValue from '../FieldNameAndValue/FieldNameAndValue';
import timeActive from '../../Assets/Images/timeActive.svg';
import CustomButton from '../Widgets/CustomButton/CustomButton';
import { styles } from './CustomListStyles';

const CustomSingleList = (props) => {
  const { data, navigateHandler } = props;

  return (
    <Box sx={styles.mainContantContainer}>
      <Box sx={styles.innerFieldsContainer}>
        <Box sx={styles.imageContainer}>
          <Typography sx={styles.imageStyle} component="img" src={timeActive} />
          <Typography sx={styles.biggerText}>{data?.orderStatus}</Typography>
        </Box>
        <Box sx={styles.rightContainer}>
          <FieldNameAndValue name="ORDER ID" value={data?.marketPlaceOrderId} />
          <FieldNameAndValue
            name="PROMOTION NAME"
            value={data?.promotionName}
          />
          <FieldNameAndValue name="ORDER STATUS" value={data?.orderStatus} />
          <FieldNameAndValue
            name="RELEASE STATUS"
            value={data?.promotionReleaseStatus}
          />
          <FieldNameAndValue
            name="Promotion Amount"
            value={
              data?.orderPromotionAmount
                ? `$${data?.orderPromotionAmount}`
                : '--'
            }
            customValueStyle={styles.priceText}
          />
        </Box>
      </Box>
      <Divider />
      <Box sx={styles.fieldsWrapper}>
        <Box sx={styles.imagesInnerBox}>
          {data?.imageUrl?.slice(0, 3)?.map((item, index) => {
            return (
              <Typography
                sx={styles.listImageStyle}
                component="img"
                src={item}
                key={index}
              />
            );
          })}
          {data?.imageUrl?.length > 3 && (
            <Box sx={styles.extraImageContainer}>
              <Typography sx={styles.extraImageText}>
                +{data?.imageUrl?.length - 3}
              </Typography>
            </Box>
          )}
        </Box>
        <Box sx={styles.buttonContainer}>
          <CustomButton
            textContent="Detail"
            variant="outlined"
            clickHandler={() => navigateHandler(data)}
            customStyles={styles.buttonStyles}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default CustomSingleList;
