/* eslint-disable no-nested-ternary */
/* eslint-disable no-unsafe-optional-chaining */
import { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { Box, TablePagination, Typography } from '@mui/material';

import CustomSingleList from './CustomSingleList';
import CustomLoader from '../Widgets/CustomLoader/CustomLoader';
import EmptyImage from '../../Assets/Images/empty.svg';
import { urlservice } from '../../Services/urlService';
import { ROW_PER_PAGE_OPTIONS } from '../../Constants/constants';
import { SOMETHING_WENT_WRONG } from '../../Constants/errorMessages';
import { styles } from './CustomListStyles';
import { commonStyles } from '../../Assets/Styles/commonStyles';

const CustomList = (props) => {
  const {
    listData,
    hidePagination,
    totalCount,
    pageHeading,
    dispatchFunction,
    navigateHandler,
    isLoading,
    isSuccess,
    isError,
    showCount,
    showCustomError,
  } = props;

  const [tableQueryParams, setTableQueryParams] = useState(() =>
    urlservice.getTableQueryParams(hidePagination)
  );

  const dispatch = useDispatch();

  const handleChangePage = (event, newPage) => {
    setTableQueryParams((prev) => {
      return {
        ...prev,
        page: newPage + 1,
      };
    });
  };

  const handleChangeRowsPerPage = (event) => {
    setTableQueryParams((prev) => {
      return {
        ...prev,
        rowsPerPage: parseInt(event.target.value, 10),
        page: 1,
      };
    });
  };

  const getPaginationCount = () => {
    return Math.ceil(totalCount / +tableQueryParams?.rowsPerPage);
  };

  const handleDispatch = () => {
    if (hidePagination) {
      dispatch(dispatchFunction());
      return;
    }
    const paginationParams = {
      limit: tableQueryParams?.rowsPerPage,
      skip: (tableQueryParams?.page - 1) * tableQueryParams?.rowsPerPage || 0,
    };

    if (dispatchFunction) {
      dispatch(dispatchFunction(paginationParams));
    }
  };

  useEffect(() => {
    const newTableParams = { ...tableQueryParams };
    if (dispatchFunction) {
      handleDispatch();
    }
    urlservice.setQueryParameters({ ...newTableParams });
  }, [tableQueryParams]);

  useEffect(() => {
    if (totalCount) {
      if (+tableQueryParams.page > getPaginationCount()) {
        setTableQueryParams((prev) => {
          return { ...prev, page: 1 };
        });
      }
    }
  }, [totalCount]);

  const displayNoData = () => {
    if (isLoading) {
      return (
        <Box sx={styles.loaderStyles}>
          <CustomLoader />
        </Box>
      );
    } else if (isError) {
      return (
        <Box sx={styles.loaderStyles}>
          <Typography sx={styles.errorStyle}>{SOMETHING_WENT_WRONG}</Typography>
        </Box>
      );
    } else if (totalCount === 0) {
      return (
        <Box sx={styles.loaderStyles}>
          <Typography component="img" src={EmptyImage} />
          <Typography sx={styles.imageStyleText}>
            {showCustomError || `It's empty in here`}
          </Typography>
        </Box>
      );
    }
    return null;
  };

  return (
    <Box sx={styles.mainContainer}>
      {pageHeading && (
        <Box sx={styles.mainHeader}>
          <Typography sx={styles.mainHeaderStyle}>{pageHeading}</Typography>
        </Box>
      )}
      {showCount && (
        <Box sx={styles.recordCountStyle}>
          <Typography>
            {totalCount >= 0 ? (
              <Typography sx={commonStyles.textBold} component="span">
                {totalCount} &nbsp;
              </Typography>
            ) : (
              'No'
            )}
            {totalCount <= 1 ? 'record' : 'records'} found
          </Typography>
        </Box>
      )}
      {displayNoData()}
      <Box sx={styles.mainListContainer}>
        {isSuccess &&
          listData?.map((item) => {
            return (
              <CustomSingleList
                data={item}
                navigateHandler={navigateHandler}
                key={item?.orderId}
              />
            );
          })}
      </Box>
      {!hidePagination && +totalCount ? (
        <TablePagination
          rowsPerPageOptions={ROW_PER_PAGE_OPTIONS}
          component="div"
          count={totalCount}
          rowsPerPage={tableQueryParams?.rowsPerPage}
          page={+tableQueryParams.page - 1}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      ) : null}
    </Box>
  );
};

export default CustomList;
