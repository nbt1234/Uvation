import {
  CAVERNOUS,
  COLD_MORNING,
  POT_BLACK,
  MORE_THAN_A_WEEK,
  WHITE,
  HEROIC_BLUE,
} from '../../Constants/colors';

export const styles = {
  cardMainContainer: {
    minHeight: '262px',
    padding: '20px 25px',
    background: WHITE,
    border: `1px solid ${COLD_MORNING}`,
    opacity: 1,
  },
  cardSubContainer: {
    display: 'flex',
    width: '100%',
    alignItems: 'center',
    '@media (max-width:600px)': {
      flexDirection: 'column',
      alignItems: 'flex-start',
    },
  },
  midContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    width: 'calc(100% - 50px)',
    margin: '29px 0px 0 0px',
    flexWrap: 'wrap',
    '@media (max-width:600px)': {
      flexDirection: 'column',
      alignItems: 'flex-start',
    },
  },
  mainHeader: {
    color: POT_BLACK,
    fontSize: '20px',
    opacity: 1,
    marginRight: '24px',
    textTransform: 'capitalize',
  },
  bottomContainer: {
    display: 'flex',
    flexDirection: 'column',
    marginTop: '25px',
  },
  flexContainer: { display: 'flex', flexWrap: 'wrap', margin: '6px 0px' },
  basicText: {
    fontSize: '14px',
    opacity: 1,
  },
  secBtnText: {
    color: HEROIC_BLUE,
    fontSize: '16px',
    textTransform: 'uppercase',
    cursor: 'pointer',
  },
  primaryBtnText: {
    color: HEROIC_BLUE,
    fontSize: '16px',
    textDecoration: 'underline',
    cursor: 'pointer',
    margin: '9px 0px',
  },
  subHeader: {
    color: MORE_THAN_A_WEEK,
    margin: '7px 0px',
  },
  keyTextStyle: {
    color: CAVERNOUS,
  },
  valueTextStyle: {
    color: POT_BLACK,
    marginLeft: '3px',
    marginRight: '3px',
    wordBreak: 'break-all',
    fontWeight: 500,
  },
};
