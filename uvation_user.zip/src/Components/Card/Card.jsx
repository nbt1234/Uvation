import { Box, Typography } from '@mui/material';
import { useNavigate } from 'react-router-dom';

import {
  MY_PROMOTIONS,
  MY_REFERRALS,
  GET_FREE_GIFT_CARD,
} from '../../Routes/Routes';
import { styles } from './CardStyles';

const Card = (props) => {
  const { type, mainHeader, subHeader, primaryButton, dataArray, giftData } =
    props;

  const navigate = useNavigate();
  const navigateToGiftCardModal = () => {
    navigate(GET_FREE_GIFT_CARD);
  };

  const primaryBtnHandler = () => {
    if (type === 'promotion') {
      navigate(MY_PROMOTIONS);
    } else if (type === 'referral') {
      navigate(MY_REFERRALS);
    }
  };

  return (
    <Box sx={styles.cardMainContainer}>
      <Box sx={styles.cardSubContainer}>
        <Typography sx={styles.mainHeader}>{mainHeader}</Typography>
      </Box>
      <Typography sx={{ ...styles.basicText, ...styles.subHeader }}>
        {subHeader}
      </Typography>
      {type === 'loyalty' && (
        <Box sx={styles.midContainer}>
          <Typography sx={{ ...styles.basicText, ...styles.keyTextStyle }}>
            {giftData}
          </Typography>
          <Typography sx={styles.secBtnText} onClick={navigateToGiftCardModal}>
            GET Free GIFT
          </Typography>
        </Box>
      )}
      <Box sx={styles.bottomContainer}>
        {dataArray?.map((item) => {
          return (
            <Box sx={styles.flexContainer} key={item.id}>
              <Typography sx={{ ...styles.basicText, ...styles.keyTextStyle }}>
                {item?.key}
              </Typography>
              <Typography
                sx={{ ...styles.basicText, ...styles.valueTextStyle }}
              >
                {item?.value}
              </Typography>
              {item?.spanText && (
                <Typography
                  sx={{ ...styles.basicText, ...styles.keyTextStyle }}
                >
                  {item?.spanText}
                </Typography>
              )}
            </Box>
          );
        })}
        <Typography sx={styles.primaryBtnText} onClick={primaryBtnHandler}>
          {primaryButton?.text}
        </Typography>
      </Box>
    </Box>
  );
};

export default Card;
