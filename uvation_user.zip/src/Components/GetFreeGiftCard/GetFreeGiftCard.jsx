/* eslint-disable no-unsafe-optional-chaining */
import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import * as _ from 'lodash';
import { Box } from '@mui/material';

import CustomTable from '../Widgets/CustomTable/CustomTable';
import CustomButton from '../Widgets/CustomButton/CustomButton';
import LoyaltyInfo from '../LoyaltyInfo/LoyaltyInfo';
import { getFreeGiftsList } from '../../Redux/GetFreeGift/GetFreeGiftSlice';
import { getLoyaltyPointsService } from '../../Services/dashboardService';
import {
  addProductToCart,
  toggleOrderCart,
} from '../../Redux/OrderCart/OrderCartSlice';
import { getItem } from '../../Services/localStorageService';
import { styles } from './GetFreeGiftCardStyles';

const GetFreeGiftCard = () => {
  const [selected, setSelected] = useState(getItem('orderCart') || []);
  const navigate = useNavigate();
  const [loyaltyData, setLoyaltyData] = useState({
    loyaltyPointsBalance: '',
    redeemAmount: '',
  });
  const [remainingLoyaltyPoints, setRemainingLoyaltyPoints] = useState(null);

  const dispatch = useDispatch();

  const { data, isSuccess, isLoading, isError } = useSelector(
    (state) => state.getFreeGift.getFreeGiftsListData
  );
  const { orderCartData } = useSelector((state) => state.orderCart);

  const fetchLoyaltyPoints = async () => {
    const response = await getLoyaltyPointsService();
    if (response?.data?.data?.data) {
      setLoyaltyData({
        loyaltyPointsBalance: response?.data?.data?.data?.loyaltyPointsBalance,
        redeemAmount: parseFloat(
          response?.data?.data?.data?.loyaltyPointsRedeemedToUSD
        ).toFixed(2),
      });
      setRemainingLoyaltyPoints(
        response?.data?.data?.data?.loyaltyPointsBalance
      );
    }
  };

  const cartOpenHandler = () => {
    dispatch(toggleOrderCart(true));
  };

  useEffect(() => {
    setSelected(orderCartData?.data);
  }, [orderCartData?.data]);

  const navigateBack = () => {
    navigate(-1);
  };

  useEffect(() => {
    fetchLoyaltyPoints();
  }, []);

  useEffect(() => {
    const loyaltyPointsLeft = _.sumBy(selected, function sumUp(giftItem) {
      return giftItem.loyaltyCardPoints;
    });
    setRemainingLoyaltyPoints(
      loyaltyData.loyaltyPointsBalance - loyaltyPointsLeft
    );
    dispatch(addProductToCart(selected));
  }, [selected]);

  const metaData = [
    {
      keyId: 0,
      mappingId: 'id',
      mappingKey: 'checkbox',
      headingName: 'Select',
      colType: 'checkbox',
      width: '5%',
      align: 'left',
      compareKey: 'loyaltyCardPoints',
    },
    {
      keyId: 1,
      mappingId: 'id',
      mappingKey: 'productImage',
      headingName: 'Product Image',
      colType: 'image',
      width: '5%',
      align: 'left',
    },
    {
      keyId: 2,
      mappingId: 'id',
      mappingKey: 'productCode',
      headingName: 'Product Code',
      colType: 'text',
      width: '10%',
      align: 'left',
    },
    {
      keyId: 3,
      mappingId: 'id',
      mappingKey: 'productName',
      headingName: 'Product Name',
      colType: 'text',
      width: '10%',
      align: 'left',
    },
    {
      keyId: 4,
      mappingId: 'id',
      mappingKey: 'loyaltyCardPoints',
      headingName: 'Loyalty points',
      colType: 'chip',
      width: '10%',
      align: 'left',
      decorText: true,
    },
  ];

  return (
    <Box sx={styles.tableMainContainer}>
      <CustomTable
        tableData={data?.result}
        metaData={metaData}
        totalCount={data?.totalCount || 0}
        isLoading={isLoading}
        isError={isError}
        isSuccess={isSuccess}
        pageHeading="Loyalty Free Items"
        selected={selected}
        setSelected={setSelected}
        customPaperStyle={styles.customPaperStyle}
        customTableStyle={styles.customTableStyle}
        headerChildren={<LoyaltyInfo loyaltyData={loyaltyData} />}
        dispatchFunction={getFreeGiftsList}
        remainingLoyaltyPoints={remainingLoyaltyPoints}
        comparisionKey="loyaltyCardPoints"
        backNavigationHandler={navigateBack}
      />
      <CustomButton
        textContent="Proceed"
        type="proceed"
        customStyles={styles.btnStyle}
        clickHandler={cartOpenHandler}
      />
    </Box>
  );
};

export default GetFreeGiftCard;
