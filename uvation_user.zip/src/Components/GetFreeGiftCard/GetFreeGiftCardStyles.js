export const styles = {
  tableMainContainer: {
    width: '100%',
    display: 'flex',
    alignItems: 'flex-end',
    flexDirection: 'column',
  },
  customPaperStyle: { marginTop: '15px' },
  customTableStyle: { maxHeight: 'calc(100vh - 410px)' },
  btnStyle: {
    margin: '1rem 2rem',
    marginTop: '-1rem',
    '@media (max-width:600px)': {
      margin: '-0.5rem 0.5rem',
    },
  },
};
