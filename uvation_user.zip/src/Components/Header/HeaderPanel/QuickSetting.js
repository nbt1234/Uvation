/* eslint-disable react/jsx-filename-extension */
import { useEffect, useState } from 'react';
import {
  Button,
  // ModalWrapper,
  // FormGroup,
  // TextInput,
  Toggle,
} from 'carbon-components-react';
import { Launch16, Checkmark24 } from '@carbon/icons-react';
import { Link } from 'react-router-dom';
import { useAccount, useMsal } from '@azure/msal-react';
import axios from 'axios';
// const CardToggleFun = ({ NameFun, NameDesc, Toggle }) => (
//   <div className="bx--row quick-func-list">
//     <div>
//       <h3>{NameFun}</h3>
//       <p>{NameDesc}</p>
//     </div>

//     <div className="toggle-align">
//       <Toggle aria-label="toggle button" defaultToggled={Toggle} labelText="" />
//     </div>
//   </div>
// );

const QuickSetting = () => {
  const [IsOn, setIsOn] = useState(true);
  const { accounts } = useMsal();
  const account = useAccount(accounts[0] || {});
  const idassUrl = 'https://identity.uvation.com/';
  useEffect(() => {
    axios
      .post('https://appsapi.uvation.com:8080/identity/system_notifi', {
        userid: account?.idTokenClaims?.sub,
        systembutton: '',
      })
      .then((res) => {
        setIsOn(res);
      });
  }, [account]);
  return (
    <div className="ibm-type-mono">
      <h2>Themes</h2>
      <div className="bx--row theme-div">
        {/* <div className='color-div black'></div>
        <div className='color-div grey'></div> */}
        <div className="color-div white">
          <Checkmark24 />
        </div>
      </div>
      <h2>Password</h2>
      <Button
        as={Link}
        kind="ghost"
        size="small"
        renderIcon={Launch16}
        onClick={() => {
          window.open(`${idassUrl}account/security`, '_blank');
        }}
      >
        Change Password
      </Button>
      <h2>Edit account details</h2>
      <div className="Edit-div-inner">
        {/* <ModalWrapper
          open={true}
          size='xs'
          buttonTriggerClassName='btn-h'
          triggerButtonKind='ghost'
          renderTriggerButtonIcon={Launch16}
          buttonTriggerText='Personal info'
          modalHeading='Edit your personal details'
          modalLabel=''
          hasForm
        >
          <div className='personal-info-modal'>
            <div className='bx--row'>
              <div className='bx--col bx--no-gutter--left'>
                <FormGroup legendText='Form'>
                  <TextInput
                    id='test11'
                    invalidText='A valid value is required'
                    labelText='Your full name*'
                    placeholder='Vlad Serban'
                  />
                </FormGroup>
              </div>
              <div className='bx--col bx--no-gutter--left'>
                <FormGroup legendText='Form'>
                  <TextInput
                    id='test12'
                    invalidText='A valid value is required'
                    labelText='Email address'
                    placeholder='serbantudovlad@gmail.com'
                  />
                </FormGroup>
              </div>
            </div>
            <div className='bx--row'>
              <div className='bx--col'>
                <FormGroup legendText='Form'>
                  <TextInput
                    id='test13'
                    invalidText='A valid value is required'
                    labelText='Phone number*'
                    placeholder='+1 0755 555 5556'
                  />
                </FormGroup>
              </div>
              <div className='bx--col bx--no-gutter--left'>
                <FormGroup legendText='Form'>
                  <TextInput
                    id='test14'
                    invalidText='A valid value is required'
                    labelText='Alternate phone (optional)'
                    placeholder='+1 255 255 255'
                  />
                </FormGroup>
              </div>
            </div>
          </div>
        </ModalWrapper> */}
        <Button
          as={Link}
          onClick={() => {
            window.open(`${idassUrl}account/info`, '_blank');
          }}
          kind="ghost"
          size="small"
          renderIcon={Launch16}
        >
          Personal info
        </Button>
        <Button
          as={Link}
          kind="ghost"
          size="small"
          renderIcon={Launch16}
          onClick={() => {
            window.open(`${idassUrl}account/security`, '_blank');
          }}
        >
          Security & Sign In
        </Button>
        <Button
          as={Link}
          kind="ghost"
          size="small"
          renderIcon={Launch16}
          onClick={() => {
            window.open(`${idassUrl}account/privacy`, '_blank');
          }}
        >
          Privacy
        </Button>
      </div>
      {/* <div className='quick-func-list'>
        <div>
          <h3>Multi-Factor Authentication</h3>
          <p>Manage your sign in preferences</p>
        </div>

        <div className='toggle-align'>
          <Toggle
            id='toggle-u-1'
            aria-label='toggle button'
            defaultToggled
            labelText=''
          />
        </div>
      </div> */}

      {/* <div className='quick-func-list'>
        <div>
          <h2>Contact Preference</h2>
          <p>Receive non services related news and updates.</p>
        </div>

        <div className='toggle-align'>
          <Toggle id='toggle-u-2' aria-label='toggle button' labelText='' />
        </div>
      </div> */}
      <div className="quick-func-list">
        <div>
          <h2>System Notifications</h2>
          <p>Enable to recieve login notifications.</p>
        </div>

        <div className="toggle-align">
          <Toggle
            id="toggle-u-3"
            defaultToggled
            aria-label="toggle button"
            toggled={IsOn?.data?.response_notifi}
            onToggle={(event) => {
              axios
                .post(
                  'https://appsapi.uvation.com:8080/identity/system_notifi',
                  {
                    userid: account?.idTokenClaims?.sub,
                    systembutton: event,
                  }
                )
                .then((res) => {
                  setIsOn(res);
                });
              // setIsOn(event)
            }}
          />
        </div>
      </div>
    </div>
  );
};
export default QuickSetting;
