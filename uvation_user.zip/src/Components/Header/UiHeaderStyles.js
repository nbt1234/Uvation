import { WHITE, HEROIC_BLUE } from '../../Constants/colors';

export const styles = {
  toolbarStyle: {
    '@media (min-width: 600px)': {
      display: 'none',
    },
  },
  mobileStyle: {
    '@media (max-width: 600px)': {
      display: 'none',
    },
  },
  hamBurgerStyle: {
    color: WHITE,
  },
  cartIconWrapper: {
    cursor: 'pointer',
  },
  cartIcon: {
    color: WHITE,
  },
  badge: {
    '& .MuiBadge-badge': {
      backgroundColor: HEROIC_BLUE,
    },
  },
};
