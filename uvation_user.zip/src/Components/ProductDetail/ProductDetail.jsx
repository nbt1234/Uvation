/* eslint-disable no-unsafe-optional-chaining */
import { Box } from '@mui/material';

import CustomTable from '../Widgets/CustomTable/CustomTable';
import { styles } from './ProductDetailStyles';
import { commonStyles } from '../../Assets/Styles/commonStyles';

const ProductDetail = (props) => {
  const { data } = props;

  const tableData = [
    ...(data?.orderItem
      ? data?.orderItem?.map((item) => {
          return { ...item, price: `$${item.price}` };
        })
      : []),
    ...(data?.freeItem
      ? data?.freeItem?.map((item) => {
          return {
            ...item,
            price: `${parseInt(item.price, 10)} pts`,
            productQty: '1',
          };
        })
      : []),
  ];

  const metaData = [
    {
      keyId: 0,
      mappingId: 'id',
      mappingKey: 'imageUrl',
      headingName: 'Image',
      colType: 'image',
      width: '40%%',
      align: 'left',
    },
    {
      keyId: 1,
      mappingId: 'id',
      mappingKey: 'name',
      headingName: 'Name',
      colType: 'text',
      width: '30%%',
      align: 'left',
    },
    {
      keyId: 2,
      mappingId: 'id',
      mappingKey: 'productQty',
      headingName: 'Product Qty',
      colType: 'text',
      width: '30%',
      align: 'left',
    },
    {
      keyId: 3,
      mappingId: 'id',
      mappingKey: 'price',
      headingName: 'Price',
      colType: 'text',
      width: '20%',
      align: 'left',
    },
  ];

  return (
    <Box sx={commonStyles.mainContentContainer}>
      <CustomTable
        tableData={tableData}
        metaData={metaData}
        totalCount={tableData?.length || 0}
        isLoading={false}
        isError={false}
        isSuccess
        styleData={styles.customTableContainer}
        customTextHeadingStyle={commonStyles.upperCaseText}
        hidePagination
        customTableCellStyle={styles.styledTableCell}
        customPaperStyle={styles.customPaperStyle}
      />
    </Box>
  );
};

export default ProductDetail;
