import { tableCellClasses } from '@mui/material';

export const styles = {
  styledTableCell: {
    [`&.${tableCellClasses.head}`]: {
      borderTop: '0px',
    },
  },
  customPaperStyle: {
    marginTop: '-20px',
  },
  customTableContainer: {
    margin: 0,
    width: '100%',
    '@media (max-width:600px)': {
      width: '100%',
      margin: '0rem',
      marginTop: '-1.5rem',
    },
  },
};
