import {
  POT_BLACK,
  MORE_THAN_A_WEEK,
  WHITE,
  HEROIC_BLUE,
} from '../../Constants/colors';

export const styles = {
  appBar: {
    zIndex: '1201',
    backgroundColor: WHITE,
    display: 'flex',
    position: 'fixed',
    boxShadow: 'none',
  },
  hamBurgerStyle: {
    color: POT_BLACK,
  },
  toolbarStyle: { display: { sm: 'none' } },
  appBarContainer: {
    position: 'relative',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    margin: 0,
    padding: 0,
    paddingRight: '35px',
    height: '70px',
    boxSizing: 'border-box',
    '@media (max-width: 900px)': {
      paddingRight: '10px',
      paddingLeft: '10px',
    },
  },
  profileText: {
    fontWeight: 700,
    fontSize: '14px',
    lineHeight: '19px',
    color: POT_BLACK,
    textTransform: 'capitalize',
    marginLeft: '11px',
    marginRight: '11px',
    '@media (max-width: 600px)': {
      display: 'none',
    },
  },
  dropDownIcon: {
    cursor: 'pointer',
    color: POT_BLACK,
  },
  logoImage: {
    width: '40px',
  },
  logoText: {
    fontSize: '22px',
    color: POT_BLACK,
    textTransform: 'uppercase',
  },
  headerActionWrapper: {
    color: POT_BLACK,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'start',
    textTransform: 'uppercase',
    columnGap: '63px',
    '@media (max-width: 600px)': {
      justifyContent: 'space-between',
      columnGap: '10px',
    },
  },
  headerActionMainContainer: {
    '@media (max-width: 600px)': {
      marginLeft: '-10px',
    },
  },
  toolbar: {
    marginLeft: '-10px',
    gap: '10px',
    '@media (max-width: 600px)': {
      display: 'none',
    },
  },
  profileWrapper: {
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
  },
  endDetailContainer: {
    display: 'flex',
    justifyContent: 'end',
    alignItems: 'center',
    gap: '30px',
  },
  badge: {
    '& .MuiBadge-badge': {
      backgroundColor: HEROIC_BLUE,
    },
  },
  cartIconWrapper: {
    cursor: 'pointer',
  },
  cartIcon: {
    color: POT_BLACK,
  },
  customerType: {
    fontStyle: 'normal',
    fontWeight: 700,
    fontSize: '10px',
    lineHeight: '14px',
    color: MORE_THAN_A_WEEK,
  },
  lastDropDownItem: {
    marginBottom: '0px',
  },
  dropDownItem: {
    height: '49px',
    boxSizing: 'border-box',
    color: POT_BLACK,
    paddingLeft: '24px',
    marginBottom: '5px',
  },
  actionItemContent: {
    fontStyle: 'normal',
    fontWeight: 500,
    fontSize: '16px',
    lineHeight: '16px',
  },
  divider: {
    marginLeft: '16px',
    marginRight: '16px',
    marginBottom: '4px',
    color: MORE_THAN_A_WEEK,
  },
  actionItemContentWrapper: {
    display: 'flex',
    alignItems: 'center',
  },
  dropDownContainer: {
    '.MuiMenu-paper': {
      boxShadow: '-8px 6px 25px 2px rgba(43, 78, 118, 0.23)',
      minWidth: '281px',
      borderRadius: '6px',
    },
    '.MuiMenu-list': {
      paddingTop: '15px',
      paddingBotton: '15px',
    },
    minWidth: '281px',
    marginTop: '70px',
  },
};
