import { useEffect, useState } from 'react';
import { useDispatch, useSelector } from 'react-redux';
import {
  AppBar,
  Toolbar,
  Box,
  Typography,
  Avatar,
  IconButton,
  Divider,
  Badge,
  Drawer,
} from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';

import logoIcon from '../../Assets/Images/logo.svg';
import HeaderActionDropDown from './HeaderActionDropDown';
import Cart from '../Cart/Cart';
import CustomToolTip from '../Widgets/CustomToolTip/CustomToolTip';
import { toggleOrderCart } from '../../Redux/OrderCart/OrderCartSlice';
import { stringAvatar } from '../../Utils/profileAvatar';
import { styles } from './HeaderStyles';

const Header = (props) => {
  const { handleDrawerToggle } = props;

  const dispatch = useDispatch();
  const { data } = useSelector((state) => {
    return state.singleSignOn.singleSignOn;
  });
  const { orderCartData, orderCartToggleData } = useSelector(
    (state) => state.orderCart
  );

  const [anchorElUser, setAnchorElUser] = useState(null);
  const [cartCount, setCartCount] = useState(0);

  const cartToggleHandler = () => {
    dispatch(toggleOrderCart(!orderCartToggleData));
  };

  const cartCloseHandler = () => {
    dispatch(toggleOrderCart(false));
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  useEffect(() => {
    if (orderCartData?.data?.length > 99) {
      setCartCount('99+');
    } else if (orderCartData?.data?.length < 0) {
      setCartCount(0);
    } else {
      setCartCount(orderCartData?.data?.length);
    }
  }, [orderCartData]);

  return (
    <AppBar position="sticky" sx={styles.appBar}>
      <Box sx={styles.appBarContainer}>
        <Toolbar sx={styles.toolbar}>
          <Typography sx={styles.logoImage} component="img" src={logoIcon} />
          <Typography sx={styles.logoText}>Uvation</Typography>
        </Toolbar>
        <Toolbar sx={styles.toolbarStyle}>
          <IconButton
            color="inherit"
            aria-label="open drawer"
            edge="start"
            onClick={handleDrawerToggle}
            sx={styles.hamBurgerStyle}
          >
            <MenuIcon />
          </IconButton>
        </Toolbar>
        <Box sx={styles.endDetailContainer}>
          <CustomToolTip title="My Cart">
            <Box onClick={cartToggleHandler} sx={styles.cartIconWrapper}>
              <Badge badgeContent={cartCount} sx={styles.badge}>
                <AddShoppingCartIcon sx={styles.cartIcon} />
              </Badge>
            </Box>
          </CustomToolTip>
          <Box sx={styles.profileWrapper} onClick={handleOpenUserMenu}>
            <Avatar
              {...stringAvatar(
                data?.idTokenClaims?.given_name
                  ?.trim()
                  .concat(' ', data?.idTokenClaims?.family_name?.trim())
              )}
            />
            <Box sx={styles.profileText}>
              <Typography>{data?.idTokenClaims?.given_name}</Typography>
              <Typography sx={styles.customerType}>Customer</Typography>
            </Box>
            <ExpandMoreIcon sx={styles.dropDownIcon} />
          </Box>
          <HeaderActionDropDown
            anchorElUser={anchorElUser}
            handleCloseUserMenu={handleCloseUserMenu}
          />
        </Box>
      </Box>
      <Divider />
      <Drawer
        anchor="right"
        open={orderCartToggleData}
        onClose={cartCloseHandler}
      >
        <Cart />
      </Drawer>
    </AppBar>
  );
};
export default Header;
