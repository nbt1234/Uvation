import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch } from 'react-redux';
import { toast } from 'react-toastify';
import { Box } from '@mui/material';
import EditIcon from '@mui/icons-material/Edit';
import CloseIcon from '@mui/icons-material/Close';

import CustomButton from '../Widgets/CustomButton/CustomButton';
import CustomLabel from '../Widgets/CustomLabel/CustomLabel';
import CustomInput from '../Widgets/CustomInput/CustomInput';
import CustomLoader from '../Widgets/CustomLoader/CustomLoader';
import { validationHandler } from '../../Utils/validations';
import {
  IS_REQUIRED_STRING_VALIDATION,
  IS_REQUIRED_VALIDATION,
} from '../../Constants/validationConstant';
import {
  IS_REQUIRED_MSG,
  SOMETHING_WENT_WRONG,
  NOT_COMPLETED_SIGNUP,
} from '../../Constants/errorMessages';
import { getItem } from '../../Services/localStorageService';
import { placeOrderService } from '../../Services/orderService';
import {
  addProductToCart,
  toggleOrderCart,
} from '../../Redux/OrderCart/OrderCartSlice';
import { MY_LOYALTY } from '../../Routes/Routes';
import { styles } from './AddressCardStyles';

const initialData = {
  email: '',
  street: '',
  city: '',
  state: '',
  postalCode: '',
  country: '',
  firstName: '',
  lastName: '',
  telephone: '',
};

const AddressCard = (props) => {
  const { orderData } = props;

  const dispatch = useDispatch();
  const navigate = useNavigate();

  const [formData, setFormData] = useState(initialData);
  const [errorData, setErrorData] = useState(initialData);
  const [isLoading, setIsLoading] = useState(false);
  const [isActive, setIsActive] = useState(true);

  useEffect(() => {
    const data = getItem('ssoData');
    setFormData((prevState) => {
      return {
        ...prevState,
        email: data?.idTokenClaims?.email || '',
        firstName: data?.idTokenClaims?.given_name || '',
        lastName: data?.idTokenClaims?.family_name || '',
        telephone: data?.idTokenClaims?.MobileNumber || '',
      };
    });
  }, []);

  useEffect(() => {
    const data = getItem('ssoData');
    if (isActive) {
      setFormData((prevState) => {
        return {
          ...prevState,
          street: data?.idTokenClaims?.streetAddress || '',
          city: data?.idTokenClaims?.city || '',
          state: data?.idTokenClaims?.state || '',
          postalCode: data?.idTokenClaims?.postalCode || '',
          country: data?.idTokenClaims?.country || '',
        };
      });
    }
  }, [isActive]);

  const validationConfig = {
    street: {
      [IS_REQUIRED_STRING_VALIDATION]: {
        errorMsg: IS_REQUIRED_MSG,
      },
    },
    city: {
      [IS_REQUIRED_STRING_VALIDATION]: {
        errorMsg: IS_REQUIRED_MSG,
      },
    },
    state: {
      [IS_REQUIRED_STRING_VALIDATION]: {
        errorMsg: IS_REQUIRED_MSG,
      },
    },
    postalCode: {
      [IS_REQUIRED_VALIDATION]: {
        errorMsg: IS_REQUIRED_MSG,
      },
    },
    country: {
      [IS_REQUIRED_STRING_VALIDATION]: {
        errorMsg: IS_REQUIRED_MSG,
      },
    },
  };

  const toggleEdit = () => {
    setIsActive((prev) => !prev);
  };

  const formValidationHandler = (name, value) => {
    const newFormData = { ...formData, [name]: value };
    validationHandler(newFormData, setErrorData, {
      [name]: validationConfig?.[name],
    });
  };

  const changeHandler = (name, value) => {
    setFormData((prevState) => {
      return { ...prevState, [name]: value };
    });
    if (errorData?.[name] && validationConfig?.[name]) {
      formValidationHandler(name, value);
    }
  };

  const placeOrder = async () => {
    setIsLoading(true);
    const newData = {
      email: formData?.email,
      shippingAddress: {
        firstName: formData?.firstName,
        lastName: formData?.lastName,
        street: formData?.street,
        city: formData?.city,
        state: formData?.state,
        postCode: formData?.postalCode,
        telephone: formData?.telephone,
      },
      orderItems: orderData.map((item) => {
        return { entityId: item.entityId };
      }),
    };
    const response = await placeOrderService(newData);
    if (response?.data) {
      const message = response?.data?.data?.message;
      toast.success(message);
      dispatch(addProductToCart([]));
      dispatch(toggleOrderCart(false));
      navigate(MY_LOYALTY);
    } else if (response?.error) {
      const code = response?.error?.data?.code;
      const message = response?.error?.data?.message;
      if (
        code === 'FREE_ITEM_NOT_FOUND' ||
        code === 'DUPLICATE_PRODUCT_EXISTS'
      ) {
        toast.error(message);
        dispatch(toggleOrderCart(false));
      } else if (
        !formData?.firstName ||
        !formData?.lastName ||
        !formData?.telephone
      ) {
        toast.error(NOT_COMPLETED_SIGNUP);
        dispatch(toggleOrderCart(false));
      } else {
        toast.error(SOMETHING_WENT_WRONG);
        dispatch(toggleOrderCart(false));
      }
    }
    setIsLoading(false);
  };

  const submitHandler = () => {
    if (validationHandler(formData, setErrorData, validationConfig)) {
      placeOrder();
    }
  };

  return (
    <Box sx={styles.mainContainer}>
      {isLoading ? (
        <CustomLoader />
      ) : (
        <>
          <Box sx={styles.formWrapper}>
            {/* edit or reset btn */}
            <Box sx={styles.editBtnWrapper}>
              <CustomButton
                endIcon={isActive ? <EditIcon /> : <CloseIcon />}
                textContent={isActive ? 'Edit' : 'Reset'}
                type={isActive ? 'detail' : 'reset'}
                clickHandler={toggleEdit}
                customStyles={styles.editBtn}
              />
            </Box>
            {/* address */}
            <Box sx={styles.inputWrapper}>
              <CustomLabel labelText="Address" isRequired />
              <CustomInput
                name="street"
                value={formData?.street}
                setValue={changeHandler}
                errorMsg={errorData?.street}
                isDisabled={isActive}
              />
            </Box>
            {/* city */}
            <Box sx={styles.inputWrapper}>
              <CustomLabel labelText="City" isRequired />
              <CustomInput
                name="city"
                value={formData?.city}
                setValue={changeHandler}
                errorMsg={errorData?.city}
                isDisabled={isActive}
              />
            </Box>
            {/* state */}
            <Box sx={styles.inputWrapper}>
              <CustomLabel labelText="State" isRequired />
              <CustomInput
                name="state"
                value={formData?.state}
                setValue={changeHandler}
                errorMsg={errorData?.state}
                isDisabled={isActive}
              />
            </Box>
            {/* postal code */}
            <Box sx={styles.inputWrapper}>
              <CustomLabel labelText="Postal Code" isRequired />
              <CustomInput
                name="postalCode"
                value={formData?.postalCode}
                setValue={changeHandler}
                errorMsg={errorData?.postalCode}
                isDisabled={isActive}
              />
            </Box>
            {/* country */}
            <Box sx={styles.inputWrapper}>
              <CustomLabel labelText="Country" isRequired />
              <CustomInput
                name="country"
                value={formData?.country}
                setValue={changeHandler}
                errorMsg={errorData?.country}
                isDisabled={isActive}
              />
            </Box>
          </Box>
          {/* btn */}
          <Box sx={styles.btnWrapper}>
            <CustomButton
              textContent="Order"
              type="proceed"
              btnType="save"
              customStyles={styles.btn}
              customBtnWrapperStyles={styles.customBtnWrapper}
              clickHandler={submitHandler}
            />
          </Box>
        </>
      )}
    </Box>
  );
};

export default AddressCard;
