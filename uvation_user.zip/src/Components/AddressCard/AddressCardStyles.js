import { WHITE } from '../../Constants/colors';
import { commonStyles } from '../../Assets/Styles/commonStyles';

export const styles = {
  mainContainer: {
    width: '100%',
    display: 'flex',
    flexDirection: 'column',
    position: 'relative',
    height: '100%',
  },
  formWrapper: {
    padding: '20px 10px',
    overflowY: 'auto',
    ...commonStyles.customScrollBar,
    flex: '1',
    marginBottom: '80px',
  },
  inputWrapper: {
    width: '100%',
    marginBottom: '10px',
  },
  editBtnWrapper: {
    display: 'flex',
    justifyContent: 'flex-end',
    marginBottom: '10px',
  },
  editBtn: {
    fontSize: '16px',
  },
  btnWrapper: {
    position: 'sticky',
    bottom: '0px',
    backgroundColor: WHITE,
    width: '100%',
    minHeight: '70px',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btn: {
    width: 'calc(100% - 22px)',
  },
  customBtnWrapper: {
    width: '100%',
  },
};
