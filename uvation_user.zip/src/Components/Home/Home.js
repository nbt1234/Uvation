/* eslint-disable react/jsx-filename-extension */
/* eslint-disable react/self-closing-comp */
// import React from 'react';
import UiHeader from '../Header/UiHeader';

const Home = (props) => {
  const { handleDrawerToggle } = props;

  return (
    <div>
      <UiHeader handleDrawerToggle={handleDrawerToggle} />
    </div>
  );
};

export default Home;
