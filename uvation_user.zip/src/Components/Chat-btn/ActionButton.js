/* eslint-disable react/jsx-filename-extension */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/button-has-type */
/* eslint-disable react/prefer-stateless-function */
import { Component } from 'react';

class ActionButton extends Component {
  render() {
    return (
      <button
        className={`action-button ${this.props.addClass}`}
        onClick={this.props.onClick}
      >
        {this.props.label}
      </button>
    );
  }
}

ActionButton.displayName = 'ActionButton';

export default ActionButton;
