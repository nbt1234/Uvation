/* eslint-disable react/prefer-stateless-function */
/* eslint-disable react/jsx-filename-extension */
/* eslint-disable react/destructuring-assignment */
import { Component } from 'react';

class ChatImage extends Component {
  render() {
    return (
      <a
        href={this.props.message.attachment.url}
        className="chat-img-container"
      >
        <div
          className="chat-img"
          style={{
            backgroundImage: `url(${this.props.message.attachment.url})`,
          }}
        />
      </a>
    );
  }
}

ChatImage.displayName = 'ChatImage';

ChatImage.defaultProps = {
  message: {
    url: '',
  },
};

export default ChatImage;
