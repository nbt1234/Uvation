/* eslint-disable jsx-a11y/label-has-associated-control */
/* eslint-disable react/jsx-filename-extension */
/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/no-string-refs */
/* eslint-disable react/sort-comp */
import { Component } from 'react';
import ReactCSSTransitionGroup from 'react-addons-css-transition-group';
import * as zChat from 'zendesk-chat-sdk';

import CardContainer from './CardContainer';
import MessageSvg from './MessageSvg';
import ActionButton from './ActionButton';

class OfflineForm extends Component {
  componentDidMount() {
    this.state.sfullname = localStorage.getItem('supportusername');
    this.state.sufullemail = localStorage.getItem('supportusermail');
  }
  // eslint-disable-next-line lines-between-class-members
  constructor(props) {
    super(props);
    this.state = {
      sent: false,
    };
    this.send = this.send.bind(this);
    this.sendAnother = this.sendAnother.bind(this);
    this.renderChild = this.renderChild.bind(this);
  }

  send(event) {
    event.preventDefault();

    // Use HTML form validation to validate inputs
    // eslint-disable-next-line prefer-destructuring
    const form = this.refs.form;
    if (!form.checkValidity()) {
      form.reportValidity();
      return;
    }

    zChat.sendOfflineMsg(
      {
        name: this.refs.name.value,
        email: this.refs.email.value,
        message: this.refs.message.value,
      },
      (err) => {
        if (err) return;
        this.setState({
          sent: true,
        });
      }
    );
  }

  sendAnother() {
    this.setState({
      sent: false,
    });
  }

  renderChild() {
    if (this.state.sent) {
      return (
        <div key="sent" className="offline-sent">
          Your message has been sent. We will get back to you as soon as
          possible.
          <ActionButton
            addClass="button-resend"
            label="Send another"
            onClick={this.sendAnother}
          />
        </div>
      );
    } else {
      return (
        <form ref="form" key="not-sent" className="offline-form">
          <div className="content">
            <div className="section">
              <label className="label">Name</label>
              <input
                ref="name"
                maxLength="255"
                value={this.state.sfullname}
                disabled
              />
            </div>
            <div className="section">
              <label className="label">Email</label>
              <input
                ref="email"
                pattern={`${zChat.EMAIL_REGEX.source}`}
                value={this.state.sufullemail}
                disabled
              />
            </div>
            <div className="section">
              <label className="label">Message</label>
              <textarea required ref="message" />
            </div>
          </div>
          <div className="button-container">
            <ActionButton
              addClass="button-send"
              label="Send"
              onClick={this.send}
            />
          </div>
        </form>
      );
    }
  }

  render() {
    return (
      <CardContainer
        addClass="offline-card"
        contentAddClass={this.state.sent ? 'sent' : ''}
        icon={<MessageSvg />}
      >
        <ReactCSSTransitionGroup
          className="offline-container"
          transitionName={this.state.sent ? 'offline-shrink' : 'offline-grow'}
          transitionEnterTimeout={250}
          transitionLeaveTimeout={250}
        >
          {this.renderChild()}
        </ReactCSSTransitionGroup>
      </CardContainer>
    );
  }
}

OfflineForm.displayName = 'OfflineForm';

export default OfflineForm;
