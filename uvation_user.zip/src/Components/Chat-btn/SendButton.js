/* eslint-disable react/destructuring-assignment */
/* eslint-disable react/jsx-filename-extension */
/* eslint-disable jsx-a11y/no-static-element-interactions */
/* eslint-disable jsx-a11y/click-events-have-key-events */
/* eslint-disable react/prefer-stateless-function */
/* eslint-disable react/self-closing-comp */
import { Component } from 'react';

class SendButton extends Component {
  // constructor(props) {
  //   super(props);
  // }

  render() {
    return (
      <div
        className={`send-button ${this.props.addClass || ''}`}
        onClick={this.props.onClick}
      >
        {/* <svg width='24' height='24' viewBox='0 0 32 32'>
          <path
            transform='rotate(315deg)'
            // d='M3 6L0 0c-.056.14 12 6 12 6L0 13c.053.083 3-7 3-7z'
            d='M27.71,4.29a1,1,0,0,0-1.05-.23l-22,8a1,1,0,0,0,0,1.87l8.59,3.43L19.59,11,21,12.41l-6.37,6.37,3.44,8.59A1,1,0,0,0,19,28h0a1,1,0,0,0,.92-.66l8-22A1,1,0,0,0,27.71,4.29Z'
            fill='#0F61FD'
            fillRule='evenodd'
          />
        </svg> */}
        <svg
          focusable="false"
          preserveAspectRatio="xMidYMid meet"
          xmlns="http://www.w3.org/2000/svg"
          fill="#0F61FD"
          width="20"
          height="20"
          viewBox="0 0 32 32"
          aria-hidden="true"
        >
          <path d="M27.71,4.29a1,1,0,0,0-1.05-.23l-22,8a1,1,0,0,0,0,1.87l8.59,3.43L19.59,11,21,12.41l-6.37,6.37,3.44,8.59A1,1,0,0,0,19,28h0a1,1,0,0,0,.92-.66l8-22A1,1,0,0,0,27.71,4.29Z"></path>
        </svg>
      </div>
    );
  }
}

SendButton.displayName = 'SendButton';

export default SendButton;
