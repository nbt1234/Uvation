import { Card, Typography, Box } from '@mui/material';

const SingleCard = (props) => {
  const {
    id,
    cardContainerStyles,
    cardStyles,
    cardImgStyles,
    cardMainTextStyles,
    iconStyles,
    handleClick,
    icon,
    cardImg,
    imageContainer,
    cardMainText,
    cardSubText,
    cardSubTextStyles,
    textContainer,
  } = props;

  return (
    <Box sx={cardContainerStyles} id={id}>
      <Card sx={cardStyles} onClick={() => handleClick(id)}>
        <Box sx={imageContainer}>
          <Typography
            component="img"
            src={cardImg}
            alt="category"
            sx={cardImgStyles}
          />
        </Box>
        <Box sx={textContainer}>
          <Typography sx={cardMainTextStyles}>{cardMainText}</Typography>
          <Typography sx={cardSubTextStyles}>{cardSubText}</Typography>
        </Box>
      </Card>
      {icon && (
        <Typography component="img" src={icon} alt="selected" sx={iconStyles} />
      )}
    </Box>
  );
};

export default SingleCard;
