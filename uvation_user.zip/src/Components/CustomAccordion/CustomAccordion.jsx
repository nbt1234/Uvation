import {
  Accordion,
  AccordionSummary,
  Typography,
  AccordionDetails,
} from '@mui/material';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';

import { styles } from './CustomAccordionStyles';

const CustomAccordion = (props) => {
  const { title, children, customStyles } = props;

  return (
    <Accordion sx={{ ...styles.accordionContainer, ...customStyles }}>
      <AccordionSummary
        expandIcon={<ExpandMoreIcon />}
        aria-controls="panel1a-content"
      >
        <Typography sx={styles.accordionTitle}>{title}</Typography>
      </AccordionSummary>
      <AccordionDetails>{children}</AccordionDetails>
    </Accordion>
  );
};

export default CustomAccordion;
