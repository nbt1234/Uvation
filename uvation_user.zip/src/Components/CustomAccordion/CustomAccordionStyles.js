import { LIGHTHOUSE } from '../../Constants/colors';

export const styles = {
  accordionContainer: {
    backgroundColor: LIGHTHOUSE,
    boxShadow: 'none',
    border: 'none',
    '&:before': {
      backgroundColor: 'transparent !important',
    },
  },
  accordionTitle: {
    fontSize: '16px',
    fontWeight: '500',
    letterSpacing: '0.18px',
  },
};
