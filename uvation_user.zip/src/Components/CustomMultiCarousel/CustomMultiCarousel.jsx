/* eslint-disable react/no-array-index-key */
/* eslint-disable no-nested-ternary */
import { useState, useRef, useEffect, useCallback } from 'react';
import Carousel, { consts } from 'react-elastic-carousel';
import { Typography, Box } from '@mui/material';

// eslint-disable-next-line import/no-cycle
import UtilityModal from '../UtilityModal/UtilityModal';
import noImage from '../../Assets/Images/No_Image_Available.jpg';
import chevronLeft from '../../Assets/Images/chevronLeft.svg';
import chevronRight from '../../Assets/Images/chevronRight.svg';
import { styles } from './CustomMultiCarouselStyles';
import './CustomMultiCarousel.css';

const breakPoints = [
  { width: 1, itemsToShow: 1 },
  { width: 400, itemsToShow: 2 },
  { width: 568, itemsToShow: 3 },
];
const newBreakPoints = [
  { width: 600, itemsToShow: 1 },
  { width: 900, itemsToShow: 1 },
];
const galleryBreakPoints = [
  { width: 1, itemsToShow: 1 },
  { width: 450, itemsToShow: 2 },
];

const CustomMultiCarousel = (props) => {
  const {
    size,
    photos,
    defaultSelectedPhotoPosition,
    preventOnImageClick,
    galleryPreview,
  } = props;
  const carouselRef = useRef(null);
  const [imageModal, setImageModal] = useState(false);
  const [selectedPhotoIndex, setSelectedPhotoIndex] = useState(0);

  useEffect(() => {
    if (defaultSelectedPhotoPosition) {
      setSelectedPhotoIndex(defaultSelectedPhotoPosition);
    }
  }, [defaultSelectedPhotoPosition]);

  useEffect(() => {
    if (carouselRef && carouselRef.current && selectedPhotoIndex) {
      carouselRef.current.goTo(selectedPhotoIndex);
    }
  }, [selectedPhotoIndex]);

  const goToSpecifiedChild = (childIndex) => {
    if (carouselRef && carouselRef.current) {
      carouselRef.current.goTo(childIndex || 0);
    }
  };

  const changeChild = useCallback(
    (e) => {
      if (e.key === 'ArrowLeft') {
        if (selectedPhotoIndex - 1 >= 0) {
          goToSpecifiedChild(selectedPhotoIndex - 1);
          setSelectedPhotoIndex(selectedPhotoIndex - 1);
        }
      } else if (e.key === 'ArrowRight') {
        if (selectedPhotoIndex + 1 < photos.length) {
          goToSpecifiedChild(selectedPhotoIndex + 1);
          setSelectedPhotoIndex(selectedPhotoIndex + 1);
        }
      }
    },
    [selectedPhotoIndex, photos]
  );

  useEffect(() => {
    document.addEventListener('keydown', changeChild);

    return function cleanup() {
      document.removeEventListener('keydown', changeChild);
    };
  });

  function myArrow({ type, onClick, isEdge }) {
    const pointer =
      type === consts.PREV ? (
        <Typography component="img" src={chevronLeft} />
      ) : (
        <Typography component="img" src={chevronRight} />
      );

    if (isEdge) {
      return (
        <Box sx={styles.disabledArrowCarousel}>
          <Box>{pointer}</Box>
        </Box>
      );
    } else {
      return (
        <Box sx={styles.enabledArrowContainer}>
          <Box onClick={onClick} sx={styles.enabledArrowCarousel}>
            {pointer}
          </Box>
        </Box>
      );
    }
  }

  const breakPointsData = () => {
    if (size === 'large') {
      return newBreakPoints;
    } else if (galleryPreview) {
      return galleryBreakPoints;
    } else {
      return breakPoints;
    }
  };

  const imageStyle = () => {
    if (size === 'large') {
      return styles.largeImage;
    } else if (galleryPreview) {
      return styles.galleryImage;
    } else {
      return styles.rectangleImage;
    }
  };

  return (
    <>
      {imageModal && (
        <UtilityModal
          openModal={imageModal}
          setCloseModal={setImageModal}
          selectedPhotoIndex={selectedPhotoIndex}
          photos={photos}
        />
      )}
      <Carousel
        ref={carouselRef}
        itemPosition={consts.CENTER}
        breakPoints={breakPointsData()}
        showArrows={photos?.length > 1}
        renderArrow={galleryPreview ? myArrow : null}
      >
        {photos.length > 0 &&
          photos.map((item, idx) => {
            return (
              <Box sx={styles.imageBox} key={idx}>
                <Typography
                  key={idx}
                  onClick={() => {
                    if (!preventOnImageClick) {
                      setImageModal(true);
                      setSelectedPhotoIndex(idx);
                    }
                  }}
                  sx={imageStyle}
                  component="img"
                  src={item}
                  alt="image"
                />
              </Box>
            );
          })}
        {photos.length === 0 && (
          <Typography
            sx={styles.rectangleImage}
            component="img"
            src={noImage}
            alt="image"
          />
        )}
      </Carousel>
    </>
  );
};

export default CustomMultiCarousel;
