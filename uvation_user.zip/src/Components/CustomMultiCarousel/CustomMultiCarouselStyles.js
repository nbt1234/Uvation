import { UP_IN_SMOKE, WHITE } from '../../Constants/colors';

export const styles = {
  imageBox: {
    display: 'flex',
    alignItems: 'center',
  },
  rectangleImage: {
    width: '175px',
    height: '134px',
    objectFit: 'contain',
    backgroundColor: WHITE,
    cursor: 'pointer',
  },
  largeImage: {
    maxWidth: '100%',
    maxHeight: 'calc(100vh - 100px)',
    textAlign: 'center',
    marginTop: '5%',
    '@media (max-width : 600px)': {
      maxWidth: '100%',
    },
  },
  galleryImage: {
    width: '213px',
    height: '150px',
    borderRadius: '0px',
    objectFit: 'contain',
    backgroundColor: WHITE,
    cursor: 'pointer',
  },
  modal: {
    backgroundColor: UP_IN_SMOKE,
  },
  disabledArrowCarousel: {
    display: 'flex',
    alignItems: 'center',
    cursor: 'not-allowed',
  },
  enabledArrowContainer: {
    display: 'flex',
    alignItems: 'center',
  },
  enabledArrowCarousel: {
    cursor: 'pointer',
  },
};
