import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Box, Typography } from '@mui/material';
import ShoppingBasketIcon from '@mui/icons-material/ShoppingBasket';

import CustomButton from '../Widgets/CustomButton/CustomButton';
import CartItem from './CartItem/CartItem';
import AddressCard from '../AddressCard/AddressCard';
import { styles } from './CartStyles';

const Cart = () => {
  const [isAddressVisible, setIsAddressVisible] = useState(false);
  const [totalPoints, setTotalPoints] = useState(0);

  const { orderCartData } = useSelector((state) => state.orderCart);

  useEffect(() => {
    let points = 0;
    if (orderCartData?.data?.length) {
      points = orderCartData?.data?.reduce(
        (total, obj) => obj.loyaltyCardPoints + total,
        0
      );
    }
    setTotalPoints(points);
  }, [orderCartData]);

  const proceedClickHandler = () => {
    setIsAddressVisible(true);
  };

  return (
    <Box sx={styles.mainContainer}>
      <Box sx={styles.headingWrapper}>
        <Box sx={styles.titleWrapper}>
          <Typography sx={styles.heading}>
            {isAddressVisible ? 'Shipping Address' : 'Your Cart'}
          </Typography>
          {!isAddressVisible && <ShoppingBasketIcon />}
        </Box>
        <Box>
          <Typography sx={styles.pointsText}>
            Total Points:{' '}
            <Typography component="span" sx={styles.pointsSubText}>
              {totalPoints}
            </Typography>
          </Typography>
        </Box>
      </Box>
      {!isAddressVisible && (
        <Box sx={styles.itemWrapper}>
          <Box sx={styles.cardItemWrapper}>
            {orderCartData?.data?.length === 0 && (
              <Box sx={styles.emptyImgWrapper}>
                <Typography
                  sx={styles.emptyImg}
                  component="img"
                  src="https://cdni.iconscout.com/illustration/free/thumb/empty-cart-4085814-3385483.png"
                />
              </Box>
            )}
            {orderCartData?.data?.map((item) => {
              return <CartItem data={item} key={item.id} />;
            })}
          </Box>
          <Box sx={styles.btnWrapper}>
            <CustomButton
              textContent="Proceed"
              type="proceed"
              customStyles={styles.btn}
              customBtnWrapperStyles={styles.customBtnWrapper}
              disabled={orderCartData?.data?.length === 0}
              clickHandler={proceedClickHandler}
            />
          </Box>
        </Box>
      )}
      {isAddressVisible && (
        <Box sx={styles.addressWrapper}>
          <AddressCard orderData={orderCartData?.data} />
        </Box>
      )}
    </Box>
  );
};

export default Cart;
