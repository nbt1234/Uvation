import { WHITE } from '../../Constants/colors';
import { commonStyles } from '../../Assets/Styles/commonStyles';

export const styles = {
  mainContainer: {
    marginTop: '71px',
    height: '100%',
    backgroundColor: WHITE,
    overflowY: 'hidden',
    position: 'relative',
    display: 'flex',
    flexDirection: 'column',
    width: '450px',
    '@media(max-width:450px)': {
      width: '100%',
    },
  },
  headingWrapper: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '1rem',
    columnGap: '55px',
  },
  heading: {
    fontSize: '24px',
    fontWeight: '500',
  },
  titleWrapper: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'start',
    gap: '10px',
  },
  pointsText: {
    fontSize: '18px',
    fontWeight: '500',
    textAlign: 'right',
  },
  pointsSubText: {
    fontSize: '18px',
  },
  itemWrapper: {
    overflowY: 'auto',
    ...commonStyles.customScrollBar,
    flex: '1',
    display: 'flex',
    flexDirection: 'column',
  },
  cardItemWrapper: {
    flex: 1,
  },
  addressWrapper: {
    height: '100%',
  },
  emptyImgWrapper: {
    height: '100%',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  emptyImg: {
    marginBottom: '70px',
    maxWidth: '350px',
  },
  btnWrapper: {
    position: 'sticky',
    bottom: '0px',
    backgroundColor: WHITE,
    width: '100%',
    minHeight: '70px',
    textAlign: 'center',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  btn: {
    width: '90%',
  },
  customBtnWrapper: {
    width: '100%',
  },
};
