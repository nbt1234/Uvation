import { Box, Typography } from '@mui/material';
import { useDispatch } from 'react-redux';

import CustomButton from '../../Widgets/CustomButton/CustomButton';
import { removeProductFromCart } from '../../../Redux/OrderCart/OrderCartSlice';
import { styles } from './CartItemStyles';

const CartItem = (props) => {
  const { data } = props;

  const dispatch = useDispatch();

  const removeHandler = () => {
    dispatch(removeProductFromCart({ id: data?.id }));
  };

  return (
    <Box sx={styles.mainContainer}>
      <Typography
        component="img"
        src={data.productImage}
        sx={styles.productImage}
      />
      <Box sx={styles.productDetail}>
        <Box>
          <Typography sx={styles.productName}>{data.productName}</Typography>
          <Typography sx={styles.productCode}>{data?.productCode}</Typography>
        </Box>
        <Box sx={styles.btnWrapper}>
          <Typography sx={styles.productPoints}>
            {data.loyaltyCardPoints}
            <Typography component="span"> points</Typography>
          </Typography>
          <CustomButton
            textContent="Remove"
            type="save"
            customStyles={styles.removeBtn}
            clickHandler={removeHandler}
          />
        </Box>
      </Box>
    </Box>
  );
};

export default CartItem;
