import { PORPOISE, MORE_THAN_A_WEEK } from '../../../Constants/colors';

export const styles = {
  mainContainer: {
    width: '90%',
    margin: 'auto',
    display: 'flex',
    borderTop: `1px solid ${PORPOISE}`,
    padding: '20px 10px',
    maxWidth: '450px',
  },
  productImage: {
    width: '25%',
    objectFit: 'contain',
    height: '140px',
    minWidth: '110px',
  },
  productDetail: {
    width: '100%',
    margin: '10px 15px',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'space-between',
    gap: '20px',
  },
  productName: {
    fontSize: '18px',
    fontWeight: '500',
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    // Addition lines for 2 line or multiline ellipsis
    display: '-webkit-box !important',
    webkitLineClamp: '2',
    webkitBoxOrient: 'vertical',
    whiteSpace: 'normal',
    wordBreak: 'break-all',
  },
  productCode: {
    fontSize: '16px',
    color: MORE_THAN_A_WEEK,
  },
  productPoints: {
    fontSize: '14px',
  },
  btnWrapper: {
    width: '100%',
    display: 'flex',
    flexDirection: 'row',
    justifyContent: 'space-between',
    gap: '50px',
  },

  removeBtn: {
    height: '30px',
  },
};
