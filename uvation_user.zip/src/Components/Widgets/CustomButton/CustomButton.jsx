import { Button, Typography, Box } from '@mui/material';

import CustomLoader from '../CustomLoader/CustomLoader';
import { styles } from './CustomButtonStyles';

const CustomButton = (props) => {
  const {
    type,
    textContent,
    buttonType = 'button',
    clickHandler,
    isLoading,
    disabled,
    endIcon,
    errorMessage,
    variant = 'contained',
    customStyles = {},
    customBtnWrapperStyles = {},
  } = props;
  return (
    <Box sx={customBtnWrapperStyles}>
      {errorMessage && (
        <Typography sx={styles.errorStyle}>{errorMessage}</Typography>
      )}
      <Button
        sx={{
          ...styles.basicBtn,
          ...(type === 'detail' && styles.detailBtn),
          ...(type === 'proceed' && styles.proceedBtn),
          ...(type === 'send' && {
            ...styles.proceedBtn,
            ...styles.sendBtn,
          }),
          ...(type === 'save' && styles.saveBtn),
          ...(type === 'submit' && styles.submitBtn),
          ...(type === 'cancel' && styles.cancelBtn),
          ...(type === 'reset' && styles.resetBtn),
          ...(isLoading && styles.loadingBtn),
          ...customStyles,
        }}
        variant={variant}
        disableElevation
        disableRipple
        disabled={disabled}
        onClick={clickHandler}
        endIcon={endIcon}
        type={buttonType}
      >
        {!isLoading ? (
          textContent
        ) : (
          <CustomLoader customStyles={styles.btnLoader} />
        )}
      </Button>
    </Box>
  );
};

export default CustomButton;
