import { styled, TableCell, tableCellClasses, TableRow } from '@mui/material';

import { COLD_MORNING, POT_BLACK } from '../../../Constants/colors';
import { commonStyles } from '../../../Assets/Styles/commonStyles';

export const StyledTableCell = styled(TableCell)(({ theme }) => ({
  [`&.${tableCellClasses.head}`]: {
    backgroundColor: theme.palette.common.white,
    color: POT_BLACK,
    borderTop: `1px solid ${COLD_MORNING}`,
  },
  [`&.${tableCellClasses.body}`]: {
    fontSize: 14,
    color: POT_BLACK,
    backgroundColor: theme.palette.common.white,
  },
}));

export const StyledTableRow = styled(TableRow)(({ theme }) => ({
  backgroundColor: theme.palette.action.white,
}));

export const styles = {
  mainContainer: {
    width: 'calc(100vw - 332px)',
    margin: '2rem',
    '@media (max-width:600px)': {
      width: 'calc(100vw - 1.5rem)',
      margin: '0.5rem',
      marginTop: '1.5rem',
    },
  },
  mainHeader: {
    marginBottom: '10px',
    display: 'flex',
    alignItems: 'center',
  },
  mainSubHeader: {
    marginTop: '15px',
  },
  subHeaderWrapper: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  mainHeaderStyle: {
    fontSize: '24px',
    lineHeight: '20px',
  },
  mainSubHeaderStyle: {
    fontSize: '20px',
    lineHeight: '20px',
  },
  recordCountStyle: {
    display: 'flex',
    height: '100%',
    flexDirection: 'column',
    justifyContent: 'flex-end',
  },
  paperStyle: {
    boxShadow: 'none ',
    marginTop: '30px',
    '@media (max-width:600px)': {
      marginTop: '1.5rem',
    },
  },
  tableStyle: {
    width: '100%',
    maxHeight: 'calc(100vh - 240px)',
    boxShadow: 'none',
    borderRadius: '0px',
    ...commonStyles.customScrollBar,
    '& .MuiPaper-root': {
      boxShadow: 'none ',
    },
  },
  tableMainStyle: {
    minWidth: '700px',
  },
  loaderErrorContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    flexDirection: 'column',
  },
  loaderContainer: {
    position: 'relative',
    height: '319px',
  },
  imageLoaderError: {
    top: '30%',
  },
  imageStyleText: {
    color: POT_BLACK,
    marginTop: '10px',
    display: 'flex',
    justifyContent: 'center',
    width: '80%',
    maxWidth: '500px',
    textAlign: 'center',
  },
  errorStyle: {
    fontSize: '25px',
    fontWeight: '600',
  },
  paginationBox: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '1.25rem 0px',
  },
  mainHeadContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
};
