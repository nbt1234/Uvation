/* eslint-disable no-unsafe-optional-chaining */
import { useState, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import {
  Box,
  TableContainer,
  Table,
  TableHead,
  TableBody,
  TableRow,
  Paper,
  Typography,
  TableCell,
  TablePagination,
  IconButton,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';

import CustomTableRow from '../CustomTableRow/CustomTableRow';
import CustomLoader from '../CustomLoader/CustomLoader';
import EmptyImage from '../../../Assets/Images/empty.svg';
import CustomButton from '../CustomButton/CustomButton';
import { urlservice } from '../../../Services/urlService';
import { SOMETHING_WENT_WRONG } from '../../../Constants/errorMessages';
import { StyledTableCell, StyledTableRow, styles } from './CustomTableStyles';
import { ROW_PER_PAGE_OPTIONS } from '../../../Constants/constants';
import { commonStyles } from '../../../Assets/Styles/commonStyles';

const CustomTable = (props) => {
  const {
    tableData,
    metaData,
    hidePagination,
    totalCount,
    dispatchFunction,
    isLoading,
    isError,
    isSuccess,
    pageHeading,
    selected,
    setSelected,
    customPaperStyle,
    pageSubHeading,
    headerChildren,
    customTableStyle,
    customTextHeadingStyle,
    actionButtonText,
    onActionButtonClick,
    customTableCellStyle,
    remainingLoyaltyPoints,
    comparisionKey,
    styleData,
    showCount,
    backNavigationHandler,
    showCustomError,
  } = props;

  const [tableQueryParams, setTableQueryParams] = useState(() =>
    urlservice.getTableQueryParams(hidePagination)
  );

  const dispatch = useDispatch();

  const handleChangePage = (event, newPage) => {
    setTableQueryParams((prev) => {
      return {
        ...prev,
        page: newPage + 1,
      };
    });
  };

  const handleChangeRowsPerPage = (event) => {
    setTableQueryParams((prev) => {
      return {
        ...prev,
        rowsPerPage: parseInt(event.target.value, 10),
        page: 1,
      };
    });
  };

  const getPaginationCount = () => {
    return Math.ceil(totalCount / +tableQueryParams.rowsPerPage);
  };

  const handleDispatch = () => {
    if (hidePagination) {
      dispatch(dispatchFunction());
      return;
    }
    const paginationParams = {
      limit: tableQueryParams?.rowsPerPage,
      skip: (tableQueryParams.page - 1) * tableQueryParams.rowsPerPage || 0,
    };

    if (dispatchFunction) {
      dispatch(
        dispatchFunction({
          ...(!hidePagination && paginationParams),
        })
      );
    }
  };

  useEffect(() => {
    const newTableParams = { ...tableQueryParams };
    if (dispatchFunction) {
      handleDispatch();
    }
    urlservice.setQueryParameters({ ...newTableParams });
  }, [tableQueryParams]);

  useEffect(() => {
    if (totalCount && !hidePagination) {
      if (+tableQueryParams.page > getPaginationCount()) {
        setTableQueryParams((prev) => {
          return { ...prev, page: 1 };
        });
      }
    }
  }, [totalCount]);

  const displayNoData = () => {
    if (isLoading) {
      return <CustomLoader />;
    } else if (isError) {
      return (
        <Box>
          <Typography sx={styles.errorStyle}>{SOMETHING_WENT_WRONG}</Typography>
        </Box>
      );
    } else if (totalCount === 0) {
      return (
        <>
          <Typography component="img" src={EmptyImage} />
          <Typography sx={styles.imageStyleText}>
            {showCustomError || `It's empty in here`}
          </Typography>
        </>
      );
    }
    return null;
  };

  return (
    <Box sx={{ ...styles.mainContainer, ...styleData }}>
      <Box sx={styles.mainHeadContainer}>
        {pageHeading && (
          <Box sx={styles.mainHeader}>
            {backNavigationHandler && (
              <IconButton disableRipple onClick={backNavigationHandler}>
                <ArrowBackIcon />
              </IconButton>
            )}
            <Typography sx={styles.mainHeaderStyle}>{pageHeading}</Typography>
          </Box>
        )}
        {actionButtonText && (
          <CustomButton
            type="proceed"
            textContent={actionButtonText}
            clickHandler={onActionButtonClick}
          />
        )}
      </Box>
      {headerChildren && <Box>{headerChildren}</Box>}
      <Box sx={styles.subHeaderWrapper}>
        <Box>
          {pageSubHeading && (
            <Box sx={styles.mainSubHeader}>
              <Typography sx={styles.mainSubHeaderStyle}>
                {pageSubHeading}
              </Typography>
            </Box>
          )}
        </Box>
        <Box>
          {showCount && (
            <Box sx={styles.recordCountStyle}>
              <Typography>
                {totalCount >= 0 ? (
                  <Typography sx={commonStyles.textBold} component="span">
                    {totalCount} &nbsp;
                  </Typography>
                ) : (
                  'No'
                )}
                {totalCount <= 1 ? 'record' : 'records'} found
              </Typography>
            </Box>
          )}
        </Box>
      </Box>
      <Paper sx={{ ...styles.paperStyle, ...customPaperStyle }}>
        <TableContainer
          sx={{ ...styles.tableStyle, ...customTableStyle }}
          component={Paper}
        >
          <Table sx={styles.tableMainStyle} stickyHeader>
            <TableHead>
              <StyledTableRow>
                {metaData.map((item) => (
                  <StyledTableCell
                    align={item?.align || 'left'}
                    key={item?.keyId}
                    width={item?.width}
                    sx={{ ...customTableCellStyle }}
                  >
                    <Typography
                      sx={{
                        ...commonStyles.commonTextStyle,
                        ...customTextHeadingStyle,
                      }}
                    >
                      {item?.headingName}
                    </Typography>
                  </StyledTableCell>
                ))}
              </StyledTableRow>
            </TableHead>
            <TableBody
              sx={{
                ...((isLoading || isError || !+totalCount) &&
                  styles.loaderContainer),
              }}
            >
              {(isLoading || isError || totalCount === 0) && (
                <TableRow sx={{ position: 'relative' }}>
                  <TableCell
                    colSpan={metaData?.length}
                    sx={{ position: 'relative' }}
                  >
                    <Box
                      sx={{
                        ...styles.loaderErrorContainer,
                        ...(!(isLoading || isError) &&
                          !+totalCount &&
                          styles.imageLoaderError),
                      }}
                    >
                      {displayNoData()}
                    </Box>
                  </TableCell>
                </TableRow>
              )}
              {isSuccess &&
                tableData?.map((item) => (
                  <CustomTableRow
                    metaData={metaData}
                    tableRowData={item}
                    key={item[metaData?.[0]?.mappingId]}
                    selected={selected}
                    setSelected={setSelected}
                    remainingLoyaltyPoints={remainingLoyaltyPoints}
                    isDisableRow={
                      remainingLoyaltyPoints < item?.[comparisionKey]
                    }
                  />
                ))}
            </TableBody>
          </Table>
        </TableContainer>
        {!hidePagination && +totalCount ? (
          <TablePagination
            rowsPerPageOptions={ROW_PER_PAGE_OPTIONS}
            component="div"
            count={totalCount}
            rowsPerPage={tableQueryParams?.rowsPerPage}
            page={tableQueryParams?.page - 1}
            onPageChange={handleChangePage}
            onRowsPerPageChange={handleChangeRowsPerPage}
          />
        ) : null}
      </Paper>
    </Box>
  );
};

export default CustomTable;
