import { WHITE, MORE_THAN_A_WEEK } from '../../../Constants/colors';

export const styles = {
  customToolTip: {
    backgroundColor: MORE_THAN_A_WEEK,
    color: WHITE,
    padding: '8px 10px',
    border: `1px solid ${MORE_THAN_A_WEEK}`,
  },
  toolTipWrapper: {
    cursor: 'pointer',
  },
};
