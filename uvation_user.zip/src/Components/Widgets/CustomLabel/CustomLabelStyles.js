export const styles = {
  textStyle: {
    letterSpacing: '0px',
    fontWeight: '600',
    fontSize: '14px',
    marginBottom: '7px',
    display: 'flex',
  },
  starCotainer: {
    position: 'relative',
  },
  starStyle: {
    position: 'absolute',
    top: '-3px',
    left: '-3px',
  },
};
