import { Typography } from '@mui/material';

import { styles } from './CustomLabelStyles';

const CustomLabel = (props) => {
  const { labelText, labelStyle, isRequired } = props;

  return (
    <Typography sx={{ ...styles.textStyle, ...labelStyle }} component="span">
      {labelText}
      {isRequired && (
        <Typography component="span" sx={styles.starCotainer}>
          <Typography
            sx={{ ...styles.starStyle, ...labelStyle }}
            component="span"
          >
            &nbsp;*
          </Typography>
        </Typography>
      )}
    </Typography>
  );
};

export default CustomLabel;
