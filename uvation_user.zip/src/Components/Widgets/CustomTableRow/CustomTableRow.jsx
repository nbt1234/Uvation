/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable react/no-array-index-key */
import { Box, Checkbox, Chip, Typography } from '@mui/material';
import moment from 'moment';
import * as _ from 'lodash';
import {
  StyledTableRow,
  StyledTableCell,
} from '../CustomTable/CustomTableStyles';

import { commonStyles } from '../../../Assets/Styles/commonStyles';
import { styles } from './CustomTableRowStyles';

const CustomTableRow = (props) => {
  const {
    metaData,
    selected,
    setSelected,
    tableRowData,
    remainingLoyaltyPoints,
    isDisableRow,
  } = props;

  const handleCheckbox = () => {
    const newSelectedValue = _.xorBy(
      selected,
      [tableRowData],
      (item) => item.id
    );
    setSelected(newSelectedValue);
  };

  const isChecked = (checkedItem) => {
    return selected?.find(
      (value) =>
        value?.[checkedItem?.mappingId] ===
        tableRowData?.[checkedItem?.mappingId]
    );
  };

  const isCheckedDisable = (metaItem) => {
    if (selected?.length && isChecked(metaItem)) {
      return false;
    } else {
      return remainingLoyaltyPoints < tableRowData?.[metaItem?.compareKey];
    }
  };

  const getTableCell = (metaItem) => {
    switch (metaItem?.colType) {
      case 'text':
        return (
          <Typography sx={commonStyles.smallText}>
            {`${tableRowData?.[metaItem?.mappingKey]}`}
          </Typography>
        );
      case 'ptsText':
        return (
          <Typography sx={commonStyles.smallText}>
            {`${tableRowData?.[metaItem?.mappingKey]} pts`}
          </Typography>
        );
      case 'price':
        return (
          <Typography sx={commonStyles.smallText}>
            {`$${tableRowData?.[metaItem?.mappingKey]}`}
          </Typography>
        );
      case 'capitaliseText':
        return (
          <Typography
            sx={{ ...commonStyles.smallText, ...styles.capitaliseText }}
          >
            {tableRowData?.[metaItem?.mappingKey]}
          </Typography>
        );
      case 'chip':
        return (
          <Chip
            label={
              (selected.length &&
                isChecked(metaItem) &&
                `${tableRowData?.[metaItem?.mappingKey]} pts`) ||
              (isDisableRow &&
                `${Math.abs(
                  remainingLoyaltyPoints - tableRowData?.[metaItem?.mappingKey]
                )} more points needed`) ||
              `${tableRowData?.[metaItem?.mappingKey]} pts`
            }
          />
        );
      case 'boolean':
        return (
          <Typography sx={commonStyles.smallText}>
            {tableRowData?.[metaItem?.mappingKey]
              ? metaItem.handleBooleanText.trueValue
              : metaItem?.handleBooleanText.falseValue}
          </Typography>
        );
      case 'date':
        return (
          <Typography>
            {moment(tableRowData?.[metaItem?.mappingKey]).format(
              'MMM DD, YYYY hh:mm:ss A'
            )}
          </Typography>
        );
      case 'image':
        return (
          <Box>
            <Typography
              sx={styles.imageStyle}
              component="img"
              src={tableRowData[metaItem.mappingKey]}
            />
          </Box>
        );
      case 'action':
        return (
          <Box
            sx={{
              ...styles.actionBox,
              ...(metaItem?.disableAction &&
                tableRowData[metaItem?.compareKey] !== metaItem?.compareValue &&
                styles.disableActionBox),
            }}
            onClick={() =>
              metaItem?.disableAction
                ? tableRowData[metaItem?.compareKey] ===
                    metaItem?.compareValue &&
                  metaItem?.handler?.onClick(tableRowData)
                : metaItem?.handler?.onClick?.(tableRowData)
            }
          >
            <Typography
              sx={{
                ...commonStyles.commonTextStyle,
                ...(metaItem?.disableAction &&
                  tableRowData[metaItem?.compareKey] !==
                    metaItem?.compareValue &&
                  styles.disableActionText),
              }}
            >
              {metaItem.actionName}
            </Typography>
          </Box>
        );
      case 'checkbox':
        return (
          <Checkbox
            color="primary"
            checked={Boolean(
              selected?.find(
                (value) =>
                  value?.[metaItem?.mappingId] ===
                  tableRowData?.[metaItem?.mappingId]
              )
            )}
            sx={styles.checkBox}
            onChange={() => handleCheckbox()}
            disableRipple
            disabled={isCheckedDisable(metaItem)}
          />
        );
      default:
        return null;
    }
  };

  const checkedStyles = (item) => {
    if (selected?.length) {
      if (!isChecked(item) && isDisableRow) {
        return styles.customStyledCell;
      }
    } else if (isDisableRow) {
      return styles.customStyledCell;
    }
    return null;
  };

  return (
    <StyledTableRow>
      {metaData?.map((item) => (
        <StyledTableCell
          align={item?.align || 'left'}
          key={item?.keyId}
          width={item?.width}
          sx={checkedStyles()}
        >
          {getTableCell(item)}
        </StyledTableCell>
      ))}
    </StyledTableRow>
  );
};

export default CustomTableRow;
