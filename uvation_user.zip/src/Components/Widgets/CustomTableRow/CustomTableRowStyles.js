import { tableCellClasses } from '@mui/material';
import {
  BLEACHED_SILK,
  CHRISTMAS_SILVER,
  COLD_MORNING,
  POT_BLACK,
  WHITE,
  UP_IN_SMOKE,
} from '../../../Constants/colors';

export const styles = {
  imageStyle: {
    maxWidth: '125px',
    maxHeight: '72px',
    borderRadius: '0px',
    objectFit: 'cover',
  },
  decorText: {
    background: CHRISTMAS_SILVER,
    borderRadius: '12px',
    width: 'fit-content',
    padding: '4px 8px',
  },
  actionBox: {
    display: 'flex',
    backgroundColor: COLD_MORNING,
    width: '122px',
    height: '48px',
    alignItems: 'center',
    justifyContent: 'center',
    cursor: 'pointer',
  },
  checkBox: {
    color: POT_BLACK,
    '&.Mui-checked': {
      color: POT_BLACK,
    },
  },
  customStyledCell: {
    [`&.${tableCellClasses.body}`]: {
      backgroundColor: BLEACHED_SILK,
      opacity: '0.6',
    },
    disableActionBox: {
      cursor: 'not-allowed',
      backgroundColor: WHITE,
      border: `1.5px solid ${COLD_MORNING}`,
      height: '45px',
    },
    disableActionText: {
      color: UP_IN_SMOKE,
    },
  },
  disableActionBox: {
    cursor: 'not-allowed',
    backgroundColor: WHITE,
    border: `1.5px solid ${COLD_MORNING}`,
    height: '45px',
  },
  disableActionText: {
    color: UP_IN_SMOKE,
  },
  capitaliseText: {
    textTransform: 'capitalize',
  },
};
