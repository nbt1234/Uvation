import { useState } from 'react';
import CloseIcon from '@mui/icons-material/Close';
import { IconButton, Box, Modal } from '@mui/material';

// eslint-disable-next-line import/no-cycle
import CustomMultiCarousel from '../CustomMultiCarousel/CustomMultiCarousel';
import { styles } from './UtilityModalStyles';

const UtilityModal = ({
  openModal,
  setCloseModal,
  photos,
  selectedPhotoIndex,
}) => {
  const [open, setOpen] = useState(openModal);

  const handleClose = () => {
    setOpen(false);
    setCloseModal(false);
  };

  return (
    <Modal
      sx={styles.modal}
      onClose={handleClose}
      open={open}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={styles.modalBox}>
        <IconButton onClick={handleClose} sx={styles.closeIconButton}>
          <CloseIcon sx={styles.closeButton} />
        </IconButton>
        <CustomMultiCarousel
          photos={photos}
          size="large"
          preventOnImageClick
          defaultSelectedPhotoPosition={selectedPhotoIndex}
        />
      </Box>
    </Modal>
  );
};

export default UtilityModal;
