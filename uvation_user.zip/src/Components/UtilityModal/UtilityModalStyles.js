import { CAVERNOUS, WHITE } from '../../Constants/colors';

export const styles = {
  modal: {
    width: '100%',
    height: '100vh',
    top: '0',
    bottom: '0',
    zIndex: '10000',
  },
  closeButton: {
    color: CAVERNOUS,
    fontWeight: 'Bold',
    fontSize: '30px',
    fill: WHITE,
  },
  closeIconButton: {
    position: 'absolute',
    top: '0px',
    right: '10px',
    width: '40px',
  },
  modalBox: {
    display: 'flex',
    flexDirection: 'column',
    position: 'relative',
    width: '100%',
    height: '100%',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,.8)',
  },
};
