/* eslint-disable no-unsafe-optional-chaining */
import { Box, Typography } from '@mui/material';

import CustomButton from '../Widgets/CustomButton/CustomButton';
import { commonStyles } from '../../Assets/Styles/commonStyles';

const LoyaltyInfo = (props) => {
  const {
    clickHandler,
    toggleBtn,
    loyaltyData,
    btnText,
    freeGiftText,
    showRedeemptionDetail,
  } = props;

  return (
    <Box sx={commonStyles.tableHeaderDetailContainer}>
      <Box>
        <Typography sx={commonStyles.displayTextSmall}>
          Available Loyalty Points Balance :{' '}
          {String(loyaltyData?.loyaltyPointsBalance) ? (
            <Typography component="span" sx={commonStyles.textBold}>
              {loyaltyData?.loyaltyPointsBalance}&nbsp;
            </Typography>
          ) : (
            '--'
          )}
          {String(loyaltyData?.loyaltyPointsBalance) && 'pts'}
        </Typography>
        {showRedeemptionDetail && (
          <Typography sx={commonStyles.displayTextSmall}>
            It can be redeem for :{' '}
            {loyaltyData?.redeemAmount ? (
              <Typography component="span" sx={commonStyles.textBold}>
                ${loyaltyData?.redeemAmount}
              </Typography>
            ) : (
              '--'
            )}{' '}
            at checkout
          </Typography>
        )}
      </Box>
      {toggleBtn && (
        <Box sx={commonStyles.centerAlign}>
          {freeGiftText && <Typography>Free Gift Rewarded</Typography>}
          <CustomButton
            type="proceed"
            textContent={btnText}
            clickHandler={clickHandler}
          />
        </Box>
      )}
    </Box>
  );
};

export default LoyaltyInfo;
