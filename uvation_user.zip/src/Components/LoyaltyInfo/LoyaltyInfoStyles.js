export const styles = {
  freeItemText: {
    fontSize: '14px',
  },
};
