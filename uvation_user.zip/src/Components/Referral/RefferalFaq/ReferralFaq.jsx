import { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';

import CustomAccordion from '../../CustomAccordion/CustomAccordion';
import { faqData as faqTempData } from '../../../Constants/temp';
import { styles } from './ReferralFaqStyles';

const ReferralFaq = () => {
  const [faqData, setFaqData] = useState([]);

  useEffect(() => {
    setFaqData(faqTempData);
  }, []);

  return (
    <Box sx={styles.mainContainer}>
      {faqData?.length > 0 && (
        <>
          <Typography sx={styles.heading}>FAQs</Typography>
          <Box sx={styles.faqWrapper}>
            {faqData?.map((data) => {
              return (
                <CustomAccordion key={data?.id} title={data?.title}>
                  <Typography sx={styles.bodyText}>
                    {data?.description}
                  </Typography>
                </CustomAccordion>
              );
            })}
          </Box>
        </>
      )}
    </Box>
  );
};

export default ReferralFaq;
