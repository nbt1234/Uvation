export const styles = {
  mainContainer: {
    margin: '57px 0',
  },
  heading: {
    fontSize: '24px',
    fontWeight: '500',
  },
  faqWrapper: {
    marginTop: '29px',
    gap: '11px',
    display: 'flex',
    flexDirection: 'column',
  },
  bodyText: {
    fontSize: '14px',
  },
};
