import { OPAQUE_PORPOISE } from '../../../Constants/colors';

export const styles = {
  emailContainer: {
    maxWidth: '500px',
    width: '100%',
  },
  buttonContainer: {
    display: 'flex',
    width: '100%',
  },
  customLabelStyle: {
    color: OPAQUE_PORPOISE,
  },
};
