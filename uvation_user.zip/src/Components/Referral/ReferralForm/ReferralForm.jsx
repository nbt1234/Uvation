import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Box } from '@mui/material';

import CustomInput from '../../Widgets/CustomInput/CustomInput';
import CustomLabel from '../../Widgets/CustomLabel/CustomLabel';
import CustomButton from '../../Widgets/CustomButton/CustomButton';
import { sendReferralRequest } from '../../../Services/referralService';
import { MY_REFERRALS } from '../../../Routes/Routes';
import { SOMETHING_WENT_WRONG } from '../../../Constants/errorMessages';
import { styles } from './ReferralFromStyles';

const ReferralForm = (props) => {
  const { formData, changeHandler } = props;
  const [isLoading, setIsLoading] = useState(false);

  const navigate = useNavigate();

  const submitHandler = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    const response = await sendReferralRequest(formData);
    setIsLoading(false);
    if (!response.error) {
      toast.success(response?.data?.data?.message);
      navigate(MY_REFERRALS);
    } else {
      const code = response.error?.data?.code;
      toast.error(
        code === 'ALREADY_CUSTOMER' || code === 'EMAIL_SENT_ERROR'
          ? response.error?.data?.message
          : SOMETHING_WENT_WRONG
      );
    }
  };

  return (
    <Box>
      <form onSubmit={submitHandler}>
        <Box sx={styles.emailContainer}>
          <CustomLabel
            labelText="Email"
            labelStyle={styles.customLabelStyle}
            isRequired
          />
          <CustomInput
            name="email"
            type="email"
            value={formData?.email}
            setValue={changeHandler}
            isRequired
            placeholder="Enter email"
          />
        </Box>
        <Box sx={styles.emailContainer}>
          <CustomLabel
            labelText="Add a message"
            labelStyle={styles.customLabelStyle}
          />
          <CustomInput
            name="message"
            value={formData?.message}
            setValue={changeHandler}
            placeholder="Enter message"
            multiline
            rows={5}
          />
        </Box>
        <Box sx={styles.buttonContainer}>
          <CustomButton
            type="proceed"
            disabled={!formData?.email}
            buttonType="submit"
            textContent="Send"
            isLoading={isLoading}
          />
        </Box>
      </form>
    </Box>
  );
};

export default ReferralForm;
