import {
  HEROIC_BLUE,
  BLEACHED_SILK,
  POT_BLACK,
  WHITE,
} from '../../Constants/colors';

export const styles = {
  drawer: {
    width: '271px',
    '& .MuiDrawer-paper': {
      overflow: 'hidden',
      display: 'flex',
      width: 'inherit',
      border: 'none',
      borderRight: `1px solid rgba(0, 0, 0, 0.12);`,
      height: 'calc(100vh - 47px)',
      marginTop: '48px',
      '@media (max-width:600px)': {
        marginTop: '48px',
        height: '100%',
      },
    },
    '& .MuiPaper-root': {
      backgroundColor: 'transparent',
    },
  },
  permDrawerContainer: {
    display: { xs: 'none', sm: 'block' },
  },
  tempDrawerContainer: {
    display: { xs: 'block', sm: 'none' },
  },
  list: {
    overflowY: 'auto',
    width: 'inherit',
    height: '100%',
    boxSizing: 'border-box',
    boxShadow: '0px 4px 4px rgba(0, 0, 0, 0.25)',
    backgroundColor: WHITE,
    a: {
      textDecoration: 'none',
      color: 'inherit',
    },
  },
  listContainer: {
    padding: '0',
    margin: '0',
    boxSizing: 'border-box',
  },
  listItem: {
    maxWidth: '271px',
    height: '70px',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'flex-start',
    position: 'relative',
    borderLeft: `5px solid ${WHITE}`,
  },
  activeListItem: {
    backgroundColor: BLEACHED_SILK,
    borderLeft: `5px solid ${HEROIC_BLUE}`,
    '.MuiTypography-root': {
      color: POT_BLACK,
    },
    '&:hover': {
      backgroundColor: BLEACHED_SILK,
    },
  },
  listItemIcon: {
    width: '24px',
  },

  listItemText: {
    color: POT_BLACK,
    fontSize: '16px',
    lineHeight: '22px',
    fontWeight: '400',
    marginLeft: '17px',
    opacity: 1,
  },
  activeListItemText: {
    color: POT_BLACK,
    fontWeight: '600',
    opacity: 1,
  },
};
