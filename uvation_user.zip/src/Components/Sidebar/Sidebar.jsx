import { NavLink, useLocation } from 'react-router-dom';
import {
  Box,
  Divider,
  Drawer,
  List,
  ListItem,
  Typography,
} from '@mui/material';

import { sidebarData } from '../../Constants/sidebarUtils';
import { styles } from './SidebarStyles';

const Sidebar = (props) => {
  const { window, handleDrawerToggle, mobileOpen } = props;
  const { pathname } = useLocation();

  const DrawerContent = (
    <List sx={styles.list} disablePadding>
      <Box sx={styles.listContainer}>
        {sidebarData.map((item) => {
          return (
            <NavLink to={item.link} key={item.id}>
              <ListItem
                sx={{
                  ...styles.listItem,
                  ...(pathname.includes(item.link) && styles.activeListItem),
                }}
                button
              >
                <Typography
                  component="img"
                  src={
                    pathname.includes(item.link) ? item.activeIcon : item.icon
                  }
                  sx={styles.listItemIcon}
                />
                <Typography
                  sx={{
                    ...styles.listItemText,
                    ...(pathname.includes(item.link) &&
                      styles.activeListItemText),
                  }}
                >
                  {item.name}
                </Typography>
              </ListItem>
              <Divider />
            </NavLink>
          );
        })}
      </Box>
    </List>
  );
  const container =
    window !== undefined ? () => window().document.body : undefined;

  return (
    <Box>
      <Drawer
        container={container}
        variant="temporary"
        open={mobileOpen}
        onClose={handleDrawerToggle}
        ModalProps={{
          keepMounted: true,
        }}
        sx={{ ...styles.drawer, ...styles.tempDrawerContainer }}
      >
        {DrawerContent}
      </Drawer>
      <Drawer
        sx={{ ...styles.drawer, ...styles.permDrawerContainer }}
        variant="permanent"
        anchor="left"
        open
      >
        {DrawerContent}
      </Drawer>
    </Box>
  );
};

export default Sidebar;
