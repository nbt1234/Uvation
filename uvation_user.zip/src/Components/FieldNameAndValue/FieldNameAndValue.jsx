import * as moment from 'moment';
import { Box, Typography } from '@mui/material';

import { styles } from './FieldNameAndValueStyles';

const FieldNameAndValue = (props) => {
  const { name, value, customNameStyle, customValueStyle, type } = props;

  return (
    <Box sx={styles.mainContainer}>
      <Typography sx={{ ...styles.nameTextStyle, ...customNameStyle }}>
        {name}
      </Typography>
      <Typography sx={{ ...styles.valueTextStyle, ...customValueStyle }}>
        {type === 'date' ? moment(value).format('ll') : value}
      </Typography>
    </Box>
  );
};

export default FieldNameAndValue;
