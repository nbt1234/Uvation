import { MORE_THAN_A_WEEK, POT_BLACK } from '../../Constants/colors';

export const styles = {
  mainContainer: {
    display: 'flex',
    flexDirection: 'column',
  },
  nameTextStyle: {
    color: MORE_THAN_A_WEEK,
    textTransform: 'uppercase',
    fontSize: '12px',
  },
  valueTextStyle: {
    color: POT_BLACK,
    fontSize: '14px',
  },
};
