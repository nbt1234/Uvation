import { CAVERNOUS, MORE_THAN_A_WEEK, POT_BLACK } from '../../Constants/colors';

export const styles = {
  subHeadingText: {
    color: MORE_THAN_A_WEEK,
    textTransform: 'uppercase',
    fontSize: '12px',
    lineHeight: '27px',
  },
  textStyle: {
    color: POT_BLACK,
    fontSize: '20px',
    lineHeight: '27px',
  },
  clockIcon: {
    width: '18px',
    height: '18px',
    marginRight: '10px',
  },
  subContainer: { display: 'flex', alignItems: 'center', marginBottom: '24px' },
  downContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    width: '100%',
    '@media (max-width:600px)': {
      flexDirection: 'column',
    },
  },
  leftContainer: { marginTop: '24px' },
  contentWrapper: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    columnGap: '20px',
    rowGap: '20px',
    marginTop: '24px',
    width: '60%',
    '@media (max-width:600px)': {
      width: '100%',
    },
  },
  flexContainer: {
    display: 'flex',
    flexDirection: 'column',
  },
  nameTextStyle: {
    color: CAVERNOUS,
    fontSize: '18px',
    textAlign: 'right',
    '@media (max-width:600px)': {
      textAlign: 'left',
    },
  },
  valueTextStyle: {
    color: POT_BLACK,
    fontSize: '20px',
    textAlign: 'right',
    '@media (max-width:600px)': {
      textAlign: 'left',
    },
  },
};
