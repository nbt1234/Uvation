import { Box, Divider, Typography } from '@mui/material';

import clockIcon from '../../Assets/Images/timeActive.svg';
import FieldNameAndValue from '../FieldNameAndValue/FieldNameAndValue';
import { commonStyles } from '../../Assets/Styles/commonStyles';
import { styles } from './OrderDetailCardStyles';

const OrderDetailCard = (props) => {
  const { data } = props;
  return (
    <Box sx={commonStyles.mainContentContainer}>
      <Box>
        <Typography sx={styles.subHeadingText}>ORDER STATUS</Typography>
        <Box sx={styles.subContainer}>
          <Typography sx={styles.clockIcon} component="img" src={clockIcon} />
          <Typography sx={styles.textStyle}>
            {data?.orderStatus ? data?.orderStatus : '--'}
          </Typography>
        </Box>
      </Box>
      <Divider />
      <Box sx={styles.downContainer}>
        <Box sx={styles.contentWrapper}>
          <FieldNameAndValue
            name="Order Number"
            value={data?.orderId ? data?.orderId : '--'}
          />
          <FieldNameAndValue
            name="Order Date"
            value={data?.orderDate ? data?.orderDate : '--'}
            type={data?.orderDate ? 'date' : ''}
          />
          <FieldNameAndValue
            name="Grand Total"
            value={data?.grandTotal ? `$${data?.grandTotal}` : '--'}
          />
        </Box>
        <Box sx={styles.leftContainer}>
          <Box sx={styles.flexContainer}>
            <Typography sx={styles.nameTextStyle}>
              Loyalty Points {data?.freeItem?.length > 0 ? 'Used' : 'Gained'}
            </Typography>
            <Typography sx={styles.valueTextStyle}>
              {data?.freeItem?.length > 0
                ? data?.loyaltyPointsUsed
                : data?.loyaltyPointsGain}
            </Typography>
          </Box>
        </Box>
      </Box>
    </Box>
  );
};

export default OrderDetailCard;
