import { useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import * as _ from 'lodash';
import {
  useMsal,
  AuthenticatedTemplate,
  useIsAuthenticated,
  useMsalAuthentication,
} from '@azure/msal-react';
import { io } from 'socket.io-client';
import { InteractionStatus } from '@azure/msal-browser';
import { Box } from '@mui/material';
import axios from 'axios';

import CustomLoader from '../Widgets/CustomLoader/CustomLoader';
import { loginRequest, msalConfig, silentRequest } from '../../authConfig';
import {
  clearStorageData,
  logoutUserHandler,
  redirectLogout,
} from '../../Utils/logoutUserHandler';
import {
  setSingleSignOn,
  // loginUser,
  setInstance,
  setSocketDataValue,
} from '../../Redux/SingleSignOn/SingleSignOnSlice';
import { setItem } from '../../Services/localStorageService';
import { styles } from './GlobalwrapperStyles';

const Globalwrapper = (props) => {
  const { children } = props;
  const { accounts, instance, inProgress } = useMsal();

  const isAuthenticated = useIsAuthenticated();
  const dispatch = useDispatch();

  const [account, setAccount] = useState({});
  const [socketData, setSocketData] = useState();
  const [contactdata, setcontactdata] = useState();
  // const [isUserSignUp, setIsUserSignUp] = useState(false);
  const [isContactLoading, setIsContactLoading] = useState(true);

  const { error } = useMsalAuthentication();

  const { data, isSuccess, isLoading, isError } = useSelector(
    (state) => state.singleSignOn.loginData
  );

  useEffect(() => {
    // const timeout = setInterval(() => {
    axios
      .post(
        'https://appsapi.uvation.com:8080/identity/sftoken'
        // "https://login.salesforce.com/services/oauth2/token?grant_type=password&client_id=3MVG9kBt168mda_.cqzKZWOYYbRmS_z9W9wgF123Aquj9qq3h89WFTBGmtKh.nhtjm9EcG0SGQUiytvMgbfCI&client_secret=403487DD8963395771203CD0260C91BFF27292E14D968DCB7511E63017B6384D&username=himani.goel@uvation.com&password=Himani@2911"

        // {
        //   headers: {
        //     "Access-Control-Allow-Origin": "*",
        //     "content-type": "application/x-www-form-urlencoded",
        //   },
        // }
      )
      .then((res) => {
        setcontactdata(res?.data?.response);
        if (account?.idTokenClaims?.newUser) {
          axios
            .post(
              `${res?.data?.response?.instance_url}/services/data/v43.0/sobjects/Contact`,
              {
                FirstName: account?.idTokenClaims?.given_name,
                LastName: account?.idTokenClaims?.family_name,
                Phone: '',
                email: account?.idTokenClaims?.email,
                MailingCity: '',
                MailingCountry: '',
                MailingState: '',
                MailingStreet: '',
                MailingPostalCode: '',
                Company_Name__c: '',
                Azure_User_ID__c: account?.idTokenClaims?.sub,
              },
              {
                headers: {
                  Authorization: `Bearer ${res?.data?.response?.access_token}`,
                  'Access-Control-Allow-Origin': '*',
                },
              }
            )
            .then((res) => {
              if (res?.status === 204) {
                axios
                  .get(
                    `${contactdata?.instance_url}/services/apexrest/ContactInfo?azureId=${account?.idTokenClaims?.sub}`,
                    {
                      headers: {
                        Authorization: `Bearer ${contactdata?.access_token}`,
                        'Access-Control-Allow-Origin': '*',
                      },
                    }
                  )
                  .then(() => {
                    // clearInterval(timeout);
                    // console.log("res", res);
                    // setcontactinfodata(res?.data?.contactInfo);
                    // setcontactsalesforce(res?.data?.companyInfo);
                  });
              }
            });
        }
      });
    // }, 10000);
  }, [account]);

  useEffect(() => {
    const timeout = setInterval(() => {
      if (contactdata && account?.idTokenClaims?.sub) {
        setIsContactLoading(true);
        axios
          .get(
            `${contactdata?.instance_url}/services/apexrest/ContactInfo?azureId=${account?.idTokenClaims?.sub}`,
            {
              headers: {
                Authorization: `Bearer ${contactdata?.access_token}`,
                'Access-Control-Allow-Origin': '*',
              },
            }
          )
          .then((res) => {
            // eslint-disable-next-line eqeqeq
            if (res?.data?.status == 'Success') {
              axios
                .post('https://appsapi.uvation.com:8080/reward/contact', {
                  azureId: account?.idTokenClaims?.sub,
                  firstName: account?.idTokenClaims?.given_name,
                  lastName: account?.idTokenClaims?.family_name,
                  email: account?.idTokenClaims?.email,
                  ssContactId: res?.data?.contactInfo?.recordId,
                  phoneNo: `${account?.idTokenClaims?.extension_CountryCode}${account?.idTokenClaims?.MobileNumber}`,
                })
                .then(() => {
                  // setIsUserSignUp(true);
                  setIsContactLoading(false);
                })
                .catch(() => {
                  setIsContactLoading(false);
                  clearStorageData();
                  redirectLogout();
                });
              clearInterval(timeout);
              // setcontactinfodata(res?.data?.contactInfo);
              // setcontactsalesforce(res?.data?.companyInfo);
            }
          })
          .catch(() => {
            setIsContactLoading(false);
            clearStorageData();
            redirectLogout();
          });
      }
    }, 10000);
  }, [contactdata, account?.idTokenClaims?.sub]);

  useEffect(() => {
    setAccount(accounts[0] || {});
  }, [accounts]);

  useEffect(() => {
    dispatch(setInstance(instance));
  }, [instance]);

  useEffect(() => {
    dispatch(setSocketDataValue(socketData));
  }, [socketData]);

  useEffect(() => {
    if (!_.isEmpty(account)) {
      // TODO: Remove this console statement.
     
      dispatch(setSingleSignOn(account));
      setItem('ssoData', account);
      setItem('azureId', account?.idTokenClaims?.sub);
      // dispatch(
      //   loginUser({
      //     azureId: account?.idTokenClaims?.sub,
      //   })
      // );
    }
  }, [account]);

  // useEffect(() => {
  //   if (!_.isEmpty(account) && isUserSignUp) {
  //     dispatch(
  //       loginUser({
  //         azureId: account?.idTokenClaims?.sub,
  //       })
  //     );
  //   }
  // }, [account, isUserSignUp]);

  useEffect(() => {
    if (data && isSuccess) {
      setItem('loginToken', data?.authToken);
    }
  }, [data]);

  useEffect(() => {
    if (error) {
      if (
        error.errorMessage &&
        error.errorMessage.indexOf('AADB2C90091') > -1
      ) {
        instance.loginRedirect(loginRequest);
      }
    } else if (
      !isAuthenticated &&
      inProgress === InteractionStatus.None &&
      !sessionStorage.length
    ) {
      instance.loginRedirect(loginRequest);
    } else if (isAuthenticated) {
      instance.acquireTokenSilent({
        ...silentRequest,
        account: accounts,
      });
    }
  }, [isAuthenticated, inProgress, instance]);

  useEffect(() => {
    if (account) {
      const socket = io.connect('https://notifications.uvation.com:443/');
      socket.on('connected');
      socket.emit('join', { userid: account?.idTokenClaims?.sub });
      setSocketData(socket);
    }
  }, [account]);

  useEffect(() => {
    if (isError) {
      clearStorageData();
      redirectLogout();
    }
  }, [isError]);

  socketData?.on('logoutfromcurrentsite', () => {
    logoutUserHandler();
    localStorage.clear();
    instance.logoutRedirect(msalConfig.auth.postLogoutRedirectUri);
  });

  return (
    <>
      {(isLoading ||
        inProgress !== InteractionStatus.None ||
        !isAuthenticated ||
        isContactLoading) && (
        <Box sx={styles.loaderBox}>
          <CustomLoader />
        </Box>
      )}
      {isSuccess && !isError && inProgress === InteractionStatus.None && (
        <AuthenticatedTemplate>{children}</AuthenticatedTemplate>
      )}
    </>
  );
};

export default Globalwrapper;
