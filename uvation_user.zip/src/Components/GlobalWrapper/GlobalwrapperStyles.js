export const styles = {
  loaderBox: {
    height: '100vh',
  },
};
