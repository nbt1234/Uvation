import { commonStyles } from '../../Assets/Styles/commonStyles';

export const styles = {
  layoutContainer: {
    width: '100%',
  },
  mainContentWrapper: {
    width: '100%',
    overflowY: 'auto',
    '@media (max-width: 900px)': {
      marginTop: '47px',
    },
    ...commonStyles.thickCustomScrollBar,
  },
  flexContainer: {
    display: 'flex',
    height: 'calc(100vh - 48px)',
    width: '100%',
    margin: 0,
    padding: 0,
  },
  layoutSuspense: {
    height: '100%',
    minHeight: 'calc(100vh - 48px)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
};
