import { useState, Suspense, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { Box, Grid } from '@mui/material';

import Home from '../Home/Home';
import Sidebar from '../Sidebar/Sidebar';
import CustomLoader from '../Widgets/CustomLoader/CustomLoader';
import { styles } from './LayoutStyes';
import { getAdminConfig } from '../../Redux/GetAdminConfig/GetAdminCongifSlice';

const Layout = (props) => {
  const { children } = props;
  const [mobileOpen, setMobileOpen] = useState(false);

  const dispatch = useDispatch();

  const handleDrawerToggle = () => {
    setMobileOpen((prev) => !prev);
  };
  useEffect(() => {
    dispatch(getAdminConfig());
  }, []);

  return (
    <Box sx={styles.layoutContainer}>
      <Home handleDrawerToggle={handleDrawerToggle} />
      <ToastContainer theme="colored" />
      <Box sx={styles.flexContainer}>
        <Sidebar
          mobileOpen={mobileOpen}
          handleDrawerToggle={handleDrawerToggle}
        />
        <Grid container sx={styles.mainContentWrapper}>
          <Suspense
            fallback={
              <Box sx={styles.layoutSuspense}>
                <CustomLoader />
              </Box>
            }
          >
            {children}
          </Suspense>
        </Grid>
      </Box>
    </Box>
  );
};

export default Layout;
