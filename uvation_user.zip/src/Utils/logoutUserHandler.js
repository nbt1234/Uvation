/* eslint-disable import/no-cycle */
import { toast } from 'react-toastify';

import { SOMETHING_WENT_WRONG } from '../Constants/errorMessages';
import { UNAUTHORIZED_USER } from '../Constants/statusCodes';
import { logoutUser } from '../Services/logoutService';

export const clearStorageData = () => {
  sessionStorage.clear();
  localStorage.clear();
};

export const redirectLogout = () => {
  window.location.replace('https://identity.uvation.com/home');
};

export const logoutUserHandler = async () => {
  const response = await logoutUser();
  if (!response.error) {
    clearStorageData();
  } else if (response.error?.status === UNAUTHORIZED_USER) {
    clearStorageData();
  } else {
    toast.error(SOMETHING_WENT_WRONG);
  }
};
