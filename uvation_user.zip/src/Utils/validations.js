import {
  IS_REQUIRED_VALIDATION,
  IS_REQUIRED_STRING_VALIDATION,
  IS_NUMBER_GREATER_THAN_VALIDATION,
} from '../Constants/validationConstant';

const isRequiredString = (value) => {
  return value.trim().length <= 0;
};

export const isSmallerThan = (value1, value2) => {
  return parseFloat(value1) > parseFloat(value2);
};

const isRequired = (value) => {
  return (
    value === 'undefined' || value === null || value === '' || value === []
  );
};

const functionHandler = (key, data) => {
  switch (key) {
    case IS_REQUIRED_STRING_VALIDATION:
      return isRequiredString(data.value);
    case IS_REQUIRED_VALIDATION:
      return isRequired(data.value);
    case IS_NUMBER_GREATER_THAN_VALIDATION:
      return isSmallerThan(data.value, data.config.maxValue);
    default:
      return null;
  }
};

export const validationHandler = (formData, setError, config) => {
  let newErrorData = {};
  let isFormValid = true;
  Object.entries(config).forEach(([fieldName, fun]) => {
    Object.entries(fun).every(([key, value]) => {
      const validationFunction = functionHandler(key, {
        value: formData[fieldName],
        config: value,
      });
      if (validationFunction) {
        newErrorData = { ...newErrorData, [fieldName]: value.errorMsg };
        isFormValid = false;
        return false;
      }
      newErrorData = { ...newErrorData, [fieldName]: '' };
      return true;
    });
  });
  setError((prevState) => {
    return { ...prevState, ...newErrorData };
  });
  return isFormValid;
};
