import {
  COLD_MORNING,
  METALLIC_SILVER,
  POT_BLACK,
  BLEACHED_SILK,
  CHRISTMAS_SILVER,
  CAVERNOUS,
  PORPOISE,
} from '../../Constants/colors';

export const commonStyles = {
  commonTextStyle: {
    fontSize: '14px',
    color: POT_BLACK,
    fontWeight: 600,
  },
  headContainer: {
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    width: 'fit-content',
    '& p': {
      color: CAVERNOUS,
    },
  },
  tableMainContainer: {
    width: '100%',
  },
  textBold: {
    fontWeight: 500,
  },
  upperCaseText: { textTransform: 'uppercase' },
  mainContentContainer: {
    boxSizing: 'border-box',
    border: `1px solid ${CHRISTMAS_SILVER}`,
    padding: '30px',
    width: '100%',
  },
  dividerStyle: {
    width: '100%',
    margin: 0,
    border: `1px solid ${COLD_MORNING}`,
  },
  customScrollBar: {
    '&::-webkit-scrollbar': {
      width: '0.3em',
      height: '0.3rem',
    },
    '&::-webkit-scrollbar-track': {
      boxShadow: 'inset 0 0 0.375rem rgba(0,0,0,0.00)',
      webkitBoxShadow: 'inset 0 0 0.375rem rgba(0,0,0,0.00)',
      width: '0.438rem',
      borderRadius: '0.75rem',
      background: PORPOISE,
    },
    '&::-webkit-scrollbar-thumb': {
      backgroundColor: 'rgba(0,0,0,.1)',
      borderRadius: '0.75rem',
      background: METALLIC_SILVER,
    },
  },
  tableHeaderDetailContainer: {
    background: `${BLEACHED_SILK} 0% 0% no-repeat padding-box`,
    border: `1px solid ${CHRISTMAS_SILVER}`,
    padding: '16px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginTop: '30px',
    marginBottom: '30px',
    '@media(max-width:900px)': {
      flexDirection: 'column',
      alignItems: 'start',
      rowGap: '10px',
    },
  },
  centerAlign: {
    display: 'flex',
    alignItems: 'center',
    columnGap: '15px',
  },
  displayTextSmall: {
    color: CAVERNOUS,
    fontSize: '16px',
  },
  displayTextSmallBold: {
    color: CAVERNOUS,
    fontSize: '16px',
    fontWeight: '600',
  },
  smallText: { fontSize: '14px' },
  thickCustomScrollBar: {
    '&::-webkit-scrollbar': {
      width: '0.6em',
      height: '0.6rem',
    },
    '&::-webkit-scrollbar-track': {
      boxShadow: 'inset 0 0 0.375rem rgba(0,0,0,0.00)',
      webkitBoxShadow: 'inset 0 0 0.375rem rgba(0,0,0,0.00)',
      width: '0.438rem',
      borderRadius: '0.75rem',
      background: PORPOISE,
    },
    '&::-webkit-scrollbar-thumb': {
      backgroundColor: 'rgba(0,0,0,.1)',
      borderRadius: '0.75rem',
      background: METALLIC_SILVER,
    },
  },
  lazyLoaderStyle: {
    height: '100vh',
  },
};
