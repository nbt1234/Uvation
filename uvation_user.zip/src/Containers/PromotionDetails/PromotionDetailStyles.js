import { CAVERNOUS } from '../../Constants/colors';

export const styles = {
  backIcon: {
    marginRight: '10px',
  },
  mainContainer: {
    width: '100%',
    padding: '40px 30px',
  },
  headerText: {
    textDecoration: 'underline',
  },
  mainHeadingText: {
    fontSize: '24px',
    marginTop: '38px',
    fontWeight: '500',
    marginBottom: '17px',
  },
  fieldsWrapper: {
    display: 'flex',
    justifyContent: 'space-between',
    marginTop: '20px',
    flexWrap: 'wrap',
    columnGap: '20px',
    rowGap: '20px',
  },
  freeItemFieldWrapper: {
    margin: '30px auto',
    display: 'flex',
    justifyContent: 'start',
    columnGap: '60px',
    rowGap: '30px',
    alignItems: 'start',
    '@media(max-width:930px)': {
      flexWrap: 'wrap',
    },
  },
  subHeadingText: {
    marginBottom: '20px',
    fontSize: '20px',
  },
  subHeadingValue: {
    fontSize: '18px',
    fontWeight: '500',
  },
  carouselWrapper: { width: '25%', maxWidth: '300px', minWidth: '240px' },
  promotionSubHeading: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'start',
    justifyContent: 'space-between',
    marginBottom: '20px',
  },
  subHeadingTitle: {
    fontSize: '12px',
    color: CAVERNOUS,
    textTransform: 'uppercase',
  },
  promotionSubHeadingWrapper: {
    textAlign: 'right',
  },
  subHeading: {
    margin: '20px auto',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'start',
    gap: '25px',
  },
  bannerImg: {
    width: '200px',
    objectFit: 'contain',
    marginTop: '30px',
  },
  freeItemImg: {
    width: '200px',
    objectFit: 'contain',
  },
  freeItemContentWrapper: {
    display: 'flex',
    justifyContent: 'start',
    flexWrap: 'wrap',
    columnGap: '100px',
    rowGap: '30px',
    alignItems: 'start',
    '@media(max-width:930px)': {
      columnGap: '40px',
    },
  },
  giftCardSubHeading: {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'start',
    columnGap: '40px',
    rowGap: '20px',
    flexWrap: 'wrap',
  },
  orderSubHeading: { margin: '0 auto 20px' },
  firstFreeItemField: {
    marginTop: '0',
  },
  lastFreeItemField: {
    marginBottom: '0',
  },
};
