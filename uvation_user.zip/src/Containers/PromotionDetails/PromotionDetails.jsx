import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Box, Typography, Divider } from '@mui/material';

import arrowLeft from '../../Assets/Images/arrowLeft.svg';
import FieldNameAndValue from '../../Components/FieldNameAndValue/FieldNameAndValue';
import CustomMultiCarousel from '../../Components/CustomMultiCarousel/CustomMultiCarousel';
import CustomLoader from '../../Components/Widgets/CustomLoader/CustomLoader';
import { MY_PROMOTIONS } from '../../Routes/Routes';
import { getPromotionDetail } from '../../Services/promotionService';
import { SOMETHING_WENT_WRONG } from '../../Constants/errorMessages';
import { FILE_DOWNLOAD_API } from '../../Constants/apiEndpoints';
import { styles } from './PromotionDetailStyles';
import { commonStyles } from '../../Assets/Styles/commonStyles';

const PromotionDetails = () => {
  const { orderId, promotionId } = useParams();

  const navigate = useNavigate();

  const [data, setData] = useState();
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);

  const fetchPromotionDetail = async () => {
    setIsLoading(true);
    const response = await getPromotionDetail({
      orderId,
      qsString: { promotionId },
    });
    const responseData = response?.data?.data?.data;
    const errorCode = response?.error?.data?.code;
    if (responseData) {
      setData(responseData);
    } else if (
      errorCode === 'ORDER_NOT_EXISTS' ||
      errorCode === 'PROMOTION_NOT_FOUND'
    ) {
      setIsError(true);
      toast.error(response?.error?.data?.message);
      navigate(MY_PROMOTIONS);
    } else if (response?.error) {
      toast.error(SOMETHING_WENT_WRONG);
      navigate(MY_PROMOTIONS);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchPromotionDetail();
  }, []);

  return (
    <Box sx={styles.mainContainer}>
      {isLoading && <CustomLoader />}
      {!isLoading && !isError && data && (
        <>
          <Box
            sx={commonStyles.headContainer}
            onClick={() => navigate(MY_PROMOTIONS)}
          >
            <Typography component="img" src={arrowLeft} sx={styles.backIcon} />
            <Typography sx={styles.headerText}>
              Back to My Promotions
            </Typography>
          </Box>
          {/* promotion detail */}
          <Typography sx={styles.mainHeadingText}>Promotion Details</Typography>
          <Box sx={commonStyles.mainContentContainer}>
            <Box sx={styles.promotionSubHeading}>
              <Box>
                <Typography sx={styles.subHeadingTitle}>
                  Promotion Name:{' '}
                </Typography>
                <Typography sx={styles.subHeadingValue}>
                  {data?.promotionName ? data?.promotionName : '--'}
                </Typography>
              </Box>
              <Box sx={styles.promotionSubHeadingWrapper}>
                <Typography sx={styles.subHeadingTitle}>
                  Order Promotion Amount:{' '}
                </Typography>
                <Typography sx={styles.subHeadingValue}>
                  {data?.orderPromotionAmount
                    ? `$${data?.orderPromotionAmount}`
                    : '--'}
                </Typography>
              </Box>
            </Box>
            <Divider />
            <Box sx={styles.subHeading}>
              <FieldNameAndValue
                name="Order Date"
                value={data?.orderDate ? data?.orderDate : '--'}
                type={data?.orderDate ? 'date' : ''}
              />
              <FieldNameAndValue
                name="Order Status"
                value={data?.orderStatus ? data?.orderStatus : '--'}
              />
              <FieldNameAndValue
                name="Released Status"
                value={
                  data?.promotionReleaseStatus
                    ? data?.promotionReleaseStatus
                    : '--'
                }
              />
            </Box>
            <Divider />
            <Typography
              sx={styles.bannerImg}
              component="img"
              src={
                data?.bannerImageId &&
                `${process.env.REACT_APP_API_BASE_URL}${FILE_DOWNLOAD_API}/${data?.bannerImageId}`
              }
            />
          </Box>
          {/* order detail */}
          <Typography sx={styles.mainHeadingText}>Order #{orderId}</Typography>
          <Box sx={commonStyles.mainContentContainer}>
            <Box sx={{ ...styles.subHeading, ...styles.orderSubHeading }}>
              <FieldNameAndValue
                name="Order Status"
                value={data?.orderStatus ? data?.orderStatus : '--'}
              />
              <FieldNameAndValue
                name="Order Date"
                value={data?.orderDate ? data?.orderDate : '--'}
                type={data?.orderDate ? 'date' : ''}
              />
            </Box>
            {data?.productImageUrl?.length && (
              <>
                <Divider />
                <Box sx={styles.fieldsWrapper}>
                  <Box sx={styles.carouselWrapper}>
                    <CustomMultiCarousel
                      galleryPreview
                      photos={data?.productImageUrl?.map((item) => {
                        return item.image;
                      })}
                    />
                  </Box>
                </Box>
              </>
            )}
          </Box>
          {data?.giftCardValue && (
            <>
              {/* gift card detail */}
              {data?.giftCardValue && (
                <>
                  {' '}
                  <Typography sx={styles.mainHeadingText}>
                    Gift Card Detail
                  </Typography>
                  <Box sx={commonStyles.mainContentContainer}>
                    <Box sx={styles.giftCardSubHeading}>
                      <FieldNameAndValue
                        name="Gift Card Value"
                        value={data?.giftCardValue ? data?.giftCardValue : '--'}
                      />
                      <FieldNameAndValue
                        name="Gift Card Released At"
                        value={
                          data?.giftCardReleaseAt
                            ? data?.giftCardReleaseAt
                            : 'Not Released'
                        }
                        type={data?.giftCardReleaseAt ? 'date' : ''}
                      />
                      <FieldNameAndValue
                        name="Gift Card Released Status"
                        value={
                          data?.giftCardReleaseStatus
                            ? data?.giftCardReleaseStatus
                            : '--'
                        }
                      />
                      <FieldNameAndValue
                        name="Gift Card Delivery At"
                        value={
                          data?.giftCardDeliveryAt
                            ? data?.giftCardDeliveryAt
                            : 'Not Delivered'
                        }
                        type={data?.giftCardDeliveryAt ? 'date' : ''}
                      />
                      <FieldNameAndValue
                        name="Gift Card Delivery Status"
                        value={
                          data?.giftCardDeliveryStatus
                            ? data?.giftCardDeliveryStatus
                            : '--'
                        }
                      />
                    </Box>
                  </Box>
                </>
              )}
            </>
          )}
          {/* free item detail */}
          {data?.freeItems?.length > 0 && (
            <>
              <Typography sx={styles.mainHeadingText}>
                Free Item Detail
              </Typography>
              <Box sx={commonStyles.mainContentContainer}>
                {data?.freeItems?.map((item, idx) => {
                  return (
                    <Box key={item.id}>
                      <Box
                        sx={{
                          ...styles.freeItemFieldWrapper,
                          ...(idx === 0 && styles.firstFreeItemField),
                          ...(idx + 1 === data?.freeItems?.length &&
                            styles.lastFreeItemField),
                        }}
                      >
                        <Typography
                          component="img"
                          sx={styles.freeItemImg}
                          src={item?.imageUrl}
                        />
                        <Box sx={styles.freeItemContentWrapper}>
                          <FieldNameAndValue
                            name="Product Code"
                            value={item?.productCode ? item?.productCode : '--'}
                          />
                          <FieldNameAndValue
                            name="Product Name"
                            value={item?.productName ? item?.productName : '--'}
                          />
                          <FieldNameAndValue
                            name="Released Status"
                            value={
                              item?.releaseStatus ? item?.releaseStatus : '--'
                            }
                          />
                          <FieldNameAndValue
                            name="Released At"
                            value={
                              item?.releaseAt ? item?.releaseAt : 'Not Released'
                            }
                            type={item?.releaseAt ? 'date' : ''}
                          />
                          <FieldNameAndValue
                            name="Delivery Status"
                            value={
                              item?.deliveryStatus ? item?.deliveryStatus : '--'
                            }
                          />
                          <FieldNameAndValue
                            name="Deliver At"
                            value={
                              item?.deliveredAt
                                ? item?.deliveredAt
                                : 'Not Delivered'
                            }
                            type={item?.deliveredAt ? 'date' : ''}
                          />
                          <FieldNameAndValue
                            name="Product Qty"
                            value={item?.productQty ? item?.productQty : '--'}
                          />
                        </Box>
                      </Box>
                      {idx + 1 !== data?.freeItems?.length && <Divider />}
                    </Box>
                  );
                })}
              </Box>
            </>
          )}
        </>
      )}
    </Box>
  );
};

export default PromotionDetails;
