/* eslint-disable no-unsafe-optional-chaining */
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Box } from '@mui/material';

import CustomTable from '../../Components/Widgets/CustomTable/CustomTable';
import LoyaltyInfo from '../../Components/LoyaltyInfo/LoyaltyInfo';
import { GET_FREE_GIFT_CARD } from '../../Routes/Routes';
import { getMyLoyaltyList } from '../../Redux/MyLoyalty/MyLoyaltySlice';
import { getLoyaltyPointsService } from '../../Services/dashboardService';
import { commonStyles } from '../../Assets/Styles/commonStyles';
import { styles } from './MyLoyaltyStyles';

const MyLoyalty = () => {
  const [loyaltyData, setLoyaltyData] = useState({
    loyaltyPointsBalance: '',
    redeemAmount: '',
  });

  const navigate = useNavigate();
  const clickHandler = () => {
    navigate(GET_FREE_GIFT_CARD);
  };

  const { isLoading, isError, isSuccess, data } = useSelector((state) => {
    return state.myLoyalty?.myLoyaltyListData;
  });
  const {
    configData,
    isAdminConfigLoading,
    isAdminConfigSuccess,
    isAdminConfigError,
  } = useSelector((state) => {
    return state.getAdminConfig.adminConfigData;
  });

  const fetchLoyaltyPoints = async () => {
    const response = await getLoyaltyPointsService();
    if (response?.data?.data?.data) {
      setLoyaltyData({
        loyaltyPointsBalance: response?.data?.data?.data?.loyaltyPointsBalance,
        redeemAmount: parseFloat(
          response?.data?.data?.data?.loyaltyPointsRedeemedToUSD
        ).toFixed(2),
      });
    }
  };

  useEffect(() => {
    fetchLoyaltyPoints();
  }, []);

  const metaData = [
    {
      keyId: 0,
      mappingId: 'id',
      mappingKey: 'logType',
      headingName: 'Type',
      colType: 'text',
      width: '15%',
      align: 'left',
    },
    {
      keyId: 1,
      mappingId: 'id',
      mappingKey: 'points',
      headingName: 'Points',
      colType: 'ptsText',
      width: '15%',
      align: 'left',
    },
    {
      keyId: 2,
      mappingId: 'id',
      mappingKey: 'created',
      headingName: 'Date',
      colType: 'date',
      width: '20%',
      align: 'left',
    },
    {
      keyId: 3,
      mappingId: 'id',
      mappingKey: 'isStatusPending',
      headingName: 'Release Status',
      colType: 'boolean',
      width: '15%',
      align: 'left',
      handleBooleanText: { falseValue: 'Completed', trueValue: 'Pending' },
    },
    {
      keyId: 4,
      mappingId: 'id',
      mappingKey: 'action',
      headingName: 'Action',
      colType: 'action',
      actionName: 'View Detail',
      width: '15%',
      align: 'left',
      handler: {
        onClick: (handlerData) => {
          navigate(`/my-loyalty/details/${handlerData?.id}`);
        },
      },
      compareKey: 'logType',
      compareValue: 'Order',
      disableAction: true,
    },
  ];

  return (
    <Box sx={commonStyles.tableMainContainer}>
      <CustomTable
        tableData={data?.result}
        metaData={metaData}
        totalCount={data?.totalCount || 0}
        isLoading={isAdminConfigLoading || isLoading}
        isError={isAdminConfigError || isError}
        isSuccess={isAdminConfigSuccess && isSuccess}
        pageHeading="Loyalty Points"
        pageSubHeading="Points history"
        customPaperStyle={styles.customPaperStyle}
        customTableStyle={styles.customTableStyle}
        headerChildren={
          <LoyaltyInfo
            clickHandler={clickHandler}
            toggleBtn
            btnText="Get Free Gift"
            loyaltyData={loyaltyData}
            freeGiftText
            showRedeemptionDetail
          />
        }
        dispatchFunction={getMyLoyaltyList}
        showCount
        showCustomError={configData?.myLoyaltyPageNewCustomerMessage}
      />
    </Box>
  );
};

export default MyLoyalty;
