export const styles = {
  customPaperStyle: { marginTop: '15px' },
  customTableStyle: {
    maxHeight: 'calc(100vh - 390px)',
    '@media(max-height:630px)': {
      maxHeight: '500px',
    },
  },
};
