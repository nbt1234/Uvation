import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Box } from '@mui/material';

import CustomTable from '../../Components/Widgets/CustomTable/CustomTable';
import ReferralInfo from './ReferralInfo';
import { getMyReferralsList } from '../../Redux/MyReferrals/MyReferralsSlice';
import { REFERRAL_DETAILS_NAVIGATE } from '../../Routes/Routes';
import { commonStyles } from '../../Assets/Styles/commonStyles';
import { styles } from './MyReferralStyles';

const MyReferral = () => {
  const { data, isLoading, isError, isSuccess } = useSelector((state) => {
    return state.myReferrals?.myReferralsListData;
  });
  const {
    configData,
    isAdminConfigLoading,
    isAdminConfigSuccess,
    isAdminConfigError,
  } = useSelector((state) => {
    return state.getAdminConfig.adminConfigData;
  });

  const navigate = useNavigate();

  const metaData = [
    {
      keyId: 1,
      mappingId: 'id',
      mappingKey: 'refereeEmailId',
      headingName: 'Email',
      colType: 'text',
      width: '25%',
      align: 'left',
    },
    {
      keyId: 2,
      mappingId: 'id',
      mappingKey: 'status',
      headingName: 'Referral Status',
      colType: 'capitaliseText',
      width: '25%',
      align: 'left',
    },
    {
      keyId: 3,
      mappingId: 'id',
      mappingKey: 'loyaltyPointsEarned',
      headingName: 'Earned',
      colType: 'ptsText',
      width: '25%',
      align: 'left',
    },
    {
      keyId: 4,
      mappingId: 'id',
      mappingKey: 'created',
      headingName: 'Referred Date',
      colType: 'date',
      width: '25%',
      align: 'left',
    },
  ];

  const clickHandler = () => {
    navigate(`${REFERRAL_DETAILS_NAVIGATE}/1`);
  };

  return (
    <Box sx={commonStyles.tableMainContainer}>
      <CustomTable
        tableData={data?.result}
        metaData={metaData}
        totalCount={data?.totalCount || 0}
        isLoading={isAdminConfigLoading || isLoading}
        isError={isAdminConfigError || isError}
        isSuccess={isAdminConfigSuccess && isSuccess}
        pageHeading="My Referral"
        pageSubHeading="Refer details"
        dispatchFunction={getMyReferralsList}
        customPaperStyle={styles.customPaperStyle}
        customTableStyle={styles.customTableStyle}
        headerChildren={<ReferralInfo />}
        actionButtonText="Refer to friend"
        onActionButtonClick={clickHandler}
        showCount
        showCustomError={configData?.myReferralsPageNewCustomerMessage}
      />
    </Box>
  );
};

export default MyReferral;
