import { useEffect, useState } from 'react';
import { Box, Typography } from '@mui/material';

import { commonStyles } from '../../Assets/Styles/commonStyles';
import { getReferralService } from '../../Services/dashboardService';

const ReferralInfo = () => {
  const [referralData, setReferralData] = useState({
    referralCode: '',
    totalCount: '',
  });

  const fetchReferral = async () => {
    const response = await getReferralService();
    if (response?.data?.data?.data) {
      setReferralData({
        referralCode: response?.data?.data?.data?.[0]?.referralCode,
        totalCount: response?.data?.data?.data?.[0]?.totalCount,
      });
    }
  };

  useEffect(() => {
    fetchReferral();
  }, []);

  return (
    <Box sx={commonStyles.tableHeaderDetailContainer}>
      <Box>
        <Typography sx={commonStyles.displayTextSmall}>
          Your reference code :{' '}
          {referralData?.referralCode ? (
            <Typography component="span" sx={commonStyles.textBold}>
              {referralData?.referralCode}{' '}
            </Typography>
          ) : (
            '--'
          )}
        </Typography>
        <Typography sx={commonStyles.displayTextSmall}>
          Referred count:{' '}
          {String(referralData?.totalCount) ? (
            <Typography component="span" sx={commonStyles.textBold}>
              {referralData?.totalCount}
            </Typography>
          ) : (
            '--'
          )}
        </Typography>
      </Box>
    </Box>
  );
};

export default ReferralInfo;
