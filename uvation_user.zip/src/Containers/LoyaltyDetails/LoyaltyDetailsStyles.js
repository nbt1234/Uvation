import { CAVERNOUS } from '../../Constants/colors';

export const styles = {
  mainContainer: {
    display: 'flex',
    flexDirection: 'column',
    width: '100%',
    padding: '40px 30px',
    alignContent: 'start',
    rowGap: '32px',
    '@media (max-width:700px)': {
      width: 'calc(100% - 60px)',
    },
  },
  headContainer: {
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    width: 'fit-content',
    '& p': {
      color: CAVERNOUS,
    },
  },
  backIcon: {
    marginRight: '10px',
  },
  headerText: {
    textDecoration: 'underline',
  },
};
