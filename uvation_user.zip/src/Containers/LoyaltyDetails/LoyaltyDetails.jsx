import { useEffect, useState } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Box, Typography } from '@mui/material';

import arrowLeft from '../../Assets/Images/arrowLeft.svg';
import OrderDetailCard from '../../Components/OrderDetailCard/OrderDetailCard';
import CustomLoader from '../../Components/Widgets/CustomLoader/CustomLoader';
import ProductDetail from '../../Components/ProductDetail/ProductDetail';
import { SOMETHING_WENT_WRONG } from '../../Constants/errorMessages';
import { getLoyaltyDetail } from '../../Services/loyaltyService';
import { MY_LOYALTY } from '../../Routes/Routes';
import { styles } from './LoyaltyDetailsStyles';

const LoyaltyDetails = () => {
  const { id } = useParams();

  const navigate = useNavigate();

  const [data, setData] = useState();
  const [isLoading, setIsLoading] = useState(true);
  const [isError, setIsError] = useState(false);

  const fetchLoyaltyDetail = async () => {
    setIsLoading(true);
    const response = await getLoyaltyDetail({ id });
    const responseData = response?.data?.data?.data[0];
    const errorCode = response?.error?.data?.code;
    if (responseData) {
      setData(responseData);
    } else if (errorCode === 'INVALID_INPUT') {
      setIsError(true);
      toast.error(response?.error?.data?.message);
      navigate(MY_LOYALTY);
    } else if (response?.error) {
      toast.error(SOMETHING_WENT_WRONG);
      navigate(MY_LOYALTY);
    }
    setIsLoading(false);
  };

  useEffect(() => {
    fetchLoyaltyDetail();
  }, []);

  return (
    <Box sx={styles.mainContainer}>
      <Box sx={styles.headContainer} onClick={() => navigate(MY_LOYALTY)}>
        <Typography component="img" src={arrowLeft} sx={styles.backIcon} />
        <Typography sx={styles.headerText}>Back to My Loyalty</Typography>
      </Box>
      {isLoading && <CustomLoader />}
      {!isLoading && !isError && data && (
        <>
          <OrderDetailCard data={data} />
          <ProductDetail data={data} />
        </>
      )}
    </Box>
  );
};

export default LoyaltyDetails;
