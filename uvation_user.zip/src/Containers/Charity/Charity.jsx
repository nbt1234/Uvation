/* eslint-disable no-unsafe-optional-chaining */
/* eslint-disable no-empty */
import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useDispatch, useSelector } from 'react-redux';
import InfiniteScroll from 'react-infinite-scroll-component';
import { toast } from 'react-toastify';
import { Box, Typography } from '@mui/material';

import arrowLeft from '../../Assets/Images/arrowLeft.svg';
import CustomSearchBar from '../../Components/CustomSearchBar/CustomSearchBar';
import CustomInput from '../../Components/Widgets/CustomInput/CustomInput';
import CustomButton from '../../Components/Widgets/CustomButton/CustomButton';
import CustomLabel from '../../Components/Widgets/CustomLabel/CustomLabel';
import CircularTick from '../../Assets/Images/tick-circle.svg';
import CustomLoader from '../../Components/Widgets/CustomLoader/CustomLoader';
import SingleCard from '../../Components/SingleCard/SingleCard';
import EmptyImage from '../../Assets/Images/empty.svg';
import useDebounceEffect from '../../Hooks/useDebounceEffect';
import { validationHandler } from '../../Utils/validations';
import { urlservice } from '../../Services/urlService';
import {
  IS_NUMBER_GREATER_THAN_VALIDATION,
  IS_REQUIRED_VALIDATION,
} from '../../Constants/validationConstant';
import {
  IS_REQUIRED_MSG,
  SOMETHING_WENT_WRONG,
  VALUE_GREATER_ERROR,
} from '../../Constants/errorMessages';
import { DEBOUNCE_TIME, LIMIT } from '../../Constants/constants';
import { getLoyaltyPointsService } from '../../Services/dashboardService';
import { getMyCharityList } from '../../Redux/MyDonations/MyDonationsSlice';
import {
  convertLoyaltyPointsToUSD,
  sendDonationRequest,
} from '../../Services/donationSerivice';
import { MY_DONATIONS } from '../../Routes/Routes';
import { commonStyles } from '../../Assets/Styles/commonStyles';
import { styles } from './CharityStyles';

const initialData = {
  pointsToDonate: '',
  activeCard: '',
};

const Charity = () => {
  const { isError, isLoading, isSuccess, data } = useSelector((state) => {
    return state.myDonations.myCharityListData;
  });

  const [formData, setFormData] = useState(initialData);
  const [errorData, setErrorData] = useState(initialData);
  const [isDisabled, setIsDisabled] = useState(true);
  const [loyaltyPointsToUSD, setLoyaltyPointsToUSD] = useState('');
  const [donationList, setDonationList] = useState([]);
  const [searchParams, setSearchParams] = useState(
    urlservice.getQueryStringObject() || ''
  );
  const [skip, setSkip] = useState(0);
  const [loading, setLoading] = useState(false);
  const [loyaltyData, setLoyaltyData] = useState({
    loyaltyPointsBalance: '',
    redeemAmount: '',
  });
  const [scrollId, setScrollId] = useState('');

  const navigate = useNavigate();
  const dispatch = useDispatch();

  const fetchLoyaltyPoints = async () => {
    const response = await getLoyaltyPointsService();
    if (response?.data?.data?.data) {
      setLoyaltyData({
        loyaltyPointsBalance: response?.data?.data?.data?.loyaltyPointsBalance,
        redeemAmount: parseFloat(
          response?.data?.data?.data?.loyaltyPointsRedeemedToUSD
        ).toFixed(2),
      });
    }
  };

  const fetchUSDPoints = async (points) => {
    const response = await convertLoyaltyPointsToUSD({ loyaltyPoints: points });
    setLoyaltyPointsToUSD(response?.data?.data?.data);
  };

  const clickHandler = (id) => {
    setFormData((prev) => {
      return { ...prev, activeCard: id };
    });
  };

  useEffect(() => {
    setDonationList([]);
    setSkip(0);
    const searchObject = {
      skip: 0,
      limit: LIMIT,
      keyword: searchParams?.searchByName,
    };
    dispatch(getMyCharityList(searchObject));
  }, [searchParams]);

  useDebounceEffect(
    () => {
      fetchUSDPoints(formData?.pointsToDonate);
    },
    DEBOUNCE_TIME,
    [formData?.pointsToDonate]
  );

  useEffect(() => {
    fetchLoyaltyPoints();
  }, []);

  useEffect(() => {
    if (data?.result) {
      setDonationList((prev) => [...prev, ...data.result]);
      if (scrollId) {
        try {
          const element = document.getElementById(scrollId);
          if (element) {
            element.scrollIntoView({ behavior: 'smooth' });
          }
        } catch (err) {}
      }
      setScrollId(data?.result?.[data?.result?.length - 1]?.id);
    }
  }, [data]);

  useEffect(() => {
    if (formData?.pointsToDonate && formData?.activeCard) setIsDisabled(false);
    else setIsDisabled(true);
  }, [formData, formData?.activeCard]);

  const handleChangeSearchValue = (value) => {
    setSearchParams(() => {
      return {
        searchByName: value,
      };
    });
    if (value) {
      urlservice.setQueryParameters({
        searchByName: value,
      });
    } else {
      urlservice?.removeParam('searchByName');
    }
  };

  const onClearClickHandler = () => {
    setSkip(0);
    setFormData((prev) => {
      return { ...prev, activeCard: '' };
    });
  };

  const validationConfig = {
    pointsToDonate: {
      [IS_REQUIRED_VALIDATION]: {
        errorMsg: IS_REQUIRED_MSG,
      },
      [IS_NUMBER_GREATER_THAN_VALIDATION]: {
        maxValue: loyaltyData?.loyaltyPointsBalance,
        errorMsg: VALUE_GREATER_ERROR,
      },
    },
  };

  const formValidationHandler = (name, value) => {
    const newFormData = { ...formData, [name]: value };
    validationHandler(newFormData, setErrorData, {
      [name]: validationConfig?.[name],
    });
  };

  const changeHandler = (name, value) => {
    const newValue = value ? Math.abs(parseInt(value, 10)) : value;
    setFormData((prevState) => {
      return { ...prevState, [name]: newValue };
    });
    if (errorData?.[name] && validationConfig?.[name]) {
      formValidationHandler(name, value);
    }
  };

  const fetchData = () => {
    dispatch(getMyCharityList({ skip: skip + LIMIT, limit: LIMIT }));
    setSkip((prev) => prev + LIMIT);
  };
  const displayNoData = () => {
    if (isLoading) {
      return <CustomLoader />;
    } else if (isError) {
      return (
        <Box>
          <Typography sx={styles.errorStyle}>{SOMETHING_WENT_WRONG}</Typography>
        </Box>
      );
    } else if (data && data?.totalCount === 0) {
      return (
        <Box>
          <Typography component="img" src={EmptyImage} />
          <Typography
            sx={styles.imageStyleText}
          >{`It's empty in here`}</Typography>
        </Box>
      );
    }
    return null;
  };

  const requestDonation = async () => {
    if (validationHandler(formData, setErrorData, validationConfig)) {
      const payload = {
        charityId: String(formData?.activeCard),
        loyaltyPoints: formData?.pointsToDonate,
      };
      setLoading(true);
      const response = await sendDonationRequest(payload);
      setLoading(false);
      if (!response.error) {
        toast.success(response?.data?.data?.message);
        navigate(MY_DONATIONS);
      } else {
        toast.error(response.error?.data?.message);
      }
    }
  };

  const getActiveCard = () => {
    const card = donationList?.find((item) => item.id === formData?.activeCard);
    return (
      <>
        <Typography
          sx={styles.imageDonation}
          component="img"
          src={card?.categoryLogoUrl}
        />
        <Typography sx={styles.cardMainText}>{card?.name}</Typography>
      </>
    );
  };

  return (
    <Box sx={styles.mainContainer}>
      <Box sx={styles.upperContainer}>
        <Box sx={styles.headerContainer}>
          <Box
            sx={commonStyles.headContainer}
            onClick={() => navigate(MY_DONATIONS)}
          >
            <Typography component="img" src={arrowLeft} sx={styles.backIcon} />
            <Typography sx={styles.headerText}>Back to My Donations</Typography>
          </Box>
          <Typography
            sx={{ ...commonStyles.displayTextSmall, ...styles.textAlign }}
          >
            Available Loyalty Points Balance :{' '}
            {String(loyaltyData?.loyaltyPointsBalance) ? (
              <Typography component="span" sx={commonStyles.textBold}>
                {loyaltyData?.loyaltyPointsBalance}&nbsp;
              </Typography>
            ) : (
              '--'
            )}
            {String(loyaltyData?.loyaltyPointsBalance) && 'pts'}
          </Typography>
        </Box>
        <Box sx={styles.headerBoxStyle}>
          <Box sx={styles.mainWrapper}>
            <Box sx={styles.inputWrapper}>
              <CustomLabel
                labelText="Enter Loyalty Points to Donate"
                isRequired
              />
              <CustomInput
                name="pointsToDonate"
                value={formData?.pointsToDonate}
                setValue={changeHandler}
                errorMsg={errorData?.pointsToDonate}
                type="number"
                showText={loyaltyPointsToUSD ? `$${loyaltyPointsToUSD}` : ''}
                customInputContainer={styles.customInputContainer}
              />
            </Box>
            <Box sx={styles.flexCenter}>
              {formData?.activeCard ? (
                getActiveCard()
              ) : (
                <Typography sx={styles.cardMainText}>
                  Select a Donation from below List{' '}
                </Typography>
              )}
            </Box>
            <CustomButton
              textContent="Donate"
              type="proceed"
              disabled={isDisabled}
              clickHandler={requestDonation}
              isLoading={loading}
            />
          </Box>
        </Box>
        <Box sx={styles.downWrapper}>
          <CustomSearchBar
            placeholder="Enter Donation name"
            onSearch={handleChangeSearchValue}
            initialValue={searchParams?.searchByName}
            showSearchIcon
            onClearClickHandler={onClearClickHandler}
          />
          <Typography sx={styles.countStyle}>
            {data?.totalCount >= 0 ? (
              <Typography sx={commonStyles.textBold} component="span">
                {data?.totalCount} &nbsp;
              </Typography>
            ) : (
              'No'
            )}
            {data?.totalCount <= 1 ? 'record' : 'records'} found
          </Typography>
        </Box>
      </Box>
      {(isLoading || isError || data?.totalCount === 0) && (
        <Box sx={styles.noDataContainer}>{displayNoData()}</Box>
      )}
      {isSuccess && data?.totalCount !== 0 && (
        <Box id="scrollableDiv" sx={styles.scrollableDivStyle}>
          {!!donationList?.length && data && (
            <InfiniteScroll
              dataLength={donationList?.length}
              next={fetchData}
              hasMore={skip + LIMIT < data?.totalCount}
              loader={<CustomLoader />}
              scrollableTarget="scrollableDiv"
              style={{ overflow: 'hidden' }}
            >
              <Box sx={styles.boxContainer}>
                <Box sx={styles.cardsWrapper}>
                  {donationList?.map((item) => (
                    <SingleCard
                      id={item?.id}
                      key={item?.id}
                      cardContainerStyles={styles.cardContainer}
                      cardStyles={{
                        ...styles.singleCard,
                        ...(formData?.activeCard === item?.id &&
                          styles.activeSingleCard),
                      }}
                      cardImgStyles={styles.cardImg}
                      cardMainTextStyles={{
                        ...styles.cardMainText,
                        ...styles.ellipsisStyle,
                        ...(formData?.activeCard === item?.id &&
                          styles.activeCardMainText),
                      }}
                      cardSubTextStyles={styles.cardSubtextStyles}
                      iconStyles={styles.circularTick}
                      cardImg={item?.categoryLogoUrl}
                      cardMainText={item?.name}
                      cardSubText={item?.categoryName}
                      icon={formData?.activeCard === item?.id && CircularTick}
                      imageContainer={styles.imagecontainer}
                      textContainer={styles.textContainer}
                      handleClick={clickHandler}
                    />
                  ))}
                </Box>
              </Box>
            </InfiniteScroll>
          )}
        </Box>
      )}
    </Box>
  );
};

export default Charity;
