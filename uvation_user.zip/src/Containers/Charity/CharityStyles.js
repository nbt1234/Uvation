import { commonStyles } from '../../Assets/Styles/commonStyles';
import {
  GREY,
  HEROIC_BLUE,
  MORE_THAN_A_WEEK,
  POT_BLACK,
  WHITE,
} from '../../Constants/colors';

export const styles = {
  wrapper: {
    width: '100%',
  },
  mainContainer: {
    width: '100%',
    height: 'calc(100% - 60px)',
    padding: '30px',
    '@media (max-width:900px)': {
      width: 'calc(100vw - 1rem)',
      padding: '16px',
    },
  },
  upperContainer: {
    width: '100%',
    minHeight: '100px',
    height: 'fit-content',
  },
  headerContainer: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '20px',
  },
  backIcon: {
    marginRight: '10px',
  },
  headerText: {
    textDecoration: 'underline',
  },
  textAlign: {
    textAlign: 'right',
  },
  inputWrapper: {
    display: 'flex',
    flexDirection: 'column',
    height: '56px',
    '@media (max-width:600px)': {
      height: 'fit-content',
    },
  },
  customInputContainer: {
    width: '350px',
    '@media (max-width:600px)': {
      width: '250px',
    },
  },
  mainWrapper: {
    width: '100%',
    display: 'flex',
    gap: '20px',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexWrap: 'wrap',
  },
  cardsWrapper: {
    display: 'flex',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: '20px',
    maxWidth: '1110px',
  },
  textStyle: { marginBottom: '15px' },
  headerBoxStyle: {
    boxShadow: `${GREY} 0px 1px 4px`,
    padding: '20px',
    paddingTop: '10px',
    borderRadius: '4px',
    '@media (max-width:900px)': {
      paddingBottom: '20px',
      height: 'fit-content',
    },
    height: '116px',
  },
  noDataContainer: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    width: '100%',
    marginTop: '20px',
  },
  downWrapper: {
    marginTop: '20px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  countStyle: {
    textAlign: 'right',
  },
  scrollableDivStyle: {
    marginTop: '20px',
    height: 'calc(100% - 250px)',
    overflow: 'auto',
    width: '100%',
    maxHeight: '400px',
    ...commonStyles.customScrollBar,
    '@media (max-width:900px)': {
      height: 'calc(100% - 400px)',
      marginTop: '20px',
    },
    '@media (max-width:600px)': {
      height: '100%',
      marginTop: '20px',
    },
  },
  imageDonation: {
    width: '80px',
    margin: '0px 20px ',
    borderRadius: '4px',
    '@media (max-width:900px)': {
      margin: '-16px 20px 0px 0px',
    },
  },
  flexCenter: {
    display: 'flex',
    alignItems: 'center',
    height: '92px',
  },
  imageStyleText: {
    color: POT_BLACK,
    marginTop: '10px',
    display: 'flex',
    justifyContent: 'center',
  },
  errorStyle: {
    fontSize: '25px',
    fontWeight: '600',
  },
  boxContainer: {
    display: 'flex',
    justifyContent: 'center',
  },
  cardContainer: {
    width: '350px',
    height: '90px',
    margin: '12px 0px',
    position: 'relative',
    bgcolor: WHITE,
    '@media (max-width:600px)': {
      width: '300px',
    },
  },
  singleCard: {
    width: 'inherit',
    height: '90px',
    border: `1.5px solid ${MORE_THAN_A_WEEK}`,
    borderRadius: '10px',
    cursor: 'pointer',
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    position: 'relative',
    boxShadow: 'none',
  },
  activeSingleCard: {
    border: `1.5px solid ${HEROIC_BLUE}`,
  },
  imagecontainer: {
    display: 'flex',
    alignItems: 'center',
    width: '92px',
    margin: '0px 20px',
    '@media (max-width:600px)': {
      width: '62px',
    },
  },
  cardImg: {
    maxWidth: '100%',
    maxHeight: '80px',
    height: 'auto',
    width: 'auto',
    objectFit: 'contain',
    borderRadius: '8px',
  },
  textContainer: {
    width: '75%',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'start',
    marginRight: '15px',
  },
  cardMainText: {
    fontSize: '16px',
    wordBreak: 'break-all',
    color: POT_BLACK,
    letterSpacing: '-0.333333px',
    lineHeight: '22px',
  },
  ellipsisStyle: {
    textOverflow: 'ellipsis',
    overflow: 'hidden',
    width: '200px',
    whiteSpace: 'nowrap',
    textTransform: 'capitalize',
  },
  activeCardMainText: {
    fontWeight: 'bold',
  },
  circularTick: {
    position: 'absolute',
    top: '-14px',
    right: '-14px',
    width: '34.17px',
    height: '34.17px',
  },
  cardSubtextStyles: {
    color: MORE_THAN_A_WEEK,
    fontWeight: 500,
  },
};
