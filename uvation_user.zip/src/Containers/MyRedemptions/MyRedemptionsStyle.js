export const styles = {
  customTableStyle: {
    maxHeight: 'calc(100vh - 270px)',
    '@media(max-height:630px)': {
      maxHeight: '500px',
    },
  },
};
