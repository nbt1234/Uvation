import { Box } from '@mui/material';
import { useSelector } from 'react-redux';

import CustomTable from '../../Components/Widgets/CustomTable/CustomTable';
import { commonStyles } from '../../Assets/Styles/commonStyles';
import { styles } from './MyRedemptionsStyle';
import { getMyRedemptionList } from '../../Redux/MyRedemption/MyRedemptionSlice';

const MyRedemptions = () => {
  const { data, isLoading, isError, isSuccess } = useSelector(
    (state) => state?.myRedemption?.myRedemptionListData
  );

  const metaData = [
    {
      keyId: 1,
      mappingId: 'id',
      mappingKey: 'productImage',
      headingName: 'Product Image',
      colType: 'image',
      width: '20%',
      align: 'left',
    },
    {
      keyId: 2,
      mappingId: 'id',
      mappingKey: 'productName',
      headingName: 'Product Name',
      colType: 'text',
      width: '15%',
      align: 'left',
    },
    {
      keyId: 3,
      mappingId: 'id',
      mappingKey: 'productCode',
      headingName: 'Product Code',
      colType: 'text',
      width: '15%',
      align: 'left',
    },
    {
      keyId: 4,
      mappingId: 'id',
      mappingKey: 'loyaltyPointsUsed',
      headingName: 'Loyalty Points',
      colType: 'ptsText',
      width: '15%',
      align: 'left',
    },
    {
      keyId: 5,
      mappingId: 'id',
      mappingKey: 'orderStatus',
      headingName: 'Order Status',
      colType: 'text',
      width: '15%',
      align: 'left',
    },
    {
      keyId: 6,
      mappingId: 'id',
      mappingKey: 'OrderedAt',
      headingName: 'Order Date',
      colType: 'date',
      width: '20%',
      align: 'left',
    },
  ];

  return (
    <Box sx={commonStyles.tableMainContainer}>
      <CustomTable
        tableData={data?.result}
        metaData={metaData}
        totalCount={data?.totalCount || 0}
        isLoading={isLoading}
        isError={isError}
        customTableStyle={styles.customTableStyle}
        isSuccess={isSuccess}
        pageHeading="My Redemptions"
        showCount
        dispatchFunction={getMyRedemptionList}
      />
    </Box>
  );
};

export default MyRedemptions;
