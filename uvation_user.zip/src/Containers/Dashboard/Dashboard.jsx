/* eslint-disable no-unsafe-optional-chaining */
import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { Box, Typography } from '@mui/material';

import CustomLoader from '../../Components/Widgets/CustomLoader/CustomLoader';
import Card from '../../Components/Card/Card';
import {
  getFreeItemsService,
  getLoyaltyPointsService,
  getPromotionsService,
  getReferralService,
} from '../../Services/dashboardService';
import { commonStyles } from '../../Assets/Styles/commonStyles';
import { styles } from './DashboardStyles';

const DashBoard = () => {
  const { configData } = useSelector((state) => {
    return state.getAdminConfig.adminConfigData;
  });
  const [loyaltyData, setLoyaltyData] = useState({
    loyaltyPointsBalance: '',
    redeemAmount: '',
  });
  const [freeGiftData, setFreeGiftData] = useState({
    totalCount: '',
  });
  const [referralData, setReferralData] = useState({
    referralCode: '',
    totalCount: '',
  });
  const [promotionData, setPromotionData] = useState({ totalCount: '' });
  const [isLoading, setIsLoading] = useState(true);

  const fetchLoyaltyPoints = async () => {
    const response = await getLoyaltyPointsService();
    if (response?.data?.data?.data) {
      setLoyaltyData({
        loyaltyPointsBalance: response?.data?.data?.data?.loyaltyPointsBalance,
        redeemAmount: parseFloat(
          response?.data?.data?.data?.loyaltyPointsRedeemedToUSD
        ).toFixed(2),
      });
    }
  };

  const fetchPromotions = async () => {
    const response = await getPromotionsService();
    if (response?.data?.data?.data) {
      setPromotionData({ totalCount: response?.data?.data?.data?.totalCount });
    }
  };

  const fetchFreeGiftItem = async () => {
    const response = await getFreeItemsService();
    if (response?.data?.data?.data) {
      setFreeGiftData({
        totalCount: response?.data?.data?.data?.totalCount,
      });
    }
  };

  const fetchReferral = async () => {
    const response = await getReferralService();
    if (response?.data?.data?.data) {
      setReferralData({
        referralCode: response?.data?.data?.data?.[0]?.referralCode,
        totalCount: response?.data?.data?.data?.[0]?.totalCount,
      });
    }
  };

  useEffect(() => {
    setIsLoading(true);
    Promise.all([
      fetchPromotions(),
      fetchFreeGiftItem(),
      fetchLoyaltyPoints(),
      fetchReferral(),
    ])
      .then(() => {
        setIsLoading(false);
      })
      .catch(() => {
        setIsLoading(false);
      });
  }, []);

  const displayGiftData = () => {
    if (freeGiftData?.totalCount) {
      return (
        <Typography>
          <Typography sx={commonStyles.textBold} component="span">
            {freeGiftData?.totalCount}&nbsp;
          </Typography>
          gift available at checkout for free
        </Typography>
      );
    } else {
      return '-- gift available at checkout for free';
    }
  };

  const displayRedeemAmountData = () => {
    if (loyaltyData?.redeemAmount) {
      return `$${loyaltyData?.redeemAmount}`;
    } else {
      return '--';
    }
  };

  return (
    <Box sx={styles.mainContainer}>
      {isLoading ? (
        <CustomLoader />
      ) : (
        <>
          <Box sx={styles.containerOne}>
            <Card
              type="loyalty"
              mainHeader="My Loyalty points"
              subHeader="Shop & earn points"
              giftData={displayGiftData()}
              dataArray={[
                {
                  id: '1',
                  key: 'Your current balance:',
                  value: `${
                    loyaltyData?.loyaltyPointsBalance
                      ? `${loyaltyData?.loyaltyPointsBalance}`
                      : '--'
                  }`,
                  spanText: 'pts',
                },
                {
                  id: '2',
                  key: 'It can be redeem for:',
                  value: `${displayRedeemAmountData()}`,
                  spanText: 'at checkout',
                },
              ]}
              spanText="at checkout"
            />
          </Box>
          <Box sx={styles.containerTwo}>
            <Card
              type="referral"
              mainHeader="My Referral"
              subHeader={
                <Typography>
                  Earn
                  <Typography sx={commonStyles.textBold} component="span">
                    &nbsp;
                    {configData?.referrerLoyaltyPoints
                      ? configData?.referrerLoyaltyPoints
                      : '--'}{' '}
                    &nbsp;
                  </Typography>
                  points for every friend
                </Typography>
              }
              dataArray={[
                {
                  id: '1',
                  key: 'Your referral code:',
                  value: `${
                    referralData?.referralCode
                      ? referralData?.referralCode
                      : '--'
                  }`,
                },
                {
                  id: '2',
                  key: 'Referred count:',
                  value: `${
                    String(referralData?.totalCount)
                      ? referralData?.totalCount
                      : '--'
                  }`,
                },
              ]}
              primaryButton={{ text: 'Refer to friends' }}
            />
          </Box>
          <Box sx={styles.containerThree}>
            <Card
              type="promotion"
              mainHeader="My promotions"
              subHeader="Use promotions and get savings"
              primaryButton={{ text: 'See lists' }}
              dataArray={[
                {
                  id: 1,
                  key: 'Promotion Applied on Orders:',
                  value: `${
                    String(promotionData?.totalCount)
                      ? promotionData?.totalCount
                      : '--'
                  }`,
                },
              ]}
            />
          </Box>
        </>
      )}
    </Box>
  );
};

export default DashBoard;
