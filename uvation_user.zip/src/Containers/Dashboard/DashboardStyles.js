import { commonStyles } from '../../Assets/Styles/commonStyles';

export const styles = {
  mainContainer: {
    display: 'flex',
    padding: '32px',
    width: '95%',
    overflow: 'auto',
    flexWrap: 'wrap',
    alignContent: 'start',
    gap: '32px',
    '@media (max-width:600px)': {
      flexDirection: 'column',
    },
    ...commonStyles.customScrollBar,
  },
  containerOne: {
    width: '574px',
    minHeight: '246px',
    height: 'fit-content',
    '@media (max-width:600px)': {
      width: '90%',
    },
  },
  containerTwo: {
    width: '271px',
    minHeight: '246px',
    height: 'fit-content',

    '@media (max-width:600px)': {
      width: '90%',
    },
  },
  containerThree: {
    width: '271px',
    minHeight: '246px',
    height: 'fit-content',
    '@media (max-width:600px)': {
      width: '90%',
    },
  },
};
