import { useEffect, useState } from 'react';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';
import { Box } from '@mui/material';

import CustomTable from '../../Components/Widgets/CustomTable/CustomTable';
import LoyaltyInfo from '../../Components/LoyaltyInfo/LoyaltyInfo';
import { getMyDonationsList } from '../../Redux/MyDonations/MyDonationsSlice';
import { getLoyaltyPointsService } from '../../Services/dashboardService';
import { CHARITY } from '../../Routes/Routes';
import { commonStyles } from '../../Assets/Styles/commonStyles';
import { styles } from './MyDonationsStyles';

const MyDonations = () => {
  const { data, isLoading, isError, isSuccess } = useSelector(
    (state) => state?.myDonations?.myDonationListData
  );

  const [loyaltyData, setLoyaltyData] = useState({
    loyaltyPointsBalance: '',
    redeemAmount: '',
  });

  const navigate = useNavigate();
  const clickHandler = () => {
    navigate(CHARITY);
  };

  const fetchLoyaltyPoints = async () => {
    const response = await getLoyaltyPointsService();
    if (response?.data?.data?.data) {
      setLoyaltyData({
        loyaltyPointsBalance: response?.data?.data?.data?.loyaltyPointsBalance,
        redeemAmount: parseFloat(
          response?.data?.data?.data?.loyaltyPointsRedeemedToUSD
        ).toFixed(2),
      });
    }
  };

  useEffect(() => {
    fetchLoyaltyPoints();
  }, []);

  const metaData = [
    {
      keyId: 1,
      mappingId: 'id',
      mappingKey: 'charityName',
      headingName: 'Charity Name',
      colType: 'text',
      width: '35%',
      align: 'left',
    },
    {
      keyId: 2,
      mappingId: 'id',
      mappingKey: 'loyaltyPointsDonated',
      headingName: 'Loyalty Points',
      colType: 'ptsText',
      width: '20%',
      align: 'left',
    },
    {
      keyId: 3,
      mappingId: 'id',
      mappingKey: 'actualDonatedAmount',
      headingName: 'Amount',
      colType: 'price',
      width: '20%',
      align: 'left',
    },
    {
      keyId: 4,
      mappingId: 'id',
      mappingKey: 'donatedOn',
      headingName: 'Donation Date',
      colType: 'date',
      width: '25%',
      align: 'left',
    },
  ];

  return (
    <Box sx={commonStyles.tableMainContainer}>
      <CustomTable
        tableData={data?.result}
        metaData={metaData}
        totalCount={data?.totalCount || 0}
        isLoading={isLoading}
        isError={isError}
        customPaperStyle={styles.customPaperStyle}
        customTableStyle={styles.customTableStyle}
        isSuccess={isSuccess}
        pageHeading="My Donations"
        showCount
        dispatchFunction={getMyDonationsList}
        headerChildren={
          <LoyaltyInfo
            clickHandler={clickHandler}
            toggleBtn
            btnText="Donate"
            loyaltyData={loyaltyData}
          />
        }
      />
    </Box>
  );
};

export default MyDonations;
