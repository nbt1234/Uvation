import { Box } from '@mui/material';
import { useSelector } from 'react-redux';
import { useNavigate } from 'react-router-dom';

import CustomList from '../../Components/CustomList/CustomList';
import { getMyPromotionsList } from '../../Redux/MyPromotions/MyPromotionsSlice';
import { commonStyles } from '../../Assets/Styles/commonStyles';

const MyPromotions = () => {
  const { data, isLoading, isError, isSuccess } = useSelector((state) => {
    return state.myPromotions?.myPromotionsListData;
  });
  const {
    configData,
    isAdminConfigLoading,
    isAdminConfigSuccess,
    isAdminConfigError,
  } = useSelector((state) => {
    return state.getAdminConfig.adminConfigData;
  });

  const navigate = useNavigate();

  const handleNavigate = (navigationData) => {
    navigate(
      `/my-promotions/details/${navigationData?.marketPlaceOrderId}/${navigationData?.promotionId}`
    );
  };

  return (
    <Box sx={commonStyles.tableMainContainer}>
      <CustomList
        listData={data?.result}
        totalCount={data?.totalCount || 0}
        dispatchFunction={getMyPromotionsList}
        isLoading={isAdminConfigLoading || isLoading}
        isError={isAdminConfigError || isError}
        isSuccess={isAdminConfigSuccess || isSuccess}
        pageHeading="My Promotions"
        navigateHandler={handleNavigate}
        showCount
        showCustomError={configData?.myPromotionPageNewCustomerMessage}
      />
    </Box>
  );
};

export default MyPromotions;
