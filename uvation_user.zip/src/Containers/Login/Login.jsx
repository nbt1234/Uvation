import { Box, Typography } from '@mui/material';

const Login = () => {
  return (
    <Box>
      Hello Uviation !!
      <Typography> Material UI Paragraph tag</Typography>
    </Box>
  );
};

export default Login;
