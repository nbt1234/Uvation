import { CAVERNOUS } from '../../Constants/colors';

export const styles = {
  mainContainer: {
    width: '100%',
    padding: '40px 30px',
  },
  headContainer: {
    display: 'flex',
    alignItems: 'center',
    cursor: 'pointer',
    width: 'fit-content',
    '& p': {
      color: CAVERNOUS,
    },
  },
  backIcon: {
    marginRight: '10px',
  },
  headerText: {
    textDecoration: 'underline',
  },
  mainHeadingText: {
    fontSize: '24px',
    marginTop: '38px',
    fontWeight: '500',
    marginBottom: '17px',
  },
};
