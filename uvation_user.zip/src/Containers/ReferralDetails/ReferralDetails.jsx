import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Box, Typography } from '@mui/material';

import ReferralForm from '../../Components/Referral/ReferralForm/ReferralForm';
import arrowLeft from '../../Assets/Images/arrowLeft.svg';
import { MY_REFERRALS } from '../../Routes/Routes';
import { styles } from './ReferralDetailsStyles';

const initialData = {
  email: '',
  message: '',
};

const ReferralDetails = () => {
  const [formData, setFormData] = useState(initialData);
  const navigate = useNavigate();

  const changeHandler = (name, value) => {
    setFormData((prev) => {
      return {
        ...prev,
        [name]: value,
      };
    });
  };

  return (
    <Box sx={styles.mainContainer}>
      <Box sx={styles.headContainer} onClick={() => navigate(MY_REFERRALS)}>
        <Typography component="img" src={arrowLeft} sx={styles.backIcon} />
        <Typography sx={styles.headerText}>Back to My Referral</Typography>
      </Box>
      <Typography sx={styles.mainHeadingText}>Refer to friend</Typography>
      <ReferralForm formData={formData} changeHandler={changeHandler} />
    </Box>
  );
};

export default ReferralDetails;
