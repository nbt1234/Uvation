/* eslint-disable no-lonely-if */

import { Suspense, useContext, useState, useEffect } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import {
  BrowserRouter as Router,
  Route,
  Routes,
  Outlet,
} from 'react-router-dom';
import { ThemeProvider, Box } from '@mui/material';
import {
  AuthenticatedTemplate,
  useIsAuthenticated,
  useMsal,
  useMsalAuthentication,
} from '@azure/msal-react';
import { InteractionStatus } from '@azure/msal-browser';
// import { initializeApp } from 'firebase/app';
// import { getAnalytics } from 'firebase/analytics';
// import { getMessaging, getToken } from 'firebase/messaging';
import * as _ from 'lodash';

import PrivateRoute from './Routes/PrivateRoute';
import Layout from './Components/Layout/Layout';
import CustomLoader from './Components/Widgets/CustomLoader/CustomLoader';
import theme from './theme';
import DefaultRoute from './Routes/DefaultRoute';
import { WILDCARD } from './Routes/Routes';
import { privateRoutes } from './Routes/PrivateRoutes';
import { commonStyles } from './Assets/Styles/commonStyles';
import { GlobalContext } from './ContextApi/GlobalContext';
import {
  b2cPolicies,
  loginRequest,
  msalConfig,
  silentRequest,
} from './authConfig';
import {
  clearStorageData,
  logoutUserHandler,
  redirectLogout,
} from './Utils/logoutUserHandler';
import {
  loginUser,
  setSingleSignOn,
} from './Redux/SingleSignOn/SingleSignOnSlice';
import { setItem } from './Services/localStorageService';
// import './App.scss';

const App = ({ history }) => {
  const [account, setAccount] = useState({});
  const { instance, inProgress, accounts } = useMsal();
  const { error } = useMsalAuthentication();
  const isAuthenticated = useIsAuthenticated();
  const { socketdata, isUserSignUp } = useContext(GlobalContext);
  const dispatch = useDispatch();
  // const [IsLogin, setIsLogin] = useState(true);

  const { data, isSuccess, isLoading, isError } = useSelector(
    (state) => state.singleSignOn.loginData
    
  );
  useEffect(() => {
    setAccount(accounts[0] || {});
  }, [accounts]);

  useEffect(() => {
    if (!_.isEmpty(account)) {
      dispatch(setSingleSignOn(account));
      setItem('ssoData', account);
      setItem('azureId', account?.idTokenClaims?.sub);
    }
  }, [account]);

  useEffect(() => {
    if (!_.isEmpty(account) && isUserSignUp) {
      dispatch(
        loginUser({
          azureId: account?.idTokenClaims?.sub,
        })
      );
    }
  }, [account, isUserSignUp]);

  useEffect(() => {
    if (data && isSuccess) {
      setItem('loginToken', data?.authToken);
    }
  }, [data]);

  useEffect(() => {
    if (error) {
      if (
        error.errorMessage &&
        error.errorMessage.indexOf('AADB2C90118') > -1
      ) {
        instance
          .loginRedirect(b2cPolicies.authorities.forgotPassword)
          .then(() => {
            window.alert(
              'Password has been reset successfully. \nPlease sign-in with your new password.'
            );
          });
      } else if (
        error.errorMessage &&
        error.errorMessage.indexOf('AADB2C90091') > -1
      ) {
        instance.loginRedirect(loginRequest);
      }
    } else {
      if (
        !isAuthenticated &&
        inProgress === InteractionStatus.None &&
        !sessionStorage.length
      ) {
        instance.loginRedirect(loginRequest);
      } else if (isAuthenticated && accounts) {
        instance.acquireTokenSilent({
          ...silentRequest,
          account: accounts,
        });
        // setuserInfo({
        //   ...userInfo,
        //   userid: accounts[0].localAccountId,
        //   email: accounts[0].username,
        //   fullname: accounts[0].name,
        // });
      }
    }
  }, [isAuthenticated, inProgress, instance]);

  useEffect(() => {
    if (isError) {
      clearStorageData();
      redirectLogout();
    }
  }, [isError]);

  socketdata?.on('logoutfromcurrentsite', () => {
    logoutUserHandler();
    localStorage.clear();
    instance.logoutRedirect(msalConfig.auth.postLogoutRedirectUri);
  });
 

  // const firebaseConfig = {
  //   apiKey: 'AIzaSyB7iPfmtbLKYtUJkqpiM1pUwO8ylJ9v3x8',
  //   authDomain: 'test-7ee7d.firebaseapp.com',
  //   projectId: 'test-7ee7d',
  //   storageBucket: 'test-7ee7d.appspot.com',
  //   messagingSenderId: '710152431651',
  //   appId: '1:710152431651:web:ffa056b10e31e2dcc06996',
  //   measurementId: 'G-F9ZJ9FQ1QZ',
  // };
  // const app = initializeApp(firebaseConfig);
  // const analytics = getAnalytics(app);
  // const messaging = getMessaging(app);



  const getRenderValue = () => {
    if (isLoading || inProgress !== InteractionStatus.None || !isUserSignUp) {
      return (
        <Box
          sx={{
            height: '100vh',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          <CustomLoader />
        </Box>
      );
    }
 
    if (isSuccess && !isError && inProgress === InteractionStatus.None) {
      return (
        <AuthenticatedTemplate>
          <Layout>
            <Outlet />
          </Layout>
        </AuthenticatedTemplate>
      );
    }
    return <Box />;
  };

  return (
    <AuthenticatedTemplate>
      <ThemeProvider theme={theme}>
        <Suspense
          fallback={
            <Box sx={commonStyles.lazyLoaderStyle}>
              <CustomLoader />
            </Box>
          }
        >
          <Router history={history}>
            <Routes>
              <Route
                element={
                  // <Layout>
                  //   <Outlet />
                  // </Layout>
                  getRenderValue()
                }
              >
                {privateRoutes.map((privateRouteDetail) => {
                  // console.log("privateRouteDetail",privateRouteDetail)
                  return (
                    <Route
                      exact
                      path="/"
                      element={<PrivateRoute />}
                      key={privateRouteDetail.id}
                    >
                      <Route
                        exact
                        path={privateRouteDetail.path}
                        element={privateRouteDetail.component}
                      />
                    </Route>
                  );
                })}
              </Route>
              <Route path={WILDCARD} element={<DefaultRoute />} />
            </Routes>
          </Router>
        </Suspense>
      </ThemeProvider>
    </AuthenticatedTemplate>
  );
};

export default App;
