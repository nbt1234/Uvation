import axiosInstance from '../API/axiosInstance';
import { PROMOTION_DETAIL_API } from '../Constants/apiEndpoints';
import { getQsValues } from './helperService';

export const getPromotionDetail = async (data) => {
  const response = { error: '', data: null };
  try {
    const qsValue = getQsValues(data.qsString);
    response.data = await axiosInstance.get(
      `${PROMOTION_DETAIL_API}${data?.orderId}?${qsValue}`
    );
  } catch (err) {
    response.error = err.response;
  }
  return response;
};
