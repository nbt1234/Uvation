import axiosInstance from '../API/axiosInstance';
import { REFER_TO_FRIEND } from '../Constants/apiEndpoints';

export const sendReferralRequest = async (data) => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.post(REFER_TO_FRIEND, data);
  } catch (err) {
    response.error = err.response;
  }
  return response;
};
