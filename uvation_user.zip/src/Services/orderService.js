import axiosInstance from '../API/axiosInstance';
import { PLACE_ORDER_API } from '../Constants/apiEndpoints';

export const placeOrderService = async (data) => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.post(PLACE_ORDER_API, data);
  } catch (err) {
    response.error = err.response;
  }
  return response;
};
