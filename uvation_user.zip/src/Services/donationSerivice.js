import axiosInstance from '../API/axiosInstance';
import {
  DONATION_CONVERSION_API,
  MY_DONATIONS_API,
} from '../Constants/apiEndpoints';
import { getQsValues } from '../Constants/getQsValues';

export const convertLoyaltyPointsToUSD = async (data) => {
  const response = { error: '', data: null };
  try {
    const newQsValue = getQsValues(data);
    response.data = await axiosInstance.get(
      `${DONATION_CONVERSION_API}?${newQsValue}`
    );
  } catch (err) {
    response.error = err.response;
  }
  return response;
};

export const sendDonationRequest = async (data) => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.post(MY_DONATIONS_API, data);
  } catch (err) {
    response.error = err.response;
  }
  return response;
};
