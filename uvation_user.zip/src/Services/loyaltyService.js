import axiosInstance from '../API/axiosInstance';
import { LOYALTY_DETAILS_API } from '../Constants/apiEndpoints';

export const getLoyaltyDetail = async (data) => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.get(
      `${LOYALTY_DETAILS_API}${data?.id}`
    );
  } catch (err) {
    response.error = err.response;
  }
  return response;
};
