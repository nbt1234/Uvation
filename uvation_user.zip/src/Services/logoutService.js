/* eslint-disable import/no-cycle */
import { UvationAPI } from '../API/axios';
import { getAzureId } from '../Auth/getAzureId';
import { getToken } from '../Auth/getToken';
import { LOGOUT_USER_API } from '../Constants/apiEndpoints';

export const logoutUser = async () => {
  const response = { error: '', data: null };
  try {
    response.data = await UvationAPI.put(
      `${LOGOUT_USER_API}?azureId=${getAzureId()}`,
      {},
      {
        headers: {
          Authorization: getToken(),
        },
      }
    );
  } catch (err) {
    response.error = err.response;
  }
  return response;
};
