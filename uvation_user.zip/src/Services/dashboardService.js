import axiosInstance from '../API/axiosInstance';
import {
  FREE_ITEMS_API,
  LOYALTY_POINTS_API,
  PROMOTION_API,
  REFERRAL_API,
} from '../Constants/apiEndpoints';

export const getFreeItemsService = async () => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.get(FREE_ITEMS_API);
  } catch (err) {
    response.error = err.response;
  }
  return response;
};

export const getPromotionsService = async () => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.get(PROMOTION_API);
  } catch (err) {
    response.error = err.response;
  }
  return response;
};

export const getLoyaltyPointsService = async () => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.get(LOYALTY_POINTS_API);
  } catch (err) {
    response.error = err.response;
  }
  return response;
};

export const getReferralService = async () => {
  const response = { error: '', data: null };
  try {
    response.data = await axiosInstance.get(REFERRAL_API);
  } catch (err) {
    response.error = err.response;
  }
  return response;
};
