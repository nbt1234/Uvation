import { getItem } from '../Services/localStorageService';

export const getAzureId = () => {
  return getItem('azureId');
};
