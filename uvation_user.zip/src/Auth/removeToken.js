import { removeItem } from '../Services/localStorageService';

export const removeToken = () => {
  removeItem('loginToken');
  window.location.replace(`http://${window.location.host}/login`);
};
