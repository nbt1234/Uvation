import { createTheme } from '@mui/material';
import { POT_BLACK } from './Constants/colors';

const theme = createTheme({
  typography: {
    allVariants: {
      fontFamily: ['IBM Plex Sans', 'Regular'].join(','),
      letterSpacing: '0px',
      color: POT_BLACK,
    },
  },
});

export default theme;
