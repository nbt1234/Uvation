import logoutIcon from '../Assets/Images/logoutIcon.svg';

export const ACTION_DROPDOWN_ITEMS = [
  {
    id: 1,
    iconSrc: logoutIcon,
    actionText: 'Logout',
    altText: 'logout img',
    askConfirmation: true,
    confirmationHeading: 'Logout',
    confirmationDescription: `Are you sure you want to logout?`,
    onClickActionItem: () => {},
  },
];
