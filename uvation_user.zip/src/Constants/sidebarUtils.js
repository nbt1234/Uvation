import OverviewIcon from '../Assets/Images/purchase.svg';
import OverviewActiveIcon from '../Assets/Images/purchaseActive.svg';
import GiftIcon from '../Assets/Images/gift.svg';
import GiftActiveIcon from '../Assets/Images/giftActive.svg';
import StarIcon from '../Assets/Images/star.svg';
import StarActiveIcon from '../Assets/Images/starActive.svg';
import CollaborateIcon from '../Assets/Images/collaborate.svg';
import CollaborateActiveIcon from '../Assets/Images/collaborateActive.svg';
import RedemptionsIcon from '../Assets/Images/redeem.svg';
import RedemptionsActiveIcon from '../Assets/Images/redeemActiveIcon.svg';
import DonationIcon from '../Assets/Images/donate.svg';
import DonationActiveIcon from '../Assets/Images/donateActiveIcon.svg';
import {
  DASHBOARD,
  MY_DONATIONS,
  MY_LOYALTY,
  MY_PROMOTIONS,
  MY_REDEMPTIONS,
  MY_REFERRALS,
} from '../Routes/Routes';

export const sidebarData = [
  {
    id: 1,
    name: 'Overview',
    link: DASHBOARD,
    icon: OverviewIcon,
    activeIcon: OverviewActiveIcon,
  },
  {
    id: 2,
    name: 'My Promotions',
    link: MY_PROMOTIONS,
    icon: GiftIcon,
    activeIcon: GiftActiveIcon,
  },
  {
    id: 3,
    name: 'My Loyalty',
    link: MY_LOYALTY,
    icon: StarIcon,
    activeIcon: StarActiveIcon,
  },
  {
    id: 4,
    name: 'My Referral',
    link: MY_REFERRALS,
    icon: CollaborateIcon,
    activeIcon: CollaborateActiveIcon,
  },
  {
    id: 5,
    name: 'My Redemptions',
    link: MY_REDEMPTIONS,
    icon: RedemptionsIcon,
    activeIcon: RedemptionsActiveIcon,
  },
  {
    id: 6,
    name: 'My Donations',
    link: MY_DONATIONS,
    icon: DonationIcon,
    activeIcon: DonationActiveIcon,
  },
];
