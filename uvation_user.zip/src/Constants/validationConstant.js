export const IS_REQUIRED_VALIDATION = 'isRequired';
export const IS_REQUIRED_STRING_VALIDATION = 'isRequiredString';
export const IS_NUMBER_GREATER_THAN_VALIDATION = 'isGreaterThan';
