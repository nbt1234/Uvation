export const SOMETHING_WENT_WRONG = 'Something went wrong.';
export const IS_REQUIRED_MSG = 'This is a required field.';
export const VALUE_GREATER_ERROR =
  'Loyalty points to be donated should be less than available loyalty points';
export const NOT_COMPLETED_SIGNUP =
  'Please complete profile setup on Uvation Identity to continue';
