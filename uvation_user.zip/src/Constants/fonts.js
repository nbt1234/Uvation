export const IBM_PLEX_SANS = 'IBM Plex Sans, sans-serif';
