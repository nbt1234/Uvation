// white
export const WHITE = '#ffffff';

// black
export const POT_BLACK = '#161616';

// Gray
export const BLEACHED_SILK = '#f3f3f3';
export const COLD_MORNING = '#E5E5E5';
export const MORE_THAN_A_WEEK = '#8D8D8D';
export const CAVERNOUS = '#525252';
export const SILVER_GREY = '#DADADA';
export const PORPOISE = '#DADADA';
export const OPAQUE_PORPOISE = '#52525259';
export const METALLIC_SILVER = '#BFBFBF';
export const CHRISTMAS_SILVER = '#E0E0E0';
export const SPANISH_GREY = '#979797';
export const LIGHTHOUSE = '#F4F4F4';
export const UP_IN_SMOKE = '#6d6f6f';
export const UNICORN_SILVER = '#E8E8E8';
export const SHARK_FIN = '#969696';
export const GREY = '#808080';

// brown
export const LEADBELCHER = '#CACACA';

// Blue
export const HEROIC_BLUE = '#0F61FD';
export const BLUEROCRATIC = '#1F6BFC';

// Red
export const RED_PIGMENT = '#EB202B';
export const CHINESE_GOLDFISH = '#F24423';
export const RED = '#FF0000';
