// auth
export const GENERATE_TOKEN_API = 'public/customer/generate-token';
export const LOGOUT_USER_API = 'customer/logout';

// referral
export const REFERRAL_FAQ_API = 'referral-faq';

// promotion
export const PROMOTIONS_API = 'customer/promotions/list';
export const PROMOTION_DETAIL_API = 'customer/promotions/';

// loyalty
export const MY_LOYALTY_LIST_API = 'customer/loyalty-points/list';
export const LOYALTY_DETAILS_API = 'customer/loyalty-points/';

// referral
export const MY_REFERRALS_API = 'customer/referrals';
export const REFER_TO_FRIEND = 'customer/refer';

// dashboard api
export const LOYALTY_POINTS_API = 'customer/loyalty-points';

// get free gift
export const LOYALTY_FREE_ITEM_API = 'customer/loyalty-free-item';

export const FREE_ITEMS_API = 'customer/count/loyalty-free-items';
export const REFERRAL_API = 'customer/count/total-referrals';
export const PROMOTION_API = 'customer/count/promotion';

// utility
export const FILE_DOWNLOAD_API = 'public/file-download';

// redemption
export const MY_REDEMPTIONS_LIST_API = 'customer/redemptions';

//  donations
export const MY_CHARITY_API = 'customer/search-charity';
export const MY_DONATIONS_API = 'customer/donation';
export const DONATION_CONVERSION_API = 'customer/converted/donation';

// Order
export const PLACE_ORDER_API = 'customer/order/loyalty-items';

//  getAdminConfig
export const GET_ADMIN_CONFIG = 'customer/configuration';
