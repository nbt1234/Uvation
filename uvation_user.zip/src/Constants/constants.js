export const DEFAULT_ROW_PER_PAGE = 5;
export const ROW_PER_PAGE_OPTIONS = [5, 10, 15];
export const DEBOUNCE_TIME = 500;
export const LIMIT = 12;
