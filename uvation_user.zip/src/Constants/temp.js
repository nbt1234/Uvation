export const faqData = [
  {
    id: 1,
    title: 'Sit reprehenderit eiusmod ad laborum.',
    description:
      'Aliquip elit consectetur nisi minim ullamco. Eu commodo sint aute pariatur irure qui ut cillum amet sint exercitation. Mollit eiusmod sit ut pariatur amet proident duis id cupidatat laboris commodo pariatur.',
  },
  {
    id: 2,
    title: 'Sit reprehenderit eiusmod ad laborum.',
    description:
      'Aliquip elit consectetur nisi minim ullamco. Eu commodo sint aute pariatur irure qui ut cillum amet sint exercitation. Mollit eiusmod sit ut pariatur amet proident duis id cupidatat laboris commodo pariatur.',
  },
  {
    id: 3,
    title: 'Sit reprehenderit eiusmod ad laborum.',
    description:
      'Aliquip elit consectetur nisi minim ullamco. Eu commodo sint aute pariatur irure qui ut cillum amet sint exercitation. Mollit eiusmod sit ut pariatur amet proident duis id cupidatat laboris commodo pariatur.',
  },
  {
    id: 4,
    title: 'Sit reprehenderit eiusmod ad laborum.',
    description:
      'Aliquip elit consectetur nisi minim ullamco. Eu commodo sint aute pariatur irure qui ut cillum amet sint exercitation. Mollit eiusmod sit ut pariatur amet proident duis id cupidatat laboris commodo pariatur.',
  },
  {
    id: 5,
    title: 'Sit reprehenderit eiusmod ad laborum.',
    description:
      'Aliquip elit consectetur nisi minim ullamco. Eu commodo sint aute pariatur irure qui ut cillum amet sint exercitation. Mollit eiusmod sit ut pariatur amet proident duis id cupidatat laboris commodo pariatur.',
  },
  {
    id: 6,
    title: 'Sit reprehenderit eiusmod ad laborum.',
    description:
      'Aliquip elit consectetur nisi minim ullamco. Eu commodo sint aute pariatur irure qui ut cillum amet sint exercitation. Mollit eiusmod sit ut pariatur amet proident duis id cupidatat laboris commodo pariatur.',
  },
  {
    id: 7,
    title: 'Sit reprehenderit eiusmod ad laborum.',
    description:
      'Aliquip elit consectetur nisi minim ullamco. Eu commodo sint aute pariatur irure qui ut cillum amet sint exercitation. Mollit eiusmod sit ut pariatur amet proident duis id cupidatat laboris commodo pariatur.',
  },
];
