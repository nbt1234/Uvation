/* eslint-disable react/jsx-filename-extension */
import { createRoot } from 'react-dom/client';
import { PublicClientApplication } from '@azure/msal-browser';
import { Provider } from 'react-redux';
import { MsalProvider } from '@azure/msal-react';

import { GlobalProvider } from './ContextApi/GlobalContext';
import { msalConfig } from './authConfig';
import './index.css';
import './index.scss';

import App from './App';
import { store } from './Redux/store';

const root = createRoot(document.getElementById('root'));
const msalInstance = new PublicClientApplication(msalConfig);

root.render(
  <MsalProvider instance={msalInstance}>
    <Provider store={store}>
      <GlobalProvider>
        <App />
      </GlobalProvider>
    </Provider>
  </MsalProvider>
);
