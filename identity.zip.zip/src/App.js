import React, { useState, useEffect, useContext, useReducer, createContext } from "react";
import { useHistory, Redirect, useLocation } from "react-router-dom";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal,
  useAccount,
  useIsAuthenticated,
  useMsalAuthentication,
} from "@azure/msal-react";
import {
  EventType,
  InteractionStatus,
  InteractionType,
} from "@azure/msal-browser";
import { b2cPolicies, loginRequest, silentRequest } from "./authConfig";
import "./App.scss";
// import { useMsal, useAccount } from "@azure/msal-react";
import Welcome from "./Components/Welcome/Welcome";
import TermsCondition from "./Components/TermsCondition/TermsCondition";
import MyAccount from "./Components/MyAccount/MyAccount";
import NotificationMessage from "./Components/Notification&Message/Notificatio&Message";
import MyAccount1 from "./Components/MyAccount/MyAccount1";
import MyAccount2 from "./Components/MyAccount/MyAccount2";
import MyAccount3 from "./Components/MyAccount/MyAccount3";
import MyAccount4 from "./Components/MyAccount/MyAccount4";
import { GlobalContext, GlobalProvider } from "./ContextApi/GlobalContext";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Loading } from "carbon-components-react";
import TicketInfo from "./Components/TicketDetails/TicketInfo";
import { Test } from "./Components/MyAccount/Test ";
import { Azureuser } from "./Components/Azurform.js/Azureuser";
import { intitialState , datareducer } from "./Reducer/Reducer";
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getMessaging, getToken, onMessage } from "firebase/messaging";
import { msalConfig } from "./authConfig";
import Apicallin from "./Apicallin";
export const Contextprovider = createContext()

export default function App() {
  const { instance, inProgress, accounts } = useMsal();
   const account = useAccount(accounts[0] || {});
  const { login, result, error } = useMsalAuthentication();
  const isAuthenticated = useIsAuthenticated();
  const { userInfo, setuserInfo, socketdata  } = useContext(GlobalContext);
  const [useralldata ,dispatch] = useReducer(datareducer ,intitialState);

  useEffect(()=>{
    dispatch({type:"USER_All_DATA",payload:account?.idTokenClaims})
  },[])
  useEffect(() => {
    if (error) {
      if (
        error.errorMessage &&
        error.errorMessage.indexOf("AADB2C90118") > -1
      ) {
        instance
          .loginRedirect(b2cPolicies.authorities.forgotPassword)
          .then((res) => {
            window.alert(
              "Password has been reset successfully. \nPlease sign-in with your new password."
            );
          });
      } else if (
        error.errorMessage &&
        error.errorMessage.indexOf("AADB2C90091") > -1
      ) {
        instance.loginRedirect(loginRequest);
      }
    } else {
      if (!isAuthenticated && inProgress === InteractionStatus.None) {
        instance.loginRedirect(loginRequest);
      } else if (isAuthenticated && accounts) {
        instance.acquireTokenSilent({
          ...silentRequest,
          account: accounts,
        });
      }
    }
  }, [isAuthenticated, inProgress, instance]);


  const location = window.location.href;

  const firebaseConfig = {
    apiKey: "AIzaSyB7iPfmtbLKYtUJkqpiM1pUwO8ylJ9v3x8",
    authDomain: "test-7ee7d.firebaseapp.com",
    projectId: "test-7ee7d",
    storageBucket: "test-7ee7d.appspot.com",
    messagingSenderId: "710152431651",
    appId: "1:710152431651:web:ffa056b10e31e2dcc06996",
    measurementId: "G-F9ZJ9FQ1QZ",
  };
  const app = initializeApp(firebaseConfig);
  const analytics = getAnalytics(app);
  const messaging = getMessaging(app);

  useEffect(() => {
    getToken(messaging, {
      vapidKey:
        "BDZ82di-xS1O1kApecoWhmOvFFR5s3Ay82VXxj3JcSOC8CX92LPvs0wv31EDhMSj59yUCiRbffT7m4AieWotWLA",
    })
      .then((currentToken) => {
        if (currentToken) {
          localStorage.setItem("notification_token", currentToken);
          // axios
          //   .get(
          //     `http://localhost:8000/api/all_notification?currentoken=${currentToken}`
          //   )
          //   .then((res) => {});
        } else {
          // Show permission request UI
          console.log(
            "No registration token available. Request permission to generate one."
          );
          // ...
        }
      })
      .catch((err) => {
        console.log("An error occurred while retrieving token. ", err);
        // ...
      });
  }, []);

  onMessage((event) => {});
 
  socketdata?.on("logoutfromcurrentsite", () => {
    sessionStorage.clear();

    instance.logoutRedirect(msalConfig.auth.postLogoutRedirectUri);
  });
  
  return (
    <>
      <AuthenticatedTemplate>
        <Contextprovider.Provider value={{useralldata ,dispatch}}>
          <Apicallin/>
        <Router>
          <Switch>
            {/* <Route exact path="/" component={Mstest} /> */}
            <Route exact path="/home" component={Welcome} />
            <Route exact path="/azureuser" component={Azureuser} />
            <Route exact path="/Test" component={Test} />
            <Route exact path="/terms" component={TermsCondition} />
            <Route exact path="/account/info" component={MyAccount} />
            {/* <Route exact path="/account/companyinfo" component={Companyinfo} /> */}
            <Route exact path="/account/companyinfo" component={MyAccount1} />

            <Route exact path="/account/security" component={MyAccount2} />

            <Route exact path="/account/privacy" component={MyAccount3} />

            <Route exact path="/account/deactivate" component={MyAccount4} />
            <Route exact path="/notification" component={NotificationMessage} />
            <Route exact path="/ticketdetail/:id" component={TicketInfo} />
            
            {location == "https://identity.uvation.com/" && (
              <Redirect to="/home" />
            )}
          </Switch>
        </Router>
        </Contextprovider.Provider>
      </AuthenticatedTemplate>
      <UnauthenticatedTemplate>
        <Loading active withOverlay />
      </UnauthenticatedTemplate>
    </>
  );
}
