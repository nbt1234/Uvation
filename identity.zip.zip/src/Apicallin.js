import axios from 'axios';
import React, { useContext, useEffect } from 'react'
import { Contextprovider } from './App';

const Apicallin = () => {
  const {useralldata , dispatch} = useContext(Contextprovider)
console.log("useralldata" , useralldata);
    useEffect(() => {
        // if (useralldata?.UserInfodata?.sub) {
          axios.post("https://notifications.uvation.com/api/getStatus", {
            userid: useralldata?.UserInfodata?.sub,
          }).then((res) => {
           dispatch({type:"SYSTEMNOTIFICATION_DATA_RESPONSE",payload:res?.data})
           
          })
        // }
      }, [useralldata?.UserInfodata?.sub , useralldata?.ToogleBtn]);
      const rewardCreateContact = (response) => {
        axios
          .post("https://appsapi.uvation.com:8080/reward/contact", {
            azureId: useralldata?.UserInfodata?.sub,
            firstName: useralldata?.UserInfodata?.given_name,
            lastName: account?.idTokenClaims?.family_name,
            email: useralldata?.UserInfodata?.email,
            referral: useralldata?.UserInfodata?.referralCode,
            phoneNo: `${useralldata?.UserInfodata?.extension_CountryCode}${useralldata?.UserInfodata?.MobileNumber}`,
            ssContactId: response?.id,
          })
          .then((res) => { });
      };
    
      const createSalesforceContact = (response, timeout) => {
        axios
          .post(
            `${response?.response?.instance_url}/services/data/v43.0/sobjects/Contact`,
            {
              FirstName: useralldata?.UserInfodata?.given_name,
              LastName: useralldata?.UserInfodata?.family_name,
              Phone: "",
              email: useralldata?.UserInfodata?.email,
              MailingCity: "",
              MailingCountry: "",
              MailingState: "",
              MailingStreet: "",
              MailingPostalCode: "",
              Company_Name__c: "",
              Azure_User_ID__c: useralldata?.UserInfodata?.sub,
            },
            {
              headers: {
                Authorization: `Bearer ${response?.response?.access_token}`,
                "Access-Control-Allow-Origin": "*",
              },
            }
          )
          .then((res) => {
            if (res?.status == 201) {
              clearInterval(timeout);
              fetchtimeset = setInterval(() => {
                setgetsalesforcedata(true);
              }, 5000);
              rewardCreateContact(res?.data);
            }
          });
      };
    
      const checkUserExists = (response1) => {
        axios
          .get(
            `${response1?.response?.instance_url}/services/apexrest/userExists?azureId=${useralldata?.UserInfodata?.sub}`,
            {
              headers: {
                Authorization: `Bearer ${response1?.response?.access_token}`,
                "Access-Control-Allow-Origin": "*",
              },
            }
          )
          .then((res) => {
            if (res?.data?.Exists == false) {
              timeout = setInterval(() => {
                createSalesforceContact(response1, timeout);
              }, 5000);
            }
          });
      };
      const salesforcetoken = () => {
        axios
          .post("https://appsapi.uvation.com:8080/identity/sftoken")
          .then((res) => {
           dispatch({type:"SALESFORCE_DATA",payload:res?.data})
            setfetchdata(res.data);
            checkUserExists(res.data);
            // createSalesforceContact(res.data);
          });
      };
      useEffect(() => {
        if (useralldata?.UserInfodata) {
          salesforcetoken();
        }
      }, [useralldata?.UserInfodata]);    
  return (
    <div>
      
    </div>
  )
}

export default Apicallin
