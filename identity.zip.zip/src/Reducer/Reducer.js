
export const intitialState = {
    UserLogsdata:null,
    UserallNotification:[],
    UserInfodata : [],
    ImageBase64 : "data:image/png;base64," ,
    LoaderData : false ,
    SystemNotificationResponse :null,
    ToogleBtn :false,
    SalesForceData :null,
}

export const datareducer = (state = intitialState, { type, payload })=>{
    
    switch(type){
        case "USER_SIGNIN_LOGS":
            return {...state,UserLogsdata: payload};
        case "USER_All_NOTIFICATION":
            return {...state ,UserallNotification: payload};
        case "USER_All_DATA":
            return {...state ,UserInfodata: payload};
        case "USER_IMAGE_BASE64":
            return {...state ,ImageBase64: payload};
        case "LOADER_DATA":
            return {...state ,LoaderData: payload}
        case "SYSTEMNOTIFICATION_DATA_RESPONSE":
            return {...state ,SystemNotificationResponse: payload}
        case "SYSTEMNOTIFICATION_TOOGLEBTN":
             return {...state ,ToogleBtn: payload}   
        case "SALESFORCE_DATA":
            return {...state ,SalesForceData: payload}   
    }

    
}

