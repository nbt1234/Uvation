import React, { createContext, useState, useEffect } from "react";
import axios from "axios";
import moment from "moment";
import qs from "qs";
import { Loading } from "carbon-components-react";
import {
  MsalAuthenticationTemplate,
  useMsal,
  useAccount,
} from "@azure/msal-react";
import {
  InteractionRequiredAuthError,
  InteractionType,
} from "@azure/msal-browser";
import { loginRequest, protectedResources } from "../authConfig";
import { Undefined } from "@carbon/icons-react";
import { io } from "socket.io-client";
import proimg from "../../src/img/profile.png";

let backend_url = "https://appsapi.uvation.com:8080";
const userdataajj = localStorage.getItem("font");

export const GlobalContext = createContext();
export const GlobalProvider = (props) => {
  const { instance, accounts, inProgress } = useMsal();
  let userdaat = {};
  const account = useAccount(accounts[0] || {});
  const daass = accounts.map((value) => {
    if (value.idTokenClaims.auth_time) {
      userdaat.login = new Date(
        value.idTokenClaims.auth_time * 1000
      ).toUTCString();
    }
    if (value.idTokenClaims.ProfileEdit_DateTime) {
      userdaat.profile_edit_time = new Date(
        value.idTokenClaims.ProfileEdit_DateTime * 1000
      ).toUTCString();
    }
    if (value?.idTokenClaims?.isProfileEdited) {
      userdaat.isProfileEditeds = value?.idTokenClaims?.isProfileEdited;
    }
    if (value.idTokenClaims.PasswordResetDateTime) {
      userdaat.PasswordResetDateTimeu = new Date(
        value.idTokenClaims.PasswordResetDateTime * 1000
      ).toUTCString();
    }
    if (value.idTokenClaims.ChangeMFAphnNo_DateTime) {
      userdaat.ChangeMFAphnNo_DateTimeuser = new Date(
        value.idTokenClaims.ChangeMFAphnNo_DateTime * 1000
      ).toUTCString();
      if (value.idTokenClaims.ForgotPasswordDateTime) {
        userdaat.ForgotPasswordDateTime = new Date(
          value.idTokenClaims.ForgotPasswordDateTime * 1000
        ).toUTCString();
      }
      if (value.idTokenClaims.isForgotPassword) {
        userdaat.isForgotPasswords = value.idTokenClaims.isForgotPassword;
      }
    }
    return <></>;
  });

  localStorage.setItem("supportusermail", account?.idTokenClaims?.email);
  localStorage.setItem(
    "supportusername",
    `${account?.idTokenClaims?.given_name}${" "}${account?.idTokenClaims?.family_name
    }`
  );
  const [imagedata, setimagedata] = useState(false);
  const [helloData, setHelloData] = useState(null);
  const [contactsalesforce, setcontactsalesforce] = useState([]);
  const [updatecompanyinfo, setupdatecompanyinfo] = useState();
  const [contactinfodata, setcontactinfodata] = useState([]);
  const [companyname, setcompanyname] = useState();
  const [socketdata, setsocketdata] = useState();
  const [userstatus, setuserstatus] = useState();
  const [IsOn, setIsOn] = useState();
  const [toggledata, settoggledata] = useState(false);
  const [notificationuser, setnotificationuser] = useState();
  const [Ontgle, setOntgle] = useState(true);
  const [eventdat, seteventdat] = useState();
  const [tooglebtn , settooglebtn] = useState(false);
  const [cloudopen, setcloudopen] = useState(false);
  const usernameinfo = "zendesk_admin@uvation.com";
  const passwordinfo = "H9dh0DH72gF";
  const headers = {
    Authorization: "Basic " + btoa(`${usernameinfo}:${passwordinfo}`),
  };
  const accountdata = account;
  useEffect(() => {
    if (account && inProgress === "none" && !helloData) {
      instance
        .acquireTokenSilent({
          scopes: protectedResources.apiHello.scopes,
          account: account,
        })
        .then((response) => {
        
          callApiWithToken(
            response.accessToken,
            account?.idTokenClaims?.sub,
            protectedResources.apiHello.endpoint
          ).then((response) => setHelloData(response));
        })
        .catch((error) => {
         
          if (error instanceof InteractionRequiredAuthError) {
            if (account && inProgress === "none") {
              instance
                .acquireTokenPopup({
                  scopes: protectedResources.apiHello.scopes,
                })
                .then((response) => {
                  callApiWithToken(
                    response.accessToken,
                    account?.idTokenClaims?.sub,
                    protectedResources.apiHello.endpoint
                  ).then((response) => { });
                })
                .catch((error) => error);
            }
          }
        });
    }
  }, [account, inProgress, instance]);

  useEffect(() => {
    axios
      .post("https://appsapi.uvation.com:8080/identity/access_token")
      .then((res) => {
        setMsAccessToken(res);
        if (res?.data?.status === "success") {
        }
      });
  }, []);
  const [toggle, settoggle] = useState({
    Quick: false,
    Support: false,
    Notification: false,
    Account: false,
    openHide: "",
    closedHide: "",
    pendingHide: "",
    newHide: "",
    tabselect: "",
  });
  const [AlldataWidget, setAlldataWidget] = useState([
    {
      id: "",
      datesubject: "",
    },
  ]);
  const [TablePagination, setTablePagination] = useState({
    totalrow: "",
    page: 1,
    per_page: 10,
    widget_page: 1,
    widget_per_page:
      window.innerHeight <= 800
        ? Math.floor((window.innerHeight - 275) / 80)
        : window.innerHeight > 800
          ? Math.floor((window.innerHeight - 295) / 76)
          : 10,
  });

  // const datandtime = new Date(1666327163);
  // var dateTime = new Date(166632716 * 1000);
  const timestamp = account?.idTokenClaims?.auth_time;
  const date = new Date(timestamp * 1000);
  const [loadingnotification, setloadingnotification] = useState(false);
  const [MsAccessToken, setMsAccessToken] = useState("");
  const [photo, setphoto] = useState(proimg);
  const [comment, setcomment] = useState([]);
  let userchat = {};
  {
    comment.map((chat) => {
      if (chat.time) {
        userchat.time = chat.time;
      }
      if (chat.message) {
        userchat.message = chat.message;
      }
      if (chat.service) {
        userchat.service = chat.service;
      }
      return <></>;
    });
  }
  const [getsalesforcedata, setgetsalesforcedata] = useState(false);
  // var getsalesforcedata = false;
  const [userInfo, setuserInfo] = useState({
    userid: null,
    fullname: null,
    email: null,
    phone: null,
    country: null,
    address: null,
    city: null,
    state: null,
    postalCode: null,
    companyName: null,

  });


  const [fetchdata, setfetchdata] = useState(null);
  const [ToggleBtnMode, setToggleBtnMode] = useState({
    ToggleBtnModeon: "",
    TileOption: "",
    CloseModal: "",
    SelectedTile: "",
    EditTileOption: "",
  });

  const [Modalset, setModalset] = useState({
    personal: "",
    address: "",
    company: "",
  });

  const usernotification_token = localStorage.getItem("notification_token");
  localStorage.setItem("newuser_d", account?.idTokenClaims?.newUser);
  useEffect(() => {
    if (userdaat) {
      axios
        .post("https://notifications.uvation.com:443/api/user_signup", {
          userid: account?.idTokenClaims?.sub,
          login_time: userdaat?.login,
          forgot_password_time: userdaat?.ForgotPasswordDateTime,
          change_password_time: userdaat?.PasswordResetDateTimeu,
          change_mfa_time: userdaat?.ChangeMFAphnNo_DateTimeuser,
          profile_edit_time: userdaat?.profile_edit_time,
          newuser: account?.idTokenClaims?.newUser,
          platform: "uvation identity",
          forgot_password: userdaat.isForgotPasswords,
          token: usernotification_token,
        })
        .then((res) => {
          axios
            .post(
              "https://notifications.uvation.com:443/api/all_notifications",
              {
                userid: account?.idTokenClaims?.sub,
                platform: "uvation identity",
              }
            )
            .then((res) => {
              setloadingnotification(false);
              setnotificationuser(res?.data?.data);
            });
        });
    }
  }, [account, loadingnotification]);

  // const constusernotification = () => {

  // };
  // useEffect(() => {
  //   if (loadingnotification) {
  //     constusernotification();
  //   }
  // }, [account, loadingnotification]);

  useEffect(() => {
    setuserInfo({
      ...userInfo,
      userid: account?.idTokenClaims?.sub,
      fullname: `${account?.idTokenClaims?.given_name}${" "}${account?.idTokenClaims?.family_name}`,
      email: account?.idTokenClaims?.email,
      phone: account?.idTokenClaims?.MobileNumber,
      country: account?.idTokenClaims?.country,
      address: account?.idTokenClaims?.streetAddress,
      city: account?.idTokenClaims?.city,
      state: account?.idTokenClaims?.state,
      postalCode: account?.idTokenClaims?.postalCode,
      companyName: account?.idTokenClaims?.extension_CompanyName,
      countryCode: account?.idTokenClaims?.extension_CountryCode,
    });
  }, [account]);

  const countFetch = async () => {
    const responeall = await axios.post(
      `${backend_url}/identity/get_user_ticket`,
      { email: userInfo?.email },
      {
        headers: {
          "Content-Type": "multipart/form-data",
        },
      }
    );

    const responeallWidget = await axios
      .post(`${backend_url}/identity/get_user_ticket`, {
        email: userInfo?.email,
        page_no: 1,
        per_page: 9,
      })
      .then((response) => {
        response.data.status !== "failed" &&
          setAlldataWidget(
            response?.data?.data?.results.map((tic) => ({
              id: `${tic.id}`,
              datesubject: (
                <div>
                  <p
                    style={{
                      fontSize: "14px",
                      lineHeight: "18px",
                      fontWeight: "600",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {tic.subject}
                  </p>
                  <p
                    style={{
                      width: "130px",
                      fontSize: "12px",
                      lineHeight: "15px",
                      fontWeight: "400",
                      overflow: "hidden",
                      textOverflow: "ellipsis",
                      whiteSpace: "nowrap",
                    }}
                  >
                    {moment(tic.created_at).format("llll")}
                  </p>
                </div>
              ),
            }))
          );
      });
    setTablePagination({
      ...TablePagination,
      totalrow: responeall.data.data.count,
    });
  };
 

  useEffect(() => {
    if (userInfo?.userid) {
      countFetch();
    }
  }, [
    TablePagination.widget_page,
    TablePagination.widget_per_page,
    userInfo.userid,
  ]);
  let fetchtime;
  let timeout;
  let fetchtimeset;

  const rewardCreateContact = (response) => {
    axios
      .post("https://appsapi.uvation.com:8080/reward/contact", {
        azureId: account?.idTokenClaims?.sub,
        firstName: account?.idTokenClaims?.given_name,
        lastName: account?.idTokenClaims?.family_name,
        email: account?.idTokenClaims?.email,
        referral: account?.idTokenClaims?.referralCode,
        phoneNo: `${account?.idTokenClaims?.extension_CountryCode}${account?.idTokenClaims?.MobileNumber}`,
        ssContactId: response?.id,
      })
      .then((res) => { });
  };

  const createSalesforceContact = (response, timeout) => {
    axios
      .post(
        `${response?.response?.instance_url}/services/data/v43.0/sobjects/Contact`,
        {
          FirstName: account?.idTokenClaims?.given_name,
          LastName: account?.idTokenClaims?.family_name,
          Phone: "",
          email: account?.idTokenClaims?.email,
          MailingCity: "",
          MailingCountry: "",
          MailingState: "",
          MailingStreet: "",
          MailingPostalCode: "",
          Company_Name__c: "",
          Azure_User_ID__c: account?.idTokenClaims?.sub,
        },
        {
          headers: {
            Authorization: `Bearer ${response?.response?.access_token}`,
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        if (res?.status == 201) {
          clearInterval(timeout);
          fetchtimeset = setInterval(() => {
            setgetsalesforcedata(true);
          }, 5000);
          rewardCreateContact(res?.data);
        }
      });
  };

  const checkUserExists = (response1) => {
    axios
      .get(
        `${response1?.response?.instance_url}/services/apexrest/userExists?azureId=${account?.idTokenClaims?.sub}`,
        {
          headers: {
            Authorization: `Bearer ${response1?.response?.access_token}`,
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        if (res?.data?.Exists == false) {
          timeout = setInterval(() => {
            createSalesforceContact(response1, timeout);
          }, 5000);
        }
      });
  };
  const salesforcetoken = () => {
    axios
      .post("https://appsapi.uvation.com:8080/identity/sftoken")
      .then((res) => {
        setfetchdata(res.data);
        checkUserExists(res.data);
        // createSalesforceContact(res.data);
      });
  };

  useEffect(() => {
    if (account) {
      salesforcetoken();
    }
  }, [account]);

  useEffect(() => {
    if (fetchdata) {
      axios
        .get(
          `${fetchdata?.response?.instance_url}/services/apexrest/ContactInfo?azureId=${account?.idTokenClaims?.sub}`,
          {
            headers: {
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              "Access-Control-Allow-Origin": "*",
            },
          }
        )
        .then((res) => {
          if (res?.data?.status == "Success") {
            clearInterval(fetchtime);
            clearInterval(fetchtimeset);
            setcontactinfodata(res?.data?.contactInfo);
            setcontactsalesforce(res?.data?.companyInfo);
          }
        });
    }
  }, [fetchdata, account, getsalesforcedata]);

  const rewarddat_edit = () => {
    axios
      .post("https://appsapi.uvation.com:8080/reward/edit_contact", {
        azureId: account?.idTokenClaims?.sub,
        firstName: account?.idTokenClaims?.given_name,
        lastName: account?.idTokenClaims?.family_name,
        email: account?.idTokenClaims?.email,
        phoneNo: `${account?.idTokenClaims?.extension_CountryCode}${account?.idTokenClaims?.MobileNumber}`,
      })
      .then(() => { });
  };
  useEffect(() => {
    if (contactinfodata?.recordId && fetchdata) {
      axios
        .patch(
          `${fetchdata?.response?.instance_url}/services/data/v41.0/sobjects/contact/${contactinfodata?.recordId}`,
          {
            FirstName: account?.idTokenClaims?.given_name,
            LastName: account?.idTokenClaims?.family_name,
            Email: account?.idTokenClaims?.email,
            Phone: account?.idTokenClaims?.MobileNumber,
            MailingStreet: account?.idTokenClaims?.streetAddress,
            MailingCity: account?.idTokenClaims?.city,
            MailingState: account?.idTokenClaims?.state,
            MailingCountry: account?.idTokenClaims?.country,
            MailingPostalCode: account?.idTokenClaims?.postalCode,
          },
          {
            headers: {
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              "Access-Control-Allow-Origin": "*",
            },
          }
        )
        .then((res) => { });
    }
  }, [contactinfodata, fetchdata, account]);
  useEffect(() => {
    if (contactinfodata?.recordId !== undefined) {
      axios
        .get(
          `${fetchdata?.response?.instance_url}/services/apexrest/ProfileImage?contactId=${contactinfodata?.recordId}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              "Access-Control-Allow-Origin": "*",
            },
          }
        )
        .then((res) => {
          setphoto(res);
      dispatch({type:"USER_IMAGE_BASE64",payload:"data:image/png;base64,"})
        });
    }
    // }
  }, [contactinfodata, fetchdata, imagedata]);
  useEffect(() => {
    if(fetchdata?.response){
    axios
      .get(
        `${fetchdata?.response?.instance_url}/services/apexrest/GetAccounts`,
        {
          headers: {
            Authorization: `Bearer ${fetchdata?.response?.access_token}`,
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        let keys = Object.keys(res?.data?.accounts);
        let data = [];
        let i = 0;
        for (let x in res?.data?.accounts) {
          i++;
          data.push({ key: keys[i], value: res?.data?.accounts[keys[i]] });
        }
        setcompanyname(data);
      });}
  }, [fetchdata?.response]);

  useEffect(() => {
    if(account?.idTokenClaims?.sub){
    var socket = io.connect("https://notifications.uvation.com:443/");
    socket.on("connected", (i) => {
      // alert("awdaiwdhawuigdahiwd");
    });
    socket.emit("join", { userid: account?.idTokenClaims?.sub });
    setsocketdata(socket);}
  }, [account]);
  useEffect(() => {
    if (account && contactinfodata && userdaat?.profile_edit_time) {
      rewarddat_edit();
    }
  }, [account, contactinfodata, userdaat?.profile_edit_time]);
  useEffect(() => {
    if (userInfo?.userid) {
      axios
        .post("https://appsapi.uvation.com:8080/identity/system_notifi", {
          userid: userInfo?.userid,
          systembutton: "",
        })
        .then((res) => {
          setIsOn(res);
          
        });
    }
  }, [userInfo]);


  return (
    <>
      <GlobalContext.Provider
        value={{
          settooglebtn,
          userstatus,
          settoggledata,
          toggledata,
          fetchdata,
          setimagedata,
          imagedata,
          setcloudopen,
          cloudopen,
          setcomment,
          comment,
          socketdata,
          setloadingnotification,
          notificationuser,
          companyname,
          setupdatecompanyinfo,
          updatecompanyinfo,
          setcontactinfodata,
          contactinfodata,
          setcontactsalesforce,
          headers,
          contactsalesforce,
          account,
          IsOn,
          seteventdat,
          eventdat,
          setOntgle,
          Ontgle,
          setIsOn,
          helloData,
          toggle,
          settoggle,
          AlldataWidget,
          setAlldataWidget,
          TablePagination,
          setTablePagination,
          MsAccessToken,
          setMsAccessToken,
          userInfo,
          setuserInfo,
          ToggleBtnMode,
          setToggleBtnMode,
          Modalset,
          setModalset,
          photo,
          accountdata,
          setphoto,
        }}
      >
        {props.children}
      </GlobalContext.Provider>
    </>
  );
};

export const GlobalConsumer = GlobalContext.Consumer;
