import { useEffect, useState } from "react";

import {
  MsalAuthenticationTemplate,
  useMsal,
  useAccount,
} from "@azure/msal-react";
import {
  InteractionRequiredAuthError,
  InteractionType,
} from "@azure/msal-browser";

import { loginRequest, protectedResources } from "../authConfig";
// import { callApiWithToken } from "../fetch";
import { HelloData } from "../components/DataDisplay";
import { UserIdTokenClaims } from "../components/UserIdTokenClaims";
const HelloContent = () => {
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [helloData, setHelloData] = useState(null);

  useEffect(() => {
    if (account && inProgress === "none" && !helloData) {
      instance
        .acquireTokenSilent({
          scopes: protectedResources.apiHello.scopes,
          account: account,
        })
        .then((response) => {
          callApiWithToken(
            response.accessToken,
            protectedResources.apiHello.endpoint
          ).then((response) => setHelloData(response));
        })
        .catch((error) => {
          // in case if silent token acquisition fails, fallback to an interactive method
          if (error instanceof InteractionRequiredAuthError) {
            if (account && inProgress === "none") {
              instance
                .acquireTokenPopup({
                  scopes: protectedResources.apiHello.scopes,
                })
                .then((response) => {
                  callApiWithToken(
                    response.accessToken,
                    protectedResources.apiHello.endpoint
                  ).then((response) => setHelloData(response));
                })
                .catch((error) => console.log(error));
            }
          }
        });
    }
  }, [account, inProgress, instance]);
  return (
    <div>
      {account && account.idTokenClaims && (
        <UserIdTokenClaims idTokenClaims={account.idTokenClaims} />
      )}
      {helloData ? <HelloData helloData={helloData} /> : null}
    </div>
  );
};
