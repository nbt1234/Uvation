import { LogLevel } from "@azure/msal-browser";

export const b2cPolicies = {
  names: {
    // signUpSignIn: "B2C_1A_DEMO1_PROGRESSIVE_PROFILING_SIGNUP_SIGNIN",
    signUpSignIn: "B2C_1A_DEMO1_PROGRESSIVE_SIGNUP_SIGNIN_REFERRAL",
    forgotPassword: "B2C_1A_DEMO1_PASSWORD_RESET",
    deactivate: "B2C_1A_DELETE_MY_ACCOUNT",
    changePassword: "B2C_1A_DEMO1_CHANGE_PASSWORD",
    editmfanumber: "B2C_1A_DEMO1_PROFILEEDIT_MFAPHONENUMBER",
    profileUpdate: "B2C_1A_DEMO1_PROFILEEDIT_ALLUSERDATA",
  },
  authorities: {
    signUpSignIn: {
      authority:
        // "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROGRESSIVE_PROFILING_SIGNUP_SIGNIN",
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROGRESSIVE_SIGNUP_SIGNIN_REFERRAL",
    },
    forgotPassword: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PASSWORD_RESET",
    },
    changePassword: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_CHANGE_PASSWORD",
    },
    profileUpdate: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROFILEEDIT_ALLUSERDATA",
    },
    deactivate: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_DELETE_MY_ACCOUNT",
    },

    editmfanumber: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROFILEEDIT_MFAPHONENUMBER",
    },
  },
  authorityDomain: "uvationidp.b2clogin.com",
};

export const msalConfig = {
  auth: {
    clientId: "70047577-a5d1-4487-b960-8d3abbf2d5e0",
    authority: b2cPolicies.authorities.signUpSignIn.authority,
    knownAuthorities: [b2cPolicies.authorityDomain],
    redirectUri: window.location.origin,
    postLogoutRedirectUri:
      "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/b2c_1a_demo1_progressive_signup_signin_referral/oauth2/v2.0/logout?post_logout_redirect_uri=https://identity.uvation.com/", // Indicates the page to navigate after logout.
    navigateToLoginRequestUrl: true,
  },
  cache: {
    cacheLocation: "sessionStorage",
    storeAuthStateInCookie: false,
  },
  system: {
    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            return;
          case LogLevel.Info:
            return;
          case LogLevel.Verbose:
            return;
          case LogLevel.Warning:
            return;
        }
      },
    },
  },
};

export const loginRequest = {
  scopes: [
    "openid",
    "profile",
    "offline_access",
    "https://uvationidp.onmicrosoft.com/tasks-api/tasks.write",
  ],
};
export const silentRequest = {
  scopes: ["openid", "profile", "offline_access"],
  loginHint: "example@domain.net",
};

export const protectedResources = {
  apiHello: {
    endpoint: "https://appsapi.uvation.com:8080/identity/hello",
    scopes: ["https://uvationidp.onmicrosoft.com/tasks-api/tasks.read"], // e.g. api://xxxxxx/access_as_user
  },
};
