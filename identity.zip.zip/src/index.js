import React from "react";
import ReactDOM from "react-dom";
import {
  EventType,
  InteractionType,
  PublicClientApplication,
} from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { b2cPolicies, msalConfig } from "./authConfig";
import App from "./App.js";
import { Provider } from "react-redux";
import ChatStore from "./stores/chatStore";
import "./index.scss";
import { Router } from "react-router-dom";
import { GlobalContext, GlobalProvider } from "./ContextApi/GlobalContext";

const msalInstance = new PublicClientApplication(msalConfig);

ReactDOM.render(
  <React.StrictMode>
    <MsalProvider instance={msalInstance}>
      <Provider store={ChatStore}>
        <GlobalProvider>
          {/* <Router> */}
          <App />
          {/* </Router> */}
        </GlobalProvider>
      </Provider>
    </MsalProvider>
  </React.StrictMode>,
  document.getElementById("root")
);
