import React, { useState, useEffect, useContext } from "react";
import { Link } from "react-router-dom";
import UiHeader from "./../Header/UiHeader";
import {
  ArrowRight16,
  Forum32,
  Launch16,
  Notification32,
  Security32,
  SettingsAdjust32,
  User32,
  ShoppingCart32,
  Box32,
  Chat24,
  Warning32,
  Close32,
  Gift32,
} from "@carbon/icons-react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

// import { request } from "../../api";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import {
  Button,
  ButtonSet,
  ToastNotification,
  ModalBody,
  ComposedModal,
} from "carbon-components-react";
import { b2cPolicies } from "../../authConfig";
import { useMsal, useAccount } from "@azure/msal-react";
import cloudnetwork from "../../img/network--enterprise.svg";
import { Contextprovider } from "../../App";



const settings = {
  arrows: false,
  dots: true,
  pauseOnHover: true,
  infinite: true,
  speed: 1000,
  autoplay: true,
  // variableWidth: false,
  slidesToShow: 1,
  slidesToScroll: 1,
  // arrows: true,
};

function ProgressBar({ percentage }) {
  return (
    <div className="progress-bar-wrapper">
      <div className="progress-bar" style={{ width: `${percentage}%` }} />
    </div>
  );
}

const Welcome = () => {
  const {useralldata} = useContext(Contextprovider)
  const {
    toggle,
    settoggle,
   
    setToggleBtnMode,
    ToggleBtnMode,
    setcloudopen,
    cloudopen,
  } = useContext(GlobalContext);
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [percentage, setpercentage] = useState(0);

  useEffect(() => {
    // request();
    setpercentage(
      Math.floor(
        (Object.values(useralldata?.UserInfodata).filter(function (value) {
          return value != null || undefined;
        }).length /
          Object.values(useralldata?.UserInfodata).length) *
          parseInt(100)
      )
    );
  }, [useralldata?.UserInfodata]);
  return (
    <div className="welcomepage">
      <ComposedModal danger open={cloudopen} size="md">
        <div className="close_button" onClick={() => setcloudopen(false)}>
          {" "}
          <Close32 />
        </div>
        <ModalBody hasForm>
          <div className="additional_status">
            <span className="warning_status">
              <Warning32 />
            </span>
            <p className="bx--modal-content__text">
              To access all of our services either re-login or add profile. To
              enable your MFA & provide us additional required information for
              optimal user experience.
            </p>
          </div>
          <Button
            onClick={() => {
              instance.loginRedirect(b2cPolicies.authorities.profileUpdate);
            }}
          >
            Add Address
          </Button>
        </ModalBody>
      </ComposedModal>
      <UiHeader />
      <div className="bx--grid bx--no-gutter main_div">
        <div className="bx--row welcome">
          <div className="bx--col banner">
            <div>
              <p>Welcome,</p>
              <h2 className="user">
                {useralldata?.UserInfodata ? useralldata?.UserInfodata.fullname : ""}
                {""} {useralldata?.UserInfodata ? useralldata?.UserInfodata.surname : ""}
              
              </h2>
            </div>
            <div className="progress_bar">
              <p>
                Profile completion <span>{percentage}%</span>
              </p>
              <ProgressBar percentage={percentage} />
              <Link to="/account/info">Complete your profile</Link>
            </div>
            {percentage != 100 ? (
              <ToastNotification
                kind="info"
                notificationType="toast"
                lowContrast={true}
                iconDescription="Cancel"
                caption={
                  <div className="toast-btnset">
                    <Button
                      size="small"
                      kind="primary"
                      as={Link}
                      to="/account/info"
                    >
                      Add now
                    </Button>
                  </div>
                }
                subtitle={
                  <span>
                    Hi, {useralldata?.UserInfodata ? useralldata?.UserInfodata?.fullname : ""}
                    {""} {useralldata?.UserInfodata ? useralldata?.UserInfodata?.surname : ""}!
                    Letting us know your personal details will help us creating
                    the best experience for you. Would you like to complete them
                    now?
                  </span>
                }
                role="alert"
                timeout={0}
                statusIconDescription="false"
                title="Your personal details"
              />
            ) : (
              ""
            )}
          </div>
        </div>

        <div className="bx--row destinations filterBlock ">
          <div className="bx--col-lg-16 title">
            <h5>Destinations</h5>
          </div>
          <div className="uvation_cloud bx--col-lg-8  bx--col-sm-16 bx--no-gutter--right">
            {/*  ?: alert(fgfgfg)} */}
            <Link
              to="#"
              onClick={() => {
                {
                  !useralldata?.UserInfodata?.newUser
                    ? window.open("https://portal.uvation.com", "_blank")
                    : setcloudopen(true);
                }
              }}
            >
              <div className="card">
                <div className="picto-icon">
                  <svg
                    focusable="false"
                    preserveAspectRatio="xMidYMid meet"
                    xmlns="http://www.w3.org/2000/svg"
                    fill="currentColor"
                    width="32"
                    height="32"
                    viewBox="0 0 32 32"
                    aria-hidden="true"
                  >
                    <path d="M25.7983,10a10,10,0,0,0-19.62.124A7.4964,7.4964,0,0,0,7.5,25H8V23H7.5a5.4961,5.4961,0,0,1-.377-10.9795l.8365-.0571.09-.8335A7.9934,7.9934,0,0,1,23.7368,10Z"></path>
                    <path d="M28,12H18a2.0023,2.0023,0,0,0-2,2v4H12a2.0023,2.0023,0,0,0-2,2V30H30V14A2.0023,2.0023,0,0,0,28,12ZM12,28V20h4v8Zm16,0H18V14H28Z"></path>
                    <path d="M20 16H22V20H20zM24 16H26V20H24zM20 22H22V26H20zM24 22H26V26H24z"></path>
                    <title>Network enterprise</title>
                  </svg>
                  {/* <CloudServices32 /> */}
                </div>
                <div className="title">
                  <h3>Uvation Services Platform (USP)</h3>
                </div>
                <div className="description">
                  <p>
                    Click here to access the Uvation Services Platform (USP)
                    <p className="technology_partner">
                      Here, you can manage all your Uvation products and
                      services in one place.
                    </p>
                  </p>
                </div>
                {!useralldata?.UserInfodata?.newUser ? (
                  <div className="open">
                    Open <Launch16 />
                  </div>
                ) : (
                  <div className="open">
                    <ArrowRight16 />
                  </div>
                )}
              </div>
            </Link>
          </div>
          <div className="bx--col-lg-8   bx--col-sm-16 bx--no-gutter--right">
            <Link
              to="#"
              onClick={() => {
                {
                  !useralldata?.UserInfodata?.newUser
                    ? window.open(
                        "https://marketplace.uvation.com/mooauth/actions/sendAuthorizationRequest/?relayState=https%3A%2F%2Fmarketplace.uvation.com%2Fcustomer%2Faccount%2Flogin%2Freferer%2FaHR0cHM6Ly9sb2NhbGhvc3QvbWFnZW50by8%252C%2F",
                        "_blank"
                      )
                    : setcloudopen(true);
                }
              }}
            >
              <div className="card">
                <div className="picto-icon">
                  <ShoppingCart32 />
                </div>
                <div className="title">
                  <h3>Marketplace</h3>
                </div>
                <div className="description">
                  <p>
                    Visit the Uvation Marketplace to view our products, manage
                    your orders, create wishlists, and more.
                    <p className="technology_partner">
                      We’re constantly adding exciting new products to the
                      marketplace, so visit regularly to get the best deals.
                    </p>
                  </p>
                </div>

                {!useralldata?.UserInfodata?.newUser ? (
                  <div className="open">
                    Open <Launch16 />
                  </div>
                ) : (
                  <div className="open">
                    <ArrowRight16 />
                  </div>
                )}
              </div>
            </Link>
          </div>
          <div className="bx--col-lg-8 uvation_cloud  bx--col-sm-16 bx--no-gutter--right">
            {/*  ?: alert(fgfgfg)} */}
            <Link
              to="#"
              onClick={() => {
                // setcloudopen(true)
                {
                  !useralldata?.UserInfodata?.newUser
                    ? window.open("https://support.uvation.com", "_blank")
                    : setcloudopen(true);
                }
              }}
            >
              <div className="card">
                <div className="picto-icon">
                  <Forum32 />
                </div>
                <div className="title">
                  <h3>Support Center</h3>
                </div>
                <div className="description">
                  <p>
                    Access the Support Center to submit service tickets, chat
                    with a service technician, or request other types of
                    assistance.
                    <p className="technology_partner">
                      You can also{" "}
                      <span className="technical_support">
                        call technical support at +1 8336204702.
                      </span>
                    </p>
                  </p>
                </div>
                {!useralldata?.UserInfodata?.newUser ? (
                  <div className="open">
                    Open <Launch16 />
                  </div>
                ) : (
                  <div className="open">
                    <ArrowRight16 />
                  </div>
                )}
              </div>
            </Link>
          </div>
          <div className="bx--col-lg-8  bx--col-sm-16 bx--no-gutter--right">
            {/*  ?: alert(fgfgfg)} */}
            <Link
              to="#"
              onClick={() => {
                {
                  !useralldata?.UserInfodata?.newUser
                    ? window.open("https://rewards.uvation.com/", "_blank")
                    : setcloudopen(true);
                }
              }}
            >
              <div className="card">
                <div className="picto-icon">
                  <Gift32 />
                </div>
                <div className="title">
                  <h3>Uvation Rewards</h3>
                </div>
                <div className="description">
                  <p>
                    Visit the Uvation Rewards center to manage your loyalty
                    points, spend cloud credits, and more.
                    <p className="technology_partner">
                      Uvation is the only technology partner that offers rewards
                      with every purchase.
                    </p>
                  </p>
                </div>
                {!useralldata?.UserInfodata?.newUser ? (
                  <div className="open">
                    Open <Launch16 />
                  </div>
                ) : (
                  <div className="open">
                    <ArrowRight16 />
                  </div>
                )}
              </div>
            </Link>
          </div>
        </div>
        <div className="bx--row destinations mobFilterBlock">
          <div className="bx--col title ">
            <h5>Destinations</h5>
          </div>
        </div>
        <Slider {...settings}>
          <div className="action">
            <div className="">
              <Link
                to="#"
                onClick={() => {
                  {
                    !useralldata?.UserInfodata?.newUser
                      ? window.open("https://portal.uvation.com", "_blank")
                      : setcloudopen(true);
                  }
                }}
              >
                <div className="card">
                  <div className="picto-icon">
                    <img src={cloudnetwork} alt="#" />
                  </div>
                  <div className="title">
                    <h3>Uvation Services Platform (USP)</h3>
                  </div>
                  <div className="description">
                    <p>
                      Open our Cloud Portal page to access the Uvation Services
                      Platform (USP).
                      <p className="technology_partner">
                        Here, you can manage all your Uvation products and
                        services in one place.
                      </p>
                    </p>
                  </div>

                  {!useralldata?.UserInfodata?.newUser ? (
                    <div className="open">
                      Open <Launch16 />
                    </div>
                  ) : (
                    <div className="open">
                      <ArrowRight16 />
                    </div>
                  )}
                </div>
              </Link>
            </div>
          </div>
          <div className="action">
            <div className="">
              <Link
                to="#"
                onClick={() => {
                  {
                    !useralldata?.UserInfodata?.newUser
                      ? window.open(
                          "https://marketplace.uvation.com/mooauth/actions/sendAuthorizationRequest/?relayState=https%3A%2F%2Fmarketplace.uvation.com%2Fcustomer%2Faccount%2Flogin%2Freferer%2FaHR0cHM6Ly9sb2NhbGhvc3QvbWFnZW50by8%252C%2F",
                          "_blank"
                        )
                      : setcloudopen(true);
                  }
                }}
              >
                <div className="card">
                  <div className="picto-icon">
                    <ShoppingCart32 />
                  </div>
                  <div className="title">
                    <h3>Marketplace</h3>
                  </div>
                  <div className="description">
                    <p>
                      Visit the Uvation Marketplace to view our products, manage
                      your orders, create wishlists, and more.
                      <p className="technology_partner">
                        We’re constantly adding exciting new products to the
                        marketplace, so visit regularly to get the best deals.
                      </p>
                    </p>
                  </div>
                  {!useralldata?.UserInfodata?.newUser ? (
                    <div className="open">
                      Open <Launch16 />
                    </div>
                  ) : (
                    <div className="open">
                      <ArrowRight16 />
                    </div>
                  )}
                </div>
              </Link>
            </div>
          </div>
          <div className="action">
            <div className="">
              <Link
                to="#"
                onClick={() => {
                  // setcloudopen(true)
                  {
                    !useralldata?.UserInfodata?.newUser
                      ? window.open("https://support.uvation.com", "_blank")
                      : setcloudopen(true);
                  }
                }}
              >
                <div className="card">
                  <div className="picto-icon">
                    <Forum32 />
                  </div>
                  <div className="title">
                    <h3>Support Center</h3>
                  </div>
                  <div className="description">
                    <p>
                      Access the Support Center to submit service tickets, chat
                      with a service technician, or request other types of
                      assistance.
                      <p className="technology_partner">
                        You can also{" "}
                        <span className="technical_support">
                          call technical support at +1 8336204702.
                        </span>
                      </p>
                    </p>
                  </div>
                  {!useralldata?.UserInfodata?.newUser ? (
                    <div className="open">
                      Open <Launch16 />
                    </div>
                  ) : (
                    <div className="open">
                      <ArrowRight16 />
                    </div>
                  )}
                </div>
              </Link>
            </div>
          </div>
          <div className="action">
            <div className="">
              <Link
                to="#"
                onClick={() => {
                  {
                    !useralldata?.UserInfodata?.newUser
                      ? window.open("https://rewards.uvation.com/", "_blank")
                      : setcloudopen(true);
                  }
                }}
              >
                <div className="card">
                  <div className="picto-icon">
                    <Gift32 />
                  </div>
                  <div className="title">
                    <h3>Uvation Rewards</h3>
                  </div>
                  <div className="description">
                    <p>
                      Visit the Uvation Rewards center to manage your loyalty
                      points, spend cloud credits, and more.
                      <p className="technology_partner">
                        Uvation is the only technology partner that offers
                        rewards with every purchase.
                      </p>
                    </p>
                  </div>
                  {!useralldata?.UserInfodata?.newUser ? (
                    <div className="open">
                      Open <Launch16 />
                    </div>
                  ) : (
                    <div className="open">
                      <ArrowRight16 />
                    </div>
                  )}
                </div>
              </Link>
            </div>
          </div>
        </Slider>
        <div className="bx--row action">
          <div className="bx--col-lg-16 title">
            <h5>Action</h5>
          </div>

          <div className="bx--col-lg-4 uvation_cloud bx--no-gutter--right">
            <Link to="/account/info">
              <div className="card">
                <div className="icon">
                  <User32 />
                </div>
                <div className="title">
                  <h3>Manage Your Account</h3>
                </div>
                <div className="desc">
                  <p>
                    Open the account management page to update your personal
                    information, change your sign-in credentials, and adjust
                    your contact preferences.
                  </p>
                </div>
                <div className="open">
                  <ArrowRight16 />
                </div>
              </div>
            </Link>
          </div>

          <div className="bx--col-lg-4 bx--no-gutter--right">
            <Link to="/notification">
              <div className="card">
                <div className="icon">
                  <Notification32 />
                </div>
                <div className="title">
                  <h3>Notifications & Messages</h3>
                </div>
                <div className="desc">
                  <p>
                    Review all notifications and messages related to your
                    account, including sign-in logs.
                  </p>
                </div>
                <div className="open">
                  <ArrowRight16 />
                </div>
              </div>
            </Link>
          </div>
          <div className="bx--col-lg-4 bx--no-gutter--right">
            <Link to="/account/security">
              <div className="card">
                <div className="icon">
                  <Security32 />
                </div>
                <div className="title">
                  <h3>Security Settings</h3>
                </div>
                <div className="desc">
                  <p>
                    Change your password and configure multi-factor
                    authentication to protect your account.
                  </p>
                </div>
                <div className="open">
                  <ArrowRight16 />
                </div>
              </div>
            </Link>
          </div>
          <div className="bx--col-lg-4 bx--no-gutter--right">
            <Link to="/terms">
              <div className="card">
                <div className="icon">
                  <Box32 />
                </div>
                <div className="title">
                  <h3>Terms & Conditions</h3>
                </div>
                <div className="desc">
                  <p>
                    Read Uvation’s Terms & Conditions for use of our services.
                  </p>
                </div>
                <div className="open">
                  <ArrowRight16 />
                </div>
              </div>
            </Link>
          </div>
          <div className="bx--col-lg-4 uvation_cloud bx--no-gutter--right">
            <Link to="/account/privacy">
              <div className="card">
                <div className="icon">
                  <SettingsAdjust32 />
                </div>
                <div className="title">
                  <h3>Privacy Settings</h3>
                </div>
                <div className="desc">
                  <p>
                    Review our Privacy Statement and change your contact
                    preferences for specific types of notifications.
                  </p>
                </div>
                <div className="open">
                  <ArrowRight16 />
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>
      <div
        className="chat-bot-icon"
        onClick={() =>
          settoggle({
            ...toggle,
            Support: !toggle.Support,
            tabselect: 1,
          })
        }
      >
        <Chat24 />
      </div>
      <div
        className="chat-bot-icon2"
        onClick={() =>
          settoggle({
            ...toggle,
            Support: !toggle.Support,
            tabselect: 1,
          })
        }
      >
        <Chat24 />
      </div>
    </div>
  );
};

export default Welcome;
