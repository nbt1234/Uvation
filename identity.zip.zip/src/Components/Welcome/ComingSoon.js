import React from 'react'
import { Grid } from 'carbon-components-react'
import UiHeader from '../Header/UiHeader'
import { User32, IbmCloud32,ArrowRight16 ,Notification32 ,Security32,Box32 ,Launch16 ,Forum32} from '@carbon/icons-react'
import { Link } from 'react-router-dom'
function ComingSoon() {
    return (
        <>
        <UiHeader />
        <div className='commingsoon 
         bg-black'>
            <h1>Notifications & Messages</h1>
        </div>
        <Grid>
                <div className="bx--row action ">
                    
                    <div className="bx--col-lg-4 bx--no-gutter--right">
                        
                        <Link to="/notification">
                            <div className="card pt-5">
                                <div className="picto-icon">
                                <Forum32 />
                                </div>
                                <div className="title">
                                    <h3>Support Notification & messages </h3>
                                </div>
                                <div className="desc">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.Ualiquam pharetra dapibus.</p>
                                </div>
                                <div className="open">Open
                                    <Launch16 />
                                </div>
                            </div>
                        </Link>
                    </div>
                    <div className="bx--col-lg-4 bx--no-gutter--right">
                        <Link to="/notification">
                            <div className="card">
                                <div className="icon">
                                <IbmCloud32 />
                                </div>
                                <div className="title">
                                    <h3>Cloud Notification & messages</h3>
                                </div>
                                <div className="desc">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut aliquam pharetra dapibus.</p>
                                </div>
                                <div className="open">
                                open
                                <Launch16 />
                                </div>
                            </div>
                        </Link>
                    </div>
                    <div className="bx--col-lg-4 bx--no-gutter--right">
                        <Link to="/notification">
                            <div className="card">
                                <div className="icon">
                                <Notification32 />
                                        </div>
                                        <div className="title"><h3>identity Notification & messages</h3>
                                </div>
                                <div className="desc">
                                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Ut aliquam pharetra dapibus.</p>
                                </div>
                                <div className="open">open
                                <Launch16 />
                                </div>
                            </div>
                        </Link>
                    </div>
                </div>
            </Grid>
        </>
    )
}

export default ComingSoon
