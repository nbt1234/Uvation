import { Header } from "carbon-components-react";
import React from "react";
import { Link } from "react-router-dom";
import Logo from "./../../img/logo.png";

const MainHeader = () => {

  return (
    <div className="header">
      <Header aria-label="Header">
        <div className="logo">
          <Link to="/home">
            <img src={Logo} alt="Logo" />
            <p>Uvation identity</p>
          </Link>
        </div>
      </Header>
    </div>
  );
};

export default MainHeader;
