import React, { useContext, useEffect, useState } from "react";
import {
  Button,
  Header,
  HeaderGlobalAction,
  HeaderGlobalBar,
  HeaderMenu,
  HeaderMenuItem,
  HeaderNavigation,
  HeaderPanel,
} from "carbon-components-react";
import {
  Notification20,
  Settings20,
  User20,
  User32,
  Logout20,
  Close20,
  Headset20,
  Switcher20,
  Home20,
  ChevronDown20,
  ShoppingCatalog20,
} from "@carbon/icons-react";
import QuickSetting from "./HeaderPanel/QuickSetting";
import SupportHelp from "./HeaderPanel/SupportHelp";
import Notification from "./HeaderPanel/Notification";
import { Link } from "react-router-dom";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import UvationLogo25 from "./../../img/logo.png";
import { useMsal } from "@azure/msal-react";
import { msalConfig } from "../../authConfig";
import proimg from "../../img/profile.png";
import { Contextprovider } from "../../App";

const UiHeader = () => {
  const {useralldata} = useContext(Contextprovider)

  const {
    toggle,
    settoggle,
    photo,
    accountdata,
    socketdata,
    notificationuser,
  } = useContext(GlobalContext);

  const [manage, setManage] = useState(false);
  const [account, setAccount] = useState(false);
  const [home, setHome] = useState(true);
  const ShowLogout = () => {
    setAccount(!account);
    setHome(false);
  };
  const ShowManage = () => {
    setManage(!manage);
    setHome(false);
  };

  const { instance } = useMsal();

  function QuickOpen() {
    settoggle({
      ...toggle,
      Quick: !toggle.Quick,
      Support: false,
      Notification: false,
      Account: false,
    });
  }
  function SupportOpen() {
    document.getElementById("test17").value = "";
    document.getElementById("test323").value = "";
    settoggle({
      ...toggle,
      Quick: false,
      Support: !toggle.Support,
      Notification: false,
      Account: false,
      tabselect: 0,
    });
  }
  function NotificationOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: false,
      Notification: !toggle.Notification,
      Account: false,
    });
  }
  function AcconutOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: false,
      Notification: false,
      Account: !toggle.Account,
    });
  }
  function SwitcherOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: false,
      Notification: false,
      Account: false,
      switcher: !toggle.switcher,
    });
  }
  const user_image = localStorage.getItem("image_user");
  return (
    <>
      <div className="SC_header">
        <Header aria-label="IBM Platform Name">
          <div className="header">
            <div className="logo">
              <Link to="/home">
                <img src={UvationLogo25} alt="UvationLogo25" />
                <p> identity</p>
              </Link>
            </div>
          </div>
          <HeaderGlobalBar>
            <HeaderNavigation aria-label="IBM [Platform]">
              <HeaderMenu aria-label="Manage" menuLinkName="Manage">
                <HeaderMenuItem element={Link} to="/account/security">
                  Security Setting
                </HeaderMenuItem>
                <HeaderMenuItem element={Link} to="/account/info">
                  My account
                </HeaderMenuItem>
              </HeaderMenu>
            </HeaderNavigation>

            <div className="user-account">
              {useralldata?.UserInfodata ? useralldata?.UserInfodata.given_name : ""}
              {""} {useralldata?.UserInfodata ? useralldata?.UserInfodata.family_name : ""}
              {/* {useralldata?.UserInfodata.status
                ? useralldata?.UserInfodata.fullname
                : accountInfo.account.idTokenClaims.name} */}
              's Account
            </div>

            <HeaderGlobalAction
              isActive={toggle.Quick}
              aria-label="Settings"
              onClick={QuickOpen}
            >
              <Settings20 />
            </HeaderGlobalAction>
            <HeaderGlobalAction
              isActive={toggle.Support}
              aria-label="Support"
              onClick={SupportOpen}
            >
              <Headset20 />
            </HeaderGlobalAction>

            <HeaderGlobalAction
              aria-label="Notification"
              isActive={toggle.Notification}
              onClick={NotificationOpen}
            >
              <Notification20 />
              {notificationuser?.length && (
                <span className="notification_count">
                  {notificationuser?.length}
                </span>
              )}
            </HeaderGlobalAction>

            <div className="tooltip_switcherbtn">
              <HeaderGlobalAction
                aria-label="User Account"
                isActive={toggle.Account}
                onClick={AcconutOpen}
              >
                <User20 />
              </HeaderGlobalAction>
            </div>
          </HeaderGlobalBar>
        </Header>
        <div className="Account-notificaton-panel-width">
          <HeaderPanel
            aria-label="Notification"
            aria-labelledby="Notification"
            className="notification-header-panel"
            expanded={toggle.Notification}
          >
            <div
              className="close"
              onClick={() => settoggle({ Notification: !toggle.Notification })}
            ></div>
            <Notification />
          </HeaderPanel>

          <HeaderPanel
            className="account-header-panel"
            aria-label="Account-panel"
            aria-labelledby="Account-panel"
            expanded={toggle.Account}
          >
            <div
              className="close"
              onClick={() => settoggle({ Account: !toggle.Account })}
            ></div>
            <div className="account-panel">
              <div className="user-info-panel">
                <div className="bx--row ">
                  <div className="in-flex-all">
                    <div>
                      <h2>
                        {useralldata?.UserInfodata ? useralldata?.UserInfodata.given_name : ""}
                        {""} {useralldata?.UserInfodata ? useralldata?.UserInfodata.family_name : ""}
                        {/* {useralldata?.UserInfodata.status
                          ? useralldata?.UserInfodata.fullname
                          : accountInfo.account.idTokenClaims.name} */}
                      </h2>
                      <p>
                        {accountdata?.idTokenClaims
                          ? accountdata?.idTokenClaims?.email
                          : ""}
                      </p>
                    </div>

                    <div className="user-icon  image">
                      <img
                        src={
                          photo?.data?.base64
                            ? `${useralldata?.ImageBase64}${photo?.data?.base64}`
                            : proimg
                        }
                        alt="#"
                        className="user-photo"
                      />
                    </div>
                  </div>
                </div>
                <ul>
                  <Link to="/account/info">
                    <li>My Account</li>
                  </Link>
                </ul>
              </div>

              <div className="butn-footer">
                <Button
                  className="butn-width"
                  kind="secondary"
                  renderIcon={Logout20}
                  //   onClick={logout}
                  onClick={() => {
                    socketdata.emit("logout", {
                      userid: useralldata?.UserInfodata?.sub,
                      time: new Date(),
                    });
                    sessionStorage.clear();
                    instance.logoutRedirect(
                      msalConfig.auth.postLogoutRedirectUri
                    );
                  }}
                >
                  Log Out
                </Button>
              </div>
            </div>
          </HeaderPanel>
        </div>

        <div className="HomeHeader-Panel">
          <HeaderPanel aria-label="Header Panel" expanded={toggle.Quick}>
            <div
              onClick={() => settoggle({ Quick: !toggle.Quick })}
              className="close-overlay"
            ></div>
            <div className="Quick-support-panel">
              <div className="QuickSetting">
                <div className="quick-title">
                  <h4>Quick Setting</h4>
                  <Close20
                    className="close-icon-color"
                    onClick={() => settoggle({ Quick: !toggle.Quick })}
                  />
                </div>
                <QuickSetting />
              </div>
            </div>
          </HeaderPanel>
          <HeaderPanel aria-label="Header Panel" expanded={toggle.Support}>
            <div onClick={SupportOpen} className="close-overlay"></div>
            <div className=" Quick-support-panel">
              <div className="SupportHelp">
                <div className="support-title">
                  <h4>Support & Help</h4>
                  <Close20 className="close-icon-color" onClick={SupportOpen} />
                </div>
                <SupportHelp selectvalue={toggle.tabselect} />
              </div>
            </div>
          </HeaderPanel>
          <div>
            <HeaderPanel
              aria-label="Switcher"
              expanded={toggle.switcher}
              className="mobSwitcher"
            >
              <div onClick={SwitcherOpen} className="close-overlay"></div>
              <div className="mob-switcher">
                <div className="switcher-Content">
                  <ul>
                    <Link to="/home">
                      <li
                        onClick={() =>
                          settoggle({
                            ...toggle,
                            Quick: false,
                            Support: false,
                            Notification: false,
                            Account: false,
                            switcher: false,
                          })
                        }
                        className={home ? "active" : ""}
                      >
                        <Home20 /> <span>Home</span>
                      </li>
                    </Link>
                    <li onClick={() => settoggle({ Quick: !toggle.Quick })}>
                      <Settings20 /> <span> Setting </span>
                    </li>

                    <div
                      style={{ position: "relative" }}
                      onClick={ShowManage}
                      className="manage"
                      onMouseLeave={() => {
                        setManage(!manage);
                        setHome(true);
                      }}
                    >
                      <ShoppingCatalog20 /> <span> Manage</span>
                      <ChevronDown20
                        className="arow"
                        style={{ float: "right" }}
                      />
                      {manage ? (
                        <>
                          <Link to="/account/security">
                            <li
                              style={{
                                position: "absolute",
                                top: "2.5rem ",

                                left: "0",
                                paddingLeft: "3.3rem",
                              }}
                              className="security"
                              onClick={() => {
                                setManage(!manage);
                                settoggle({ switcher: false });
                              }}
                            >
                              Security settings
                            </li>
                          </Link>
                          <Link to="/account/info">
                            <li
                              style={{
                                position: "absolute",
                                top: "4.5rem ",
                                left: "0",

                                paddingLeft: "3.3rem",
                              }}
                              className="my-acc"
                              onClick={() => {
                                setManage(!manage);
                                settoggle({ switcher: false });
                              }}
                            >
                              My account
                            </li>
                          </Link>
                        </>
                      ) : null}
                    </div>
                    <div
                      style={{ position: "relative" }}
                      onClick={ShowLogout}
                      onMouseLeave={() => {
                        setAccount(!account);
                        setHome(true);
                      }}
                      className="my-ac"
                    >
                      <User20 /> <span> My Account</span>
                      <ChevronDown20
                        className="arow"
                        style={{ float: "right" }}
                      />
                      {account ? (
                        <Link to="/home">
                          <div
                            style={{
                              position: "absolute",
                              top: "3rem ",
                              left: "0",
                              paddingLeft: "3.3rem",
                              // left: '2.3rem',
                            }}
                            className="logout"
                            onClick={() => {
                              localStorage.clear();
                              instance.logoutRedirect(
                                msalConfig.auth.postLogoutRedirectUri
                              );
                            }}
                          >
                            Logout
                          </div>
                        </Link>
                      ) : null}
                    </div>
                  </ul>
                </div>
              </div>
            </HeaderPanel>
          </div>
        </div>
      </div>
      <div className="SC_header mobHeader">
        <Header aria-label="IBM Platform Name">
          <div className="header">
            <div className="logo">
              <Link to="/home">
                <img src={UvationLogo25} alt="UvationLogo25" />
                <p>Uvation identity</p>
              </Link>
            </div>
          </div>
          <HeaderGlobalBar>
            <HeaderGlobalAction
              isActive={toggle.Support}
              aria-label="Headset"
              onClick={SupportOpen}
            >
              <Headset20 />
            </HeaderGlobalAction>
            <HeaderGlobalAction
              aria-label="Notifications"
              isActive={toggle.Notification}
              onClick={NotificationOpen}
            >
              <Notification20 />
              {notificationuser?.length && (
                <span className="notification_count">
                  {notificationuser?.length}
                </span>
              )}
            </HeaderGlobalAction>
            <HeaderGlobalAction
              aria-label="Switcher"
              isActive={toggle.switcher}
              onClick={SwitcherOpen}
            >
              <Switcher20 />
            </HeaderGlobalAction>
          </HeaderGlobalBar>
        </Header>
      </div>
    </>
  );
};

export default UiHeader;
