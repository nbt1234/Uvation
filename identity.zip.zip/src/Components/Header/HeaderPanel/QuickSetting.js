import React, { useContext, useEffect, useState } from "react";
import {
  Button,
  ModalWrapper,
  FormGroup,
  TextInput,
  Toggle,
} from "carbon-components-react";
import {
  Checkmark24,
  Launch16,
  Edit20,
  Email16,
  MobileCheck20,
  QrCode16,
} from "@carbon/icons-react";
import { GlobalContext } from "../../../ContextApi/GlobalContext";
import { Link } from "react-router-dom";
import axios from "axios";
import { Contextprovider } from "../../../App";
const QuickSetting = () => {
  const {useralldata ,dispatch} = useContext(Contextprovider)
  const {
    ToggleBtnMode,
    setToggleBtnMode,
  } = useContext(GlobalContext);

 
  return (
    <div className="ibm-type-mono">
      <h2>Themes</h2>
      <div className="bx--row theme-div">
        <div className="color-div white">
          <Checkmark24 />
        </div>
      </div>
      <h2>Password</h2>
      <Button
        as={Link}
        to="/account/security"
        kind="ghost"
        size="small"
        renderIcon={Launch16}
      >
        Change Password
      </Button>
      <h2>Edit account details</h2>
      <div className="Edit-div-inner">
        <Button
          as={Link}
          to="/account/info"
          kind="ghost"
          size="small"
          renderIcon={Launch16}
          // onClick={() => setModalset({ ...Modalset, personal: true })}
        >
          Personal info
        </Button>
        <Button
          as={Link}
          to="/account/security"
          kind="ghost"
          size="small"
          renderIcon={Launch16}
        >
          Security & Sign In
        </Button>
        <Button
          as={Link}
          to="/account/privacy"
          kind="ghost"
          size="small"
          renderIcon={Launch16}
        >
          Privacy
        </Button>
      </div>
      {/* <div className="quick-func-list">
        <div>
          <h3>Multi-Factor Authentication</h3>
          <p>Manage your sign in preferences</p>
        </div>

        <div className="toggle-align">
          <Toggle
            // defaultToggled
            toggled={ToggleBtnMode.ToggleBtnModeon}
            aria-label="toggle button"
            id="toggle-1"
            onToggle={
              ToggleBtnMode.ToggleBtnModeon == true
                ? () => setToggleBtnMode({ ...ToggleBtnMode, CloseModal: true })
                : () =>
                    setToggleBtnMode({
                      ...ToggleBtnMode,
                      ToggleBtnModeon: !ToggleBtnMode.ToggleBtnModeon,
                      TileOption: true,
                    })
            }
          />
        </div>
      </div> */}
      {ToggleBtnMode.SelectedTile !== "" ? <h6>You have selected:</h6> : ""}
      {ToggleBtnMode.SelectedTile === "sms" ? (
        <div className="modal__tile_sm">
          <div className="tile__content ">
            <MobileCheck20 />
          </div>
          <div>
            <p>Send the code through SMS</p>
          </div>
          <Edit20
            className="tile_edit_btn"
            onClick={() =>
              setToggleBtnMode({
                ...ToggleBtnMode,
                TileOption: true,
                EditTileOption: true,
              })
            }
          />
        </div>
      ) : ToggleBtnMode.SelectedTile === "email" ? (
        <div className="modal__tile_sm">
          <div className="tile__content ">
            <Email16 />
          </div>
          <div>
            <p>Send the code through email</p>
          </div>
          <Edit20
            className="tile_edit_btn"
            onClick={() =>
              setToggleBtnMode({
                ...ToggleBtnMode,
                TileOption: true,
                EditTileOption: true,
              })
            }
          />
        </div>
      ) : ToggleBtnMode.SelectedTile === "qrcode" ? (
        <div className="modal__tile_sm">
          <div className="tile__content ">
            <QrCode16 />
          </div>
          <div>
            <p>By scanning a QR code</p>
          </div>
          <Edit20
            className="tile_edit_btn"
            onClick={() =>
              setToggleBtnMode({
                ...ToggleBtnMode,
                TileOption: true,
                EditTileOption: true,
              })
            }
          />
        </div>
      ) : (
        ""
      )}

      {/* <div className="quick-func-list">
        <div>
          <h2>Contact Preference</h2>
          <p>Receive non services related news and updates.</p>
        </div>

        <div className="toggle-align">
          <Toggle id="toggle-u-2" aria-label="toggle button" labelText="" />
        </div>
      </div> */}
      <div className="quick-func-list">
        <div>
          <h2>System Notifications</h2>
          <p>Enable to recieve login notifications.</p>
        </div>

        <div className="toggle-align">
          <Toggle
            id="58"
            defaultToggled
            aria-label="toggle button"
            toggled={useralldata?.SystemNotificationResponse?.status}
            onToggle={(event) => {
              if (useralldata?.UserInfodata) {
                axios
                  .post(
                    "https://notifications.uvation.com:443/api/permission",
                    {
                      userid: useralldata?.UserInfodata?.sub,
                      status: event,
                    }
                  )
                  .then((res) => {
                    dispatch({type:"SYSTEMNOTIFICATION_TOOGLEBTN",payload:event})
                    
                  });
              }
            }}
          />
        </div>
      </div>
    </div>
  );
};
export default QuickSetting;
