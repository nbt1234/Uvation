import { Launch20 } from "@carbon/icons-react";
import axios from "axios";
import { Button } from "carbon-components-react";
import React, { useContext } from "react";
import { Link, useHistory } from "react-router-dom";
import { Contextprovider } from "../../../App";
import { GlobalContext } from "../../../ContextApi/GlobalContext";

// const CardForSection = ({ title, describe }) => (
//   <>
//     <div className="in-flex-all">
//       <div className="heading-banner">
//         <h5>{title}</h5>
//         <p>{describe}</p>
//       </div>
//       <Launch20 />
//     </div>
//   </>
// );

const Notification = () => {
  const history = useHistory();
  const { useralldata,dispatch} =useContext(Contextprovider)

  const {
    toggle,
    settoggle,
    notificationuser,
 
    setloadingnotification,
  } = useContext(GlobalContext);

  const notificationcheck = (value) => {
    axios
      .post("https://notifications.uvation.com:443/api/read", {
        userid: useralldata?.UserInfodata?.sub,
        notification_id: value?.id,
      })
      .then((res) => {
        setloadingnotification(true);
      });
  };
  return (
    <div className="notificationBoxMain">
      <div className="div position-relative">
      <div className="Notification-panel">
        <div className="notification-content">
          <h4>Latest notifications</h4>

          {notificationuser?.map((value, index) => {
            return (
              <>
              {value?.zendesk_id !== null || value?.image_change_time !==null ? 
              ( <>
              {value?.zendesk_id &&
              <div
                    className="in-flex-all"
                    onClick={() => notificationcheck(value)}
                  >
                    <div className="heading-banner">
                      <h5>System Notification</h5>
                      <p
                        onClick={() =>
                          history.push(`/ticketdetail/${value.zendesk_id}`)
                        }
                      >
                       Your Zendesk ticket create successfully at :
                        {value?.notification_time}
                      </p>
                    </div>
                    <Launch20 />
                  </div>
          }
                  
                  {value?.image_change_time && <div
                   className="in-flex-all"
                   onClick={() => notificationcheck(value)}
                 >
                   <div className="heading-banner">
                     <h5>System Notification</h5>
                     <p>
                      Your Profile Image Change successfully at: {value?.image_change_time}
                     </p>
                   </div>
                   <Launch20 />
                 </div>
              }</>) :( <div
                  className="in-flex-all"
                  onClick={() => notificationcheck(value)}
                >
                  <div className="heading-banner ">
                    <h5>System Notification</h5>
                    <p>{value?.message}</p>
                  </div>
                  <Launch20 />
                </div>) }        
              </>
            );
          })}

        </div>
      </div>
      <div
        className="bx--row"
        style={{
          position: "absolute",
          bottom: 0,
          right: 0,
          left: 0,
        }}
      >
        <Button
          className="btn-footer"
          kind="secondary"
          onClick={() => {
            axios
              .post("https://notifications.uvation.com:443/api/dismiss_all", {
                userid: useralldata?.UserInfodata?.sub,
              })
              .then((res) => {
                setloadingnotification(true);
              });
            settoggle({ ...toggle, Notification: !toggle.Notification });
          }}
        >
          Dismiss all
        </Button>
        <Button
          className="btn-footer"
          as={Link}
          to="/notification"
          kind="primary"
        >
          See all({useralldata?.UserallNotification?.count})
        </Button>
      </div>
      </div>
    </div>
  );
};

export default Notification;
