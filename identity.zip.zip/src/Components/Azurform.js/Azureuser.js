import React from 'react'

export const Azureuser = () => {
  return (
    <div>Azureuser</div>
  )
}
