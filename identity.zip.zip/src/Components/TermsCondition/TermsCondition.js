import React, { useContext, useEffect, useState } from "react";
import { Link } from "react-router-dom";

import {
  CaretRight16,
  Chat24,
  ChevronRight20,
  Document32,
} from "@carbon/icons-react";
// import MainHeader from "../Header/UiHeader";
import {
  ModalWrapper,
  Button,
  Loading,
  Row,
  Grid,
  Column,
  Modal,
  Dropdown,
} from "carbon-components-react";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import axios from "axios";
import * as All from "@carbon/icons-react";
import UiHeader from "../Header/UiHeader";

const Icon = ({ iconName = "Document32", fill }) => {
  const icon = React.createElement(All[iconName]);
  return <div style={{ fill: fill }}>{icon}</div>;
};
const TermsCard = ({ icon, heading, title, label, desc }) => {
  const [open, setopen] = useState(false);
  return (
    <Column lg={4}>
      <div className="card">
        <div className="content ">
          <div className="icon">
            <Icon iconName={icon} />
          </div>
          <Column lg={14} className="card--heading">
            <h4>{heading}</h4>
          </Column>
        </div>
        <Modal
          hasScrollingContent
          open={open}
          modalLabel={title}
          modalHeading={label}
          passiveModal={false}
          preventCloseOnClickOutside
          onRequestClose={() => setopen(!open)}
          secondaryButtons={[
            {
              buttonText: "I understand",
              onClick: () => setopen(!open),
            },
          ]}
        >
          <p dangerouslySetInnerHTML={{ __html: desc }} />
        </Modal>
        <Button
          kind="ghost"
          renderIcon={CaretRight16}
          onClick={() => setopen(!open)}
        >
          Read
        </Button>
      </div>
    </Column>
  );
};
const TermsCondition = () => {
  const [namePrivecy, setNameprivecy] = useState([]);
  const [cardData, setcardData] = useState([]);
  const [loaderfilter, setloaderfilter] = useState(false);

  const [currentcatItem, setcatCurrentItem] = useState({
    name: "All",
  });

  useEffect(() => {
    if (currentcatItem?.name == "All") {
      let formData = new FormData();
      formData.append("method", "terms_data");
      formData.append("slug", "All");
      axios
        .post("https://cms.uvation.com/all-apis-new", formData)

        .then((res) => setcardData(res?.data?.data))
        .catch((err) => console.log(err));
    }
  }, [currentcatItem]);
  const dropdownData = async (selectedItem) => {
    setcatCurrentItem(selectedItem?.data?.name);
    let formData1 = new FormData();
    formData1.append("method", "terms_data");
    formData1.append("slug", selectedItem?.slug);
    let response = await axios.post(
      "https://cms.uvation.com/all-apis-new",
      formData1
    );
    setcardData(response?.data?.data);
  };
  useEffect(() => {
    axios
      .get("https://cms.uvation.com/all-apis-new/?method=get_terms")
      .then((res) => {
        setNameprivecy(res?.data);
      });
  }, []);

  const resetFilter = () => {
    setcatCurrentItem({ name: "All" });
  };
  window.scrollTo(0, 0);
  const [isLoading, setIsLoading] = useState(false);

  const [investordata, setinvesterdata] = useState();
  const [open, setopen] = useState(false);
  const [termsfilterdata, settermsfilterdata] = useState();

  useEffect(() => {
    setIsLoading(true);
    axios
      .get(
        "https://cms.uvation.com/all-apis-new/?method=information_for_investors1_page&section_name=investors1",
        {
          method: "information_for_investors1_page",
          section_name: "investors1",
        }
      )
      .then((res) => {
        setIsLoading(false);
        setinvesterdata(res?.data?.uvation_content);
      });
  }, []);

  // const {
  //   toggle,
  //   settoggle,
  //   AlldataWidget,
  //   setAlldataWidget,
  //   TablePagination,
  //   setTablePagination,
  //   MsAccessToken,
  //   setMsAccessToken,
  //   userInfo,
  //   setuserInfo,
  //   userInfo,
  //   setuserInfo,
  //   ToggleBtnMode,
  //   setToggleBtnMode,
  //   Modalset,
  //   setModalset,
  // } = useContext(GlobalContext);
  const filtervaluedata = (carddata) => {
    setloaderfilter(true);
    const termsfilterdata = new FormData();
    termsfilterdata.append("method", "terms_single_page");
    termsfilterdata.append("slug", carddata?.slug);
    axios
      .post("https://cms.uvation.com/all-apis-new", termsfilterdata)
      .then((res) => {
        settermsfilterdata(res?.data);
        if (res?.data?.status == "success") {
          setloaderfilter(false);
          setopen(!open);
        }
      });
  };
  return (
    <div className="terms_condition">
      <UiHeader />

      <Loading active={isLoading} withOverlay />
      <div className="bx--grid bx--no-gutter">
        <div className="bx--row">
          <div className="bx--col banner">
            <div>
              <h5>Welcome to</h5>
            </div>
            <div className="terms">
              <span>
                <h2> Terms & Conditions</h2> <ChevronRight20 />
              </span>
              <span>
                <Link to="/home">Home</Link>
              </span>
            </div>
          </div>
        </div>

        <Grid fullWidth className="cards" name="cards">
          <Grid>
            <div className="myDropdown ">
              <Row className="myDropdown_row">
                <Column lg={4} className="myDropdown_coldata">
                  {namePrivecy.length != 0 && (
                    <Dropdown
                      onChange={({ selectedItem }) =>
                        dropdownData(selectedItem)
                      }
                      light
                      label="All"
                      id={"option-0"}
                      titleText="Select Category"
                      items={
                        namePrivecy?.data === undefined
                          ? [{ name: "All" }]
                          : namePrivecy?.data
                      }
                      itemToString={(item) => (item ? item.name : "")}
                      selectedItem={currentcatItem}
                    />
                  )}
                </Column>
                <Column lg={4} className="filter_btn">
                  {currentcatItem?.name !== "All" ? (
                    <Button
                      size="field"
                      onClick={resetFilter}
                      style={{ background: "#0f62fe", color: "#fff" }}
                    >
                      Reset all filters
                    </Button>
                  ) : (
                    <Button
                      size="field"
                      onClick={resetFilter}
                      style={{ background: "#E0E0E0", color: "#fff" }}
                    >
                      Reset all filters
                    </Button>
                  )}
                </Column>
              </Row>
            </div>
            <Row condensed>
              {/* {cardData?.terms_show[0] == "marketing" || cardData?.terms_show[1] == "marketing" ? "hello" : "ankit"} */}
              {cardData.map((carddata, index) => {
                return (
                  <>
                    {carddata.terms_show?.[0] == "identity" ||
                    carddata.terms_show?.[1] == "identity" ? (
                      <Column lg={4}>
                        <Loading active={loaderfilter} />
                        <div className="card">
                          <div className="content ">
                            <div className="icon">
                              <Document32 />
                            </div>
                            <Column lg={14} className="card--heading">
                              <h4>{carddata?.title}</h4>
                            </Column>
                          </div>

                          <Button
                            kind="ghost"
                            renderIcon={CaretRight16}
                            onClick={
                              () => filtervaluedata(carddata)
                              // setopen(!open)
                            }
                          >
                            Read
                          </Button>
                        </div>
                      </Column>
                    ) : (
                      ""
                    )}
                  </>
                );
              })}
            </Row>
            <Modal
              hasScrollingContent
              open={open}
              className="terms_modal"
              // modalLabel={title}
              modalHeading={termsfilterdata?.data?.terms_filter_heading}
              passiveModal={false}
              preventCloseOnClickOutside
              onRequestClose={() => setopen(!open)}
              secondaryButtons={[
                {
                  buttonText: "I understand",
                  onClick: () => setopen(!open),
                },
              ]}
            >
              <p
                dangerouslySetInnerHTML={{
                  __html: termsfilterdata?.data?.terms_filter_desc,
                }}
              />
            </Modal>
          </Grid>
        </Grid>
      </div>
    </div>
  );
};

export default TermsCondition;
