import React from "react";


const Notfound = () => {
return(
    <>
    <div className="notfoundpage">
    <h1>
        404 Page Not Found
        </h1></div>
    </>
)
}
export default Notfound;