import React, { useContext, useEffect, useState } from "react";
import { Catalog32, Launch16 } from "@carbon/icons-react";
import { ModalWrapper, Toggle, Dropdown } from "carbon-components-react";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import axios from "axios";
import { Contextprovider } from "../../App";

const Privacy = () => {
  const {useralldata , dispatch} = useContext(Contextprovider)

  const { IsOn, setIsOn ,settooglebtn} =
    useContext(GlobalContext);
    // useEffect(() => {
    //   // if (useralldata?.UserInfodata?.sub) {
    //     axios.post("https://notifications.uvation.com/api/getStatus", {
    //       userid: useralldata?.UserInfodata?.sub,
    //     }).then((res) => {
    //      dispatch({type:"SYSTEMNOTIFICATION_DATA_RESPONSE",payload:res?.data})
         
    //     })
    //   // }
    // }, [useralldata?.UserInfodata?.sub , useralldata?.ToogleBtn]);
  
  return (
    <div>
      <div className="bx--row e">
        <div className="bx--col-lg-4 bx--no-gutter--right">
          <div className="card privacy_statement_">
            <div className="title">
              <h4> Privacy Statement</h4>
            </div>
            <div className="Privacy_Statement_data">
              <p>Your privacy and security are important to us. </p>
              <p>
                Read our Privacy Statement to learn more about how we use data
                and keep it safe.
              </p>
            </div>
            <div className="privacy">
              <div className="icon">
                <Catalog32 />
              </div>
            </div>

            <div className="edit-btn one-btn">
              <ModalWrapper
                modalLabel="Privacy"
                modalHeading="Privacy Statement"
                size="sm"
                buttonTriggerText=" Read"
                triggerButtonKind="primary"
                renderTriggerButtonIcon={Launch16}
                buttonTriggerClassName="modal-btn"
                primaryButtonText="I understand"
                hasScrollingContent={true} 
              >
                Effective as of January 1, 2017, Uvation, Inc., “Uvation” and
                its subsidiaries, collectively, the “Uvation” or “we” or “us” or
                “our” have updated our Privacy Policy “Policy”. Uvation provides
                this Privacy Policy to inform you of our policies and procedures
                regarding the collection, use and disclosure of personal
                information we receive from users of our Services related to our
                Website located at www.uvation.com. This Privacy Policy may be
                updated from time to time. We will notify you of any material
                changes by posting the new Privacy Policy on the Website. Your
                use of the Services following any such notice will signify and
                constitute your assent to and acceptance of such revised Privacy
                Policy. Unless otherwise defined in this Privacy Policy,
                capitalized terms used below have the same meanings as in our
                Terms of Service. As used in this Privacy Policy, the terms
                “using” and “processing” information include using cookies on a
                computer, subjecting the information to statistical or other
                analysis and using or handling information in any way,
                including, but not limited to collecting, storing, evaluating,
                modifying, deleting, combining, disclosing and transferring
                information within the United States or internationally. 1.
                Information Collection and Use Our primary goals in collecting
                information are to provide and improve our Services and to
                enable Website users to enjoy and easily navigate the Website.
                subjecting the information to statistical or other analysis and
                using or handling information in any way, including, but not
                limited to collecting, storing, evaluating, modifying, deleting,
                combining, disclosing and transferring information within the
                United States or internationally. 1. Information Collection and
                Use Our primary goals in collecting information are to provide
                and improve our Services and to enable Website users to enjoy
                and ea Effective as of January 1, 2017, Uvation, Inc., “Uvation”
                and its subsidiaries, collectively, the “Uvation” or “we” or
                “us” or “our” have updated our Privacy Policy “Policy”. Uvation
                provides this Privacy Policy to inform you of our policies and
                procedures regarding the collection, use and disclosure of
                personal information we receive from users of our Services
                related to our Website located at www.uvation.com. This Privacy
                Policy may be updated from time to time. We will notify you of
                any material changes by posting the new Privacy Policy on the
                Website. Your use of the Services following any such notice will
                signify and constitute your assent to and acceptance of such
                revised Privacy
              </ModalWrapper>
            </div>
          </div>
        </div>
        <div className="bx--col-lg-4 bx--no-gutter--right">
          <div className="card">
            <div className="title">
              <h4> News & Updates Notifications</h4>
            </div>
            <div className="auth">
              <h6>
                Control whether you receive non-service-related news about
                Uvation and its brand. These types of updates may include:
              </h6>
              <ul>
                <li>News about changes to our brand</li>
                <li>Business award announcements</li>
                <li>Partnership announcements</li>
                <li>Press releases</li>
              </ul>
            </div>
            <div className="edit-btn">
              <Toggle id="50" defaultToggled aria-label="toggle button" 
               toggled={IsOn?.data?.response_notifi}
                onToggle={(event) => {
                  if (useralldata?.UserInfodata) {
                    axios
                      .post(
                        "https://appsapi.uvation.com:8080/identity/system_notifi",
                        {
                          userid: useralldata?.UserInfodata?.sub,
                          NewsUpdatessystembutton: event,
                        }
                      )
                      .then((res) => {
                        setIsOn(res);
                      });
                  }
                }} />
            </div>
          </div>
        </div>
        <div className="bx--col-lg-4 bx--no-gutter--right">
          <div className="card">
            <div className="title" style={{ paddingRight: "0" }}>
              <h4>Marketing & Promotions Notifications</h4>
            </div>
            <div className="auth">
              <h6>
                Control whether you receive notifications about product and
                service promotions. hese notifications typically include
                information about the following:
              </h6>
              <ul>
                <li>Discounts</li>
                <li>Deals</li>
                <li>Promotionss</li>
                <li>Rewards</li>
                <li>New products and services</li>
              </ul>
            </div>
            <div className="edit-btn">
              <Toggle id="51" defaultToggled aria-label="toggle button" 
               toggled={IsOn?.data?.response_notifi}
                onToggle={(event) => {
                  if (useralldata?.UserInfodata) {
                    axios
                      .post(
                        "https://appsapi.uvation.com:8080/identity/system_notifi",
                        {
                          userid: useralldata?.UserInfodata?.sub,
                          Marketingpromotionsystembutton: event,
                        }
                      )
                      .then((res) => {
                        setIsOn(res);
                      });
                  }
                }}/>
            </div>
          </div>
        </div>
        <div className="bx--col-lg-4 bx--no-gutter--right">
          <div className="card">
            <div className="title">
              <h4> System Notifications</h4>
            </div>
            <div className="auth">
              <h6>
                Control whether you receive notifications about changes to the
                Uvation Cloud infrastructure. These notifications typically
                include information about the following:
              </h6>
              <ul>
                <li>New Uvation Cloud features and services</li>
                <li>Infrastructure updates or upgrades</li>
              </ul>
            </div>
            <div className="edit-btn">
              <Toggle
                id="52"
                aria-label="toggle button"
                toggled={useralldata?.SystemNotificationResponse?.status}
                onToggle={(event) => {
                  if (useralldata?.UserInfodata) {
                    axios
                      .post(
                        "https://notifications.uvation.com:443/api/permission",
                        {
                          userid: useralldata?.UserInfodata?.sub,
                          status: event,
                        }
                      )
                      .then((res) => {
                      dispatch({type:"SYSTEMNOTIFICATION_TOOGLEBTN",payload: event})
                      });
                  }
                }}
              />
            </div>
          </div>
        </div>
        <div className="bx--col-lg-4 bx--no-gutter--right">
          <div className="card">
            <div className="title">
              <h4>Unplanned Incident Notifications</h4>
            </div>
            <div className="auth">
              <h6>
                Control whether you receive notifications about Uvation Cloud
                outages or potential issues that could cause outages.
              </h6>
              <p>
                These issues are location-specific and apply only to the Uvation
                Cloud platform.
              </p>
            </div>
            <div className="edit-btn">
              <Toggle id="53" defaultToggled aria-label="toggle button" 
               toggled={IsOn?.data?.response_notifi}
               onToggle={(event) => {
                 if (useralldata?.UserInfodata) {
                   axios
                     .post(
                       "https://appsapi.uvation.com:8080/identity/system_notifi",
                       {
                         userid: useralldata?.UserInfodata?.sub,
                         Unplainedsystembutton: event,
                       }
                     )
                     .then((res) => {
                       setIsOn(res);
                     });
                 }
               }} />
            </div>
          </div>
        </div>
        <div className="bx--col-lg-4 bx--no-gutter--right">
          <div className="card">
            <div className="title">
              <h4>Planned Maintenance Notifications</h4>
            </div>
            <div className="auth">
              <h6>
                Control whether you receive notifications about planned
                maintenance on the Uvation Cloud platform.
              </h6>
              <p>
                You will receive notifications about upcoming scheduled
                maintenance as well as notices about when services will be
                restored.
              </p>
              <p className=" Maintenance_optimally">
                Maintenance is required to keep the platform operating
                optimally. It requires some services to be shut down
                temporarily.
              </p>
            </div>
            <div className="edit-btn">
              <Toggle id="54" defaultToggled aria-label="toggle button"
               toggled={IsOn?.data?.response_notifi}
               onToggle={(event) => {
                 if (useralldata?.UserInfodata) {
                   axios
                     .post(
                       "https://appsapi.uvation.com:8080/identity/system_notifi",
                       {
                         userid: useralldata?.UserInfodata?.sub,
                         Plainedsystembutton: event,
                       }
                     )
                     .then((res) => {
                       setIsOn(res);
                     });
                 }
               }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Privacy;
