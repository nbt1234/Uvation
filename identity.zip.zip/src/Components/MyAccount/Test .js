import React, { useState } from 'react'
import { Grid } from 'carbon-components-react'
import UiHeader from '../Header/UiHeader'
import { User32, IbmCloud32, ArrowRight16, Notification32, Security32, Box32, Launch16, Forum32 } from '@carbon/icons-react'
import {Dropdown} from 'carbon-components-react'

export const Test = () => {
    const items=[
        { id: 'option-0', text: 'Option 0' },
        { id: 'option-1', text: 'Option 1' },
        { id: 'option-2', text: 'Option 2' },
      ]
const [currentItem, setCurrentItem] = useState(items[4]);

    return (
        <>
  

<Dropdown
  items={items}
  itemToString={(item) => (item ? item.text : '')}
  onChange={({ selectedItem }) => setCurrentItem(selectedItem)}
  selectedItem={currentItem}
/>
        </>
    )
}
