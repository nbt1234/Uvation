import React from "react";
import MyAccount from "./MyAccount";

const MyAccount3 = () => {
  return (
    <div>
      <MyAccount selected={3} />
    </div>
  );
};

export default MyAccount3;
