import React, { useContext, useEffect, useState } from "react";
import {
  LogoFacebook32,
  LogoLinkedin32,
  LogoInstagram32,
  LogoTwitter32,
} from "@carbon/icons-react";
import ibmlogo from "../../img/ibmimage.png";
import { Button, Modal, TextInput, Form } from "carbon-components-react";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import axios from "axios";

export const Companyinfo = () => {
  const {
    MsAccessToken,

    userInfo,
    setuserInfo,
    // contactsalesforce,
    // setcontactsalesforce,
    setupdatesdetail,
    updatesdetail,
    Modalset,
    setModalset,
    companyname,
    photo,
    setcontactsalesforce,
    contactsalesforce,
    setphoto,
    fetchdata,
    contactinfodata,
    setupdatecompanyinfo,
    updatecompanyinfo,
  } = useContext(GlobalContext);
  const cancelmodal = (res) => {
  };
  const [valuchange, setvaluchange] = useState();

  const [contactsalesforce12, setcontactsalesforce12] = useState();

  const submitdatahandler = () => {
    if (contactsalesforce) {
    // let countryArray = companyname.filter((company) => {
    //   return company.key == contactsalesforce?.companyName;
    // });
    // let parameter;
    // if (countryArray.length == 0) {
    //   parameter = { Company_Name__c: contactsalesforce?.companyName };
    // } else {
    //   parameter = { accountId: countryArray[0]?.value };
    // }
    axios
      .patch(
        `${fetchdata?.response?.instance_url}/services/data/v41.0/sobjects/contact/${contactinfodata?.recordId}`,
        {
          Company_Data_Verified__c: true,
          Company_City__c: contactsalesforce?.companyCity,
          Company_Name__c: contactsalesforce?.companyName,
          // accountId: countryArray.length !== 0 ? countryArray[0]?.value : "",
          // ...parameter,
          Company_Description__c: contactsalesforce?.description,
          Company_Domain__c: contactsalesforce?.domain,
          Company_EIN__c: contactsalesforce?.EIN,
          Company_Facebook_Handle__c: contactsalesforce?.facebookHandle,
          Company_Industry__c: contactsalesforce?.industry,
          Company_Industry_Group__c: contactsalesforce?.industryGroup,
          Company_Legal_Name__c: contactsalesforce?.legalName,
          Company_Linkedin_Handle__c: contactsalesforce?.linkedInHandle,
          Company_Logo__c: contactsalesforce?.companyLogo1,
          Company_Country__c: contactsalesforce?.country,
          Company_Phone_Number__c: contactsalesforce?.phone,
          Company_NAICS_Code__c: contactsalesforce?.NAICS_Code,
          Company_Sector__c: contactsalesforce?.sector,
          Company_State__c: contactsalesforce?.state,
          Company_Street_Name__c: contactsalesforce?.streetName,
          Company_Street_Number__c: contactsalesforce?.streetNumber,
          Company_Ticker__c: contactsalesforce?.companyCity,
          Company_Twitter_Handle__c: contactsalesforce?.ticker,
          Company_Type__c: contactsalesforce?.type,
          Company_URL__c: contactsalesforce?.companyURL,
        },
        {
          headers: {
            Authorization: `Bearer ${fetchdata?.response?.access_token}`,
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        setModalset({ ...Modalset, address: false });
      });
    }
  };

  const handleSearch = (event) => {
    let companydata = companyname.filter((name) => {
      return (
        name?.key?.includes(event.target.value) &&
        name?.key != event.target.value
      );
    });
    setvaluchange(companydata);
  };
  const handleSearch12 = (e) => {
    let companydata = companyname.filter((name) => {
      return (
        name?.key?.includes(e.target.innerHTML) &&
        name?.key != e.target.innerHTML
      );
    });
    setvaluchange(companydata);
  };

  const urlRegex =
    /^((http(s?)?):\/\/)?([wW]{3}\.)?[a-zA-Z0-9\-.]+\.[a-zA-Z]{2,}(\.[a-zA-Z]{2,})?$/g;
  return (
    <div>
      <div className="company_info">
        <div className="bx--grid bx--no-gutter main">
          <div className="box-row">
            <div className="company_data">
              <div className="company_mainheader">
                <h4>Company Information</h4>
              </div>
              <div className="aboutibm">
                <div className="comapnay_img">
                  {contactsalesforce?.companyLogo && <img src={contactsalesforce?.companyLogo}  alt="#" />}
                </div>

                <div className="ibm_info">
                  <h4>{contactsalesforce?.companyName}</h4>
                  <span>
                    <a href={contactsalesforce?.companyURL} target="_blank">
                      {contactsalesforce?.companyURL}
                    </a>
                  </span>
                  <div className="personal_details">
                    <ul className="social_icon">
                      {contactsalesforce?.facebookHandle !== null && (
                        <li className="">
                          <a
                            href={`https://www.facebook.com/${contactsalesforce?.facebookHandle}`}
                            target="_blank"
                          >
                            <LogoFacebook32 />
                          </a>
                        </li>
                      )}

                      {contactsalesforce?.linkedInHandle !== null && (
                        <li className="">
                          <a
                            href={`https://in.linkedin.com/${contactsalesforce?.linkedInHandle}`}
                            target="_blank"
                          >
                            <LogoLinkedin32 />
                          </a>
                        </li>
                      )}

                      {contactsalesforce?.twitterHandle !== null && (
                        <li className="">
                          <a
                            href={`https://mobile.twitter.com/${contactsalesforce?.twitterHandle}`}
                            target="_blank"
                          >
                            <LogoTwitter32 />
                          </a>
                        </li>
                      )}
                    </ul>
                  </div>
                </div>
              </div>
              <div className="security_description">
                <p>
                  {contactsalesforce?.description}
                 
                </p>
              </div>
            </div>
          </div>
          <div className="box-row company_location_">
            <div className="bx--col-lg-8 bx--no-gutter--right">
              <div className="personal_details">
                <ul>
                  <li className="">
                    <h6>Legal Name: </h6>
                    <p>{contactsalesforce?.legalName}</p>
                  </li>
                  <li className="">
                    <h6>Company Street Number: </h6>
                    <p>{contactsalesforce?.streetNumber}</p>
                  </li>
                  <li className="">
                    <h6> Company Type: </h6>
                    <p>{contactsalesforce?.type}</p>
                  </li>
                  <li className="">
                    <h6>Company Street Name: </h6>
                    <p> {contactsalesforce?.streetName}</p>
                  </li>
                  {/* Company Description Company Ticker Company City Company Domain Company State */}

                  {/* <li className="">
                    <h6>Company Description: </h6>
                    <p> {contactsalesforce?.description}</p>
                  </li> */}
                  <li className="">
                    <h6>Company Ticker: </h6>
                    <p>{contactsalesforce?.ticker}</p>
                  </li>
                  <li className="">
                    <h6>Company City: </h6>
                    <p>{contactsalesforce?.companyCity}</p>
                  </li>
                  <li className="">
                    <h6>Company Domain: </h6>
                    <p>{contactsalesforce?.domain}</p>
                  </li>
                  <li className="">
                    <h6>Company State: </h6>
                    <p>{contactsalesforce?.state}</p>
                  </li>
                </ul>
              </div>
            </div>
            <div className="bx--col-lg-8 bx--no-gutter--right">
              <div className="personal_details">
                <ul>
                  <li className="">
                    <h6>Company Country: </h6>
                    <p>{contactsalesforce?.country}</p>
                  </li>
                  <li className="">
                    <h6>Company Postal Code: </h6>
                    <p>{contactsalesforce?.postalCode}</p>
                  </li>
                  <li className="">
                    <h6>Company Industry: </h6>
                    <p>{contactsalesforce?.industry}</p>
                  </li>
                  <li className="">
                    <h6>Company Industry Group: </h6>
                    <p>{contactsalesforce?.industryGroup}</p>
                  </li>
                  <li className="">
                    <h6>Company Sector: </h6>
                    <p>{contactsalesforce?.sector}</p>
                  </li>
                  <li className="">
                    <h6>Company NAICS Code: </h6>
                    <p>{contactsalesforce?.NAICS_Code}</p>
                  </li>
                  <li className="">
                    <h6>Company EIN: </h6>
                    <p>{contactsalesforce?.EIN}</p>
                  </li>
                  <li className="">
                    <h6>Company Phone Number: </h6>
                    <p>{contactsalesforce?.phone}</p>
                  </li>
                </ul>
              </div>
            </div>
          </div>
          <div className="company_editinfo">
            <Button
              kind="secondary"
              onClick={() => setModalset({ ...Modalset, address: true })}
            >
              Edit
            </Button>

            <Modal
              open={Modalset.address}
              modalLabel="Personal Info"
              modalHeading="Edit your details"
              hasForm
              primaryButtonText="Submit"
              secondaryButtonText="Cancel"
              size="lg"
              selectorPrimaryFocus="#text-input-2"
              onRequestClose={() => {
                setModalset({ ...Modalset, address: false });
                cancelmodal();
              }}
              onRequestSubmit={() => {
              
                submitdatahandler();
              }}
            >
              <Form>
                <div className="model-popup-form">
                  <TextInput
                    id="13"
                    warn={!contactsalesforce?.companyCity}
                    warnText="Please enter your companyCity"
                    invalidText="Invalid error message."
                    labelText="Your companyCity name*"
                    placeholder="Company City"
                    value={contactsalesforce?.companyCity}
                    onChange={(e) => {
                      setcontactsalesforce({
                        ...contactsalesforce,
                        companyCity:
                          e.target.value == "" ? null : e.target.value,
                      });
                    }}
                  />
                  <div className="company_data13">
                    {" "}
                    <TextInput
                      id="12"
                      warn={!contactsalesforce?.companyName}
                      warnText="Please enter your company name"
                      invalidText="Invalid error message."
                      labelText="Your comapny  name*"
                      placeholder="company name"
                      value={contactsalesforce?.companyName}
                      onInput={(e) => {
                        handleSearch(e);
                        setcontactsalesforce({
                          ...contactsalesforce,
                          companyName: e.target.value,
                        });
                      }}
                    ></TextInput>
                    <ul className="ddfbndfsdfsnjdf">
                      {valuchange?.map((filteredName) => {
                        return (
                          <li
                            onClick={(e) => {
                              handleSearch12(e);
                              setcontactsalesforce({
                                ...contactsalesforce,
                                companyName: filteredName.key,
                              });
                            }}
                          >
                            {contactsalesforce?.companyName !== "" &&
                              filteredName.key}
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                </div>

                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="119"
                    invalid={
                      contactsalesforce?.phone !== null &&
                      !/^[0-9\b]+$/.test(contactsalesforce?.phone)
                    }
                    invalidText={"Enter a valid company phone number"}
                    warn={!contactsalesforce?.phone}
                    warnText="Please enter your company number"
                    labelText="company Phone number*"
                    placeholder="Enter a phone number"
                    value={contactsalesforce?.phone}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        phone: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                  <TextInput
                    maxLength={50}
                    id="118"
                    warn={!contactsalesforce?.state}
                    warnText="Please enter your company state"
                    labelText="Phone number*"
                    placeholder="Enter a company state"
                    value={contactsalesforce?.state}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        state: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="116"
                    warn={!contactsalesforce?.sector}
                    warnText="Please enter company sector"
                    labelText="company sector"
                    placeholder="Enter company sector"
                    value={contactsalesforce?.sector}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        sector: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                  <TextInput
                    maxLength={50}
                    id="120"
                    warn={!contactsalesforce?.streetName}
                    warnText="Please enter your company streetname"
                    labelText="streetname"
                    placeholder="Enter company streetname"
                    value={contactsalesforce?.streetName}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        streetName:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="121"
                    warn={!contactsalesforce?.streetNumber}
                    warnText="Please enter your number"
                    labelText="streetNumber number*"
                    placeholder="Enter a phone number"
                    value={contactsalesforce?.streetNumber}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        streetNumber:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                  <TextInput
                    maxLength={50}
                    id="122"
                    invalidText={"Enter a valid domain"}
                    warn={!contactsalesforce?.domain}
                    warnText="Please enter your company domain"
                    labelText="Company domain"
                    placeholder="Enter Company do"
                    value={contactsalesforce?.domain}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        domain: e.target.value === "" ? null : e.target.value,
                      })
                    }
                    invalid={!contactsalesforce?.domain?.match(urlRegex)}
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="123"
                    warn={!contactsalesforce?.type}
                    warnText="Please enter company type"
                    labelText="type"
                    placeholder="Enter company typer"
                    value={contactsalesforce?.type}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        type: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />

                  <TextInput
                    maxLength={50}
                    id="124"
                    warn={!contactsalesforce?.country}
                    warnText="Please enter your company country"
                    labelText="company country"
                    placeholder="Enter company country"
                    value={contactsalesforce?.country}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        country: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="125"
                    warn={!contactsalesforce?.legalName}
                    warnText="Please enter your legalName"
                    labelText="legalName"
                    placeholder="Enter legalName"
                    value={contactsalesforce?.legalName}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        legalName:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />

                  <TextInput
                    maxLength={50}
                    id="126"
                    warn={!contactsalesforce?.EIN}
                    warnText="Please enter your company EIN number"
                    labelText="EIN number"
                    placeholder="Enter EIN number"
                    value={contactsalesforce?.EIN}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        EIN: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="127"
                    warn={!contactsalesforce?.industry}
                    warnText="Please enter your industry"
                    labelText="comapny industry"
                    placeholder="Enter industry name"
                    value={contactsalesforce?.industry}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        industry: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                  <TextInput
                    maxLength={50}
                    id="128"
                    warn={!contactsalesforce?.industryGroup}
                    warnText="Please enter your industryGroup"
                    labelText="industryGroup"
                    placeholder="Enter industryGroup"
                    value={contactsalesforce?.industryGroup}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        industryGroup:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                </div>

                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="129"
                    warn={!contactsalesforce?.NAICS_Code}
                    warnText="Please enter your NAICS_Code"
                    labelText="NAICS_Code*"
                    placeholder="Enter a NAICS_Coder"
                    value={contactsalesforce?.NAICS_Code}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        NAICS_Code:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                  <TextInput
                    maxLength={50}
                    id="130"
                    warn={!contactsalesforce?.ticker}
                    warnText="Please enter ticker"
                    labelText="ticker"
                    placeholder="Enter a tickerr"
                    value={contactsalesforce?.ticker}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        ticker: e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="131"
                    invalidText={"please Enter a valid Url"}
                    warn={!contactsalesforce?.companyURL}
                    warnText="Please enter your companyURL"
                    labelText="companyURL"
                    placeholder="Enter a companyURLr"
                    value={contactsalesforce?.companyURL}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        companyURL:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                    invalid={!contactsalesforce?.companyURL?.match(urlRegex)}
                  />

                  <TextInput
                    maxLength={50}
                    id="132"
                    warn={!contactsalesforce?.description}
                    warnText="Please enter your company number"
                    labelText="description"
                    placeholder="Enter description"
                    value={contactsalesforce?.description}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        description:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="133"
                    invalidText={"please enter valid url"}
                    warn={!contactsalesforce?.facebookHandle}
                    warnText="Please enter your company facebookHandle"
                    labelText="company facebookHandle"
                    placeholder="Enter company facebookHandle"
                    value={`https://www.facebook.com/${contactsalesforce?.facebookHandle}`}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        facebookHandle:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                    invalid={
                      !contactsalesforce?.facebookHandle?.match(urlRegex)
                    }
                  />
                  <TextInput
                    maxLength={50}
                    id="134"
                    invalidText={"please enter valid url"}
                    warn={!contactsalesforce?.linkedInHandle}
                    warnText="Please enter your company linkedInHandle"
                    labelText="company linkedInHandle"
                    placeholder="Enter company linkedInHandle"
                    value={`https://in.linkedin.com/${contactsalesforce?.linkedInHandle}`}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        linkedInHandle:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                    invalid={
                      !contactsalesforce?.linkedInHandle?.match(urlRegex)
                    }
                  />
                </div>
                <div className="model-popup-form">
                  <TextInput
                    maxLength={50}
                    id="135"
                    invalidText={"please enter valid url"}
                    warn={!contactsalesforce?.twitterHandle}
                    warnText="Please enter your company twitterHandle"
                    labelText="company twitterHandle"
                    placeholder="Enter company twitterHandle"
                    value={`https://mobile.twitter.com/${contactsalesforce?.twitterHandle}`}
                    onChange={(e) =>
                      setcontactsalesforce({
                        ...contactsalesforce,
                        twitterHandle:
                          e.target.value === "" ? null : e.target.value,
                      })
                    }
                    invalid={!contactsalesforce?.twitterHandle?.match(urlRegex)}
                  />
                  <TextInput
                    maxLength={50}
                    className="imageurlsdfsnsd"
                    id="136"
                    type="file" // warn={!contactsalesforce?.twitterHandle}
                    warnText="Please select your logo"
                    labelText="Company logo*"
                    placeholder="Enter a logo"
                    // value={contactsalesforce?.companyLogo}
                    onChange={(e) => {
                      let image = e.target.files[0];

                      e.preventDefault();
                      let fileReader = new FileReader();
                      fileReader.readAsDataURL(image);
                      fileReader.onload = (event) => {
                        setcontactsalesforce({
                          ...contactsalesforce,
                          companyLogo1:
                            e.target.value === "" ? null : event.target.result,
                        });
                      };
                      // uploadPhoto(e);
                    }}
                  />
                </div>
              </Form>
            </Modal>
          </div>
        </div>
      </div>
    </div>
  );
};
