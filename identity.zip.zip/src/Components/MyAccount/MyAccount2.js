import React from "react";
import MyAccount from "./MyAccount";

const MyAccount2 = () => {
  return (
    <div>
      <MyAccount selected={2} />
    </div>
  );
};

export default MyAccount2;
