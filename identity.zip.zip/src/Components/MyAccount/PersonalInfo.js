import React, { useContext, useEffect, useState } from "react";
import {
  Add16,
  Edit16,
  User32,
  LogoFacebook32,
  LogoInstagram32,
  LogoTwitter32,
  Close32,
  Warning32,
  LogoLinkedin32,
} from "@carbon/icons-react";

import {
  ModalWrapper,
  Form,
  TextInput,
  ModalFooter,
  Modal,
  Button,
  FileUploader,
  FileUploaderButton,
  Loading,
  ModalBody,
  ComposedModal,
  Dropdown,
} from "carbon-components-react";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import axios from "axios";
import csc from "country-state-city";
// import { useIsAuthenticated, useMsal } from "@azure/msal-react";
import { InteractionStatus } from "@azure/msal-browser";
import {
  MsalAuthenticationTemplate,
  useMsal,
  useAccount,
} from "@azure/msal-react";
import {
  InteractionRequiredAuthError,
  InteractionType,
} from "@azure/msal-browser";
// import {loginRequest ,protectedResources} from "../authConfig"
import { b2cPolicies } from "../../authConfig";
import proimg from "../../img/profile.png";

import { Contextprovider } from "../../App";

const PersonalInfo = () => {
  const { instance} = useMsal();
  const [imageuser, setimageuser] = useState(false);
  const [userdataimage, setuserdataimage] = useState();
  const {useralldata ,dispatch} = useContext(Contextprovider)
const {
    photo,
    setloadingnotification,
    contactsalesforce,
    setphoto,
    cloudopen,
    contactinfodata,
    fetchdata,
    setcloudopen,
    setimagedata,
  } = useContext(GlobalContext);
  const usernotification_token = localStorage.getItem("notification_token");
  localStorage.setItem("userid", useralldata?.UserInfodata.userid);
  const Countries = csc
    .getAllCountries()
    .map((country) => `${country.name} ${country.isoCode}`);
 
  const userimg = localStorage.getItem("user_image");
  const uploadPhoto = (e) => {
    let image = e.target.files[0];
    let datajn = new Date().toUTCString();
    e.preventDefault();
    let fileReader = new FileReader();
    fileReader.readAsDataURL(image);
    fileReader.onload = (event) => {
      dispatch({type:"USER_IMAGE_BASE64",payload:""})
      setphoto({ data: { base64: event.target.result } });
    };
    const user_dataimg = new FormData();
    user_dataimg.append("contactid", contactinfodata?.recordId);
    user_dataimg.append("image", image);
    user_dataimg.append("actoken", fetchdata?.response?.access_token);
    user_dataimg.append("instance_url", fetchdata?.response?.instance_url);
    setuserdataimage(image?.size);
    if (image?.size <= 1048576) {
      axios
        .post(`https://appsapi.uvation.com:8080/identity/image`, user_dataimg, {
          headers: {
            "Content-Type": "application/json",
          },
        })
        .then((res) => {
          axios
            .post(
              "https://notifications.uvation.com:443/api/action_notification",
              {
                userid: useralldata?.UserInfodata.sub,

                image_change_time: datajn,
                platform: "uvation identity",
                token: usernotification_token,
              }
            )
            .then((res) => {
              setloadingnotification(true);
            });
          if ((JSON.parse(res?.data).Status = "success")) {
            setimagedata(true);
          }
        })
        .catch((err) => console.log(err));
    }
  };
  return (
    <>
      <div className="main_divinfo">
        <ComposedModal danger open={cloudopen} size="md">
          {/* <ModalHeader /> */}
          <div className="close_button" onClick={() => setcloudopen(false)}>
            {" "}
            <Close32 />
          </div>

          <ModalBody hasForm>
            <div className="additional_status">
              <span className="warning_status">
                <Warning32 />
              </span>
              <p className="bx--modal-content__text">
                To access all of our services please re-login to enable your MFA
                & provide us additional required information for optimal user
                experience.
              </p>
            </div>
          </ModalBody>
        </ComposedModal>
        {/* <img src={photo?.proimg}/> */}
        <div className="bx--grid bx--no-gutter main">
          <div className="bx--row main_divinforow">
            <div className="bx--col-lg-4 bx--no-gutter--right user_column">
              <div className="user-icon">
                {userdataimage > 1048576 ? (
                  <span className="user_image_size">
                    Your selected image size more then 1MB
                  </span>
                ) : (
                  <img
                    src={
                      photo?.data?.base64
                        ? `${useralldata?.ImageBase64}${photo?.data?.base64}`
                        : proimg
                    }
                    className="user-photo"
                    alt="#"
                  />
                )}
                {/* <img
                  src={
                    photo?.data?.status == "Success"
                      ? `data:image/png;base64,${photo?.data.base64}`
                      : proimg
                  }
                  className="user-photo"
                /> */}
                <div className="user_img">
                  {imageuser && (
                    <span className="user_image_size">
                      {userimagesize?.message}
                    </span>
                  )}{" "}
                </div>
              </div>
            </div>
            <div className="bx--col-lg-12 bx--no-gutter--right information_column">
              <div className="card">
                <div className="details">
                  <h5> Profile Photo</h5>
                  <ul>
                    <li className="list">
                      <p>Recommended size: </p>
                      <p>512 x 512 pixels</p>
                    </li>
                    <li className="list">
                      <p>Maximum upload size: </p>
                      <p>1MB </p>
                    </li>
                    <li className="list">
                      <p>
                        only <span> .jpg and .png</span> are supported
                      </p>
                    </li>
                  </ul>
                </div>
              </div>
              <div className="upload_btn">
                <div className="edit-btn">
                  {/* <div className="bx--file__container"> */}
                  <div className="cds--file__container">
                    <FileUploader
                      accept={[".jpg", ".png"]}
                      buttonLabel="Upload"
                      buttonKind="secondary"
                      filenameStatus="edit"
                      iconDescription="Clear file"
                      name=""
                      role="button"
                      size="md"
                      onChange={(e) => {
                        uploadPhoto(e);
                      }}
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="bx--row main_divinforow_personal_info">
            <div className="bx--col-lg-6 bx--no-gutter--right personal_user_column">
              <div className="personal_info_main_div">
                <div className="personal_info_main_heading">
                  <h4>Personal Detail</h4>
                </div>
                {/* <div className="prsonalinfo_detail"> */}
                <div className="personal_details">
                  <ul>
                    <li className="">
                      <h6>Account Id: </h6>
                      <p>{contactinfodata?.clientId}</p>
                    </li>
                    <li className="">
                      <h6>Full Name: </h6>
                      <p>
                        {useralldata?.UserInfodata?.given_name}
                        {"  "}
                        {useralldata?.UserInfodata?.family_name}
                      </p>
                    </li>
                    <li className="">
                      <h6>Email: </h6>
                      <p>{useralldata?.UserInfodata.email}</p>
                    </li>
                    <li className="">
                      <h6>Phone: </h6>
                      <p>
                        {useralldata?.UserInfodata.extension_CountryCode}
                        {useralldata?.UserInfodata.MobileNumber}
                      </p>
                    </li>
                    {/* <li className="">
                      <h6>Alternate phone: </h6>
                      <p> +1 255 255 25</p>
                    </li> */}
                    {/* <li className="list">
               <h6>Alternate Phone: </h6>
               <p>{useralldata?.UserInfodata.alternatephone}</p>
             </li> */}
                  </ul>
                </div>
              </div>
              {/* </div> */}
            </div>
            <div className="bx--col-lg-6 bx--no-gutter--right">
              <div className="personal_info_main_div_address">
                <div className="personal_info_main_heading">
                  <h4>Address</h4>
                </div>
                {/* <div className="prsonalinfo_detail"> */}
                <div className="personal_details">
                  <ul>
                    <li className="">
                      <h6>Address: </h6>
                      <p>{useralldata?.UserInfodata.streetAddress}</p>
                    </li>
                    <li className="">
                      <h6>Country: </h6>
                      <p>{useralldata?.UserInfodata.country}</p>
                    </li>
                    <li className="">
                      <h6>State: </h6>
                      <p>{useralldata?.UserInfodata.state}</p>
                    </li>
                    <li className="">
                      <h6>City: </h6>
                      <p>{useralldata?.UserInfodata.city}</p>
                    </li>
                    <li className="">
                      <h6>Postal Code: </h6>
                      <p>{useralldata?.UserInfodata.postalCode}</p>
                    </li>
                    {/* <li className="list">
               <h6>Alternate Phone: </h6>
               <p>{useralldata?.UserInfodata.alternatephone}</p>
             </li> */}
                  </ul>
                </div>
              </div>
            </div>
            <div className="bx--col-lg-4 bx--no-gutter--right">
              <div className="personal_info_social_icon_div">
                <div className="personal_info_main_heading">
                  {!contactsalesforce?.facebookHandle == null && (
                    <h4>Social Media Links</h4>
                  )}
                </div>

                <div className="personal_details">
                  <ul className="social_icon user_social_icon">
                    {!contactsalesforce?.facebookHandle == null && (
                      <li className="">
                        <a href="#">
                          <LogoFacebook32 />
                        </a>
                      </li>
                    )}

                    {!contactsalesforce?.facebookHandle == null && (
                      <li className="">
                        <a href="#">
                          <LogoLinkedin32 />
                        </a>
                      </li>
                    )}

                    {!contactsalesforce?.facebookHandle == null && (
                      <li className="">
                        <a href="#">
                          <LogoTwitter32 />
                        </a>
                      </li>
                    )}

                    {/* <li className="">
                      <LogoInstagram32 />
                    </li> */}
                  </ul>
                </div>
              </div>
            </div>
          </div>
          <div className="edit-btn_info">
            <Button
              kind="secondary"
              onClick={() => {
                instance.loginRedirect(b2cPolicies.authorities.profileUpdate);
              }}
              // onClick={() => {
              //   instance.loginRedirect(b2cPolicies.authorities.profileUpdate);
              // }}
            >
              {!useralldata?.useralldata?.UserInfodatadata.newUser
                ? "Profile Edit"
                : "Add Profile"}
            </Button>
          </div>
        </div>
      </div>
    </>
  );
  // return (
  //   <>

  //     <div className="bx--row e profle_details">

  //       <div className="bx--col-lg-4 bx--no-gutter--right">
  //         <div className="card">
  //           <div className="title">
  //             <h4> Profile Photo</h4>
  //           </div>
  //           <div className="details">
  //             <ul>
  //               <li className="list">
  //                 <h6>Recommended size: </h6>
  //                 <p>512 x 512 pixels</p>
  //               </li>
  //               <li className="list">
  //                 <h6>Maximum upload size: </h6>
  //                 <p>100kb </p>
  //               </li>
  //               <li className="list">
  //                 <p>
  //                   only <span> .jpg and .png</span>are supported
  //                 </p>
  //               </li>
  //             </ul>
  //             <div className="user-icon">
  //               {/* {updatedus/erimage?.data==updateduserimage?.data ?<img src={updateduserimage?.data?.url} className="user-photo" />:  <span className="user_image_size">{userimagesize}</span>}   */}
  //               <img src={photo?.data?.url} className="user-photo" />
  //               <div className="user_img">
  //                 {imageuser && <span className="user_image_size">{userimagesize?.message}</span>} </div>

  //             </div>

  //           </div>
  //           <div className="edit-btn">
  //             {/* <div className="bx--file__container"> */}
  //             <div className="cds--file__container">
  //               <FileUploader
  //                 accept={[
  //                   '.jpg',
  //                   '.png'
  //                 ]}
  //                 buttonLabel="Upload"
  //                 buttonKind="secondary"
  //                 filenameStatus="edit"
  //                 iconDescription="Clear file"
  //                 // labelDescription="Max file size is 500mb. Only .jpg files are supported."

  //                 name=""
  //                 role="button"
  //                 size="md"
  //                 onChange={(e) => {
  //                   uploadPhoto(e);
  //                 }}
  //               />
  //             </div>
  //             {/* <FileUploaderButton
  //             size="field"
  //             disablelabelchanges
  //             onProgress
  //             labelText="Upload"
  //             accept={[".jpg", ".png", ".jpeg"]}
  //             buttonKind="secondary"
  //             buttonLabel="Upload"
  //             onChange={(e) => {
  //               uploadPhoto(e);
  //             }}
  //           /> */}
  //           </div>
  //         </div>
  //       </div>
  //       <div className="bx--col-lg-4 bx--no-gutter--right">
  //         <div className="card">
  //           <div className="title">
  //             <h4>Details</h4>
  //           </div>
  //           <div className="details">
  //             <ul>
  //               <li className="list">
  //                 <h6>Full Name: </h6>
  //                 <p>{useralldata?.UserInfodata?.fullname}{"  "}{useralldata?.UserInfodata?.surname}</p>
  //               </li>
  //               <li className="list">
  //                 <h6>Email: </h6>
  //                 <p>{useralldata?.UserInfodata.email}</p>
  //               </li>
  //               <li className="list">
  //                 <h6>Phone: </h6>
  //                 <p>{useralldata?.UserInfodata.countryCode}{useralldata?.UserInfodata.phone}</p>
  //               </li>
  //               {/* <li className="list">
  //               <h6>Alternate Phone: </h6>
  //               <p>{useralldata?.UserInfodata.alternatephone}</p>
  //             </li> */}
  //             </ul>
  //           </div>
  //           <div className="edit-btn">

  //             {/* <Button
  //             className="btn_height"
  //             kind="secondary"
  //             renderIcon={Edit16}
  //             onClick={() =>
  //               instance.loginRedirect(b2cPolicies.authorities.editProfile1)
  //             }
  //             >
  //             Edit
  //           </Button> */}

  //             <Modal
  //               open={Modalset.personal}
  //               modalLabel="Personal Info"
  //               modalHeading="Edit your details"
  //               hasForm
  //               primaryButtonText="Submit"
  //               secondaryButtonText="Cancel"
  //               size="sm"
  //               selectorPrimaryFocus="#text-input-2"
  //               onRequestClose={() => {
  //                 setModalset({ ...Modalset, personal: false });
  //                 cancelmodal();
  //               }}
  //             // onRequestSubmit={updateinfo}
  //             >
  //               {useralldata?.UserInfodata && (
  //                 <Form>
  //                   <div className="model-popup-form">
  //                     <TextInput
  //                       id="13"
  //                       warn={!useralldata?.UserInfodata.fullname}
  //                       warnText="Please enter your name"
  //                       invalidText="Invalid error message."
  //                       labelText="Your full name*"
  //                       placeholder="Placeholder text"
  //                       value={useralldata?.UserInfodata.fullname}
  //                       onChange={(e) =>
  //                         setuseralldata?.UserInfodata({
  //                           ...useralldata?.UserInfodata,
  //                           fullname:
  //                             e.target.value === "" ? null : e.target.value,
  //                         })
  //                       }
  //                     />
  //                     <TextInput
  //                       id="12"
  //                       invalidText="Invalid error message."
  //                       labelText="Email address*"
  //                       placeholder="Enter a email address"
  //                       value={useralldata?.UserInfodata.email}
  //                       disabled
  //                     />
  //                   </div>
  //                   <div className="model-popup-form">
  //                     <TextInput
  //                       maxLength={14}
  //                       id="119"
  //                       invalid={
  //                         useralldata?.UserInfodata.phone !== null &&
  //                         !/^[0-9\b]+$/.test(useralldata?.UserInfodata.phone)
  //                       }
  //                       invalidText={"Enter a valid phone number"}
  //                       warn={!useralldata?.UserInfodata.phone}
  //                       warnText="Please enter your number"
  //                       labelText="Phone number*"
  //                       placeholder="Enter a phone number"
  //                       value={useralldata?.UserInfodata.phone}
  //                       onChange={(e) =>
  //                         setuseralldata?.UserInfodata({
  //                           ...useralldata?.UserInfodata,
  //                           phone: e.target.value === "" ? null : e.target.value,
  //                         })
  //                       }
  //                     />
  //                   </div>
  //                 </Form>
  //               )}
  //             </Modal>
  //           </div>
  //         </div>
  //       </div>
  //       <div className="bx--col-lg-4 bx--no-gutter--right">
  //         <div className="card">
  //           <div className="title">
  //             <h4>Address</h4>
  //           </div>

  //           <div className="details">
  //             <ul>
  //               <li className="list">
  //                 <h6>Address: </h6>
  //                 <p>{useralldata?.UserInfodata.address}</p>
  //               </li>
  //               <li className="list">
  //                 <h6>Country: </h6>
  //                 <p>{useralldata?.UserInfodata.country}</p>
  //               </li>
  //               <li className="list">
  //                 <h6>State: </h6>
  //                 <p>{useralldata?.UserInfodata.state}</p>
  //               </li>
  //               <li className="list">
  //                 <h6>City: </h6>
  //                 <p>{useralldata?.UserInfodata.city}</p>
  //               </li>
  //               <li className="list">
  //                 <h6>Postal Code: </h6>
  //                 <p>{useralldata?.UserInfodata.postalCode}</p>
  //               </li>
  //             </ul>
  //           </div>
  //           <div className="edit-btn">
  //             {/* <Button
  //             className="btn_height"
  //             kind="secondary"
  //             renderIcon={Edit16}
  //             onClick={() =>
  //               instance.loginRedirect(b2cPolicies.authorities.addressbook)
  //             }
  //             // onClick={() => setModalset({ ...Modalset, address: true })}
  //           >
  //             Edit
  //           </Button> */}
  //             <Modal
  //               open={Modalset.address}
  //               modalLabel="Personal Info"
  //               modalHeading="Edit your address book"
  //               hasForm
  //               size="sm"
  //               primaryButtonText="Submit"
  //               secondaryButtonText="Cancel"
  //               selectorPrimaryFocus="#text-input-2"
  //               // onRequestSubmit={updateinfo}
  //               onRequestClose={() => {
  //                 setModalset({ ...Modalset, address: false });
  //                 cancelmodal();
  //               }}
  //             >
  //               {useralldata?.UserInfodata && (
  //                 <Form>
  //                   <div className="model-popup-form">
  //                     <TextInput
  //                       required={true}
  //                       id="6"
  //                       warn={!useralldata?.UserInfodata.address}
  //                       warnText="Address is required"
  //                       labelText="Address*"
  //                       placeholder="Address"
  //                       value={useralldata?.UserInfodata.address}
  //                       onChange={(e) =>
  //                         setuseralldata?.UserInfodata({
  //                           ...useralldata?.UserInfodata,
  //                           address:
  //                             e.target.value === "" ? null : e.target.value,
  //                         })
  //                       }
  //                     />
  //                   </div>
  //                   <div className="model-popup-form">
  //                     <div className="add__dropdown">
  //                       <Dropdown
  //                         id="country"
  //                         light
  //                         direction="top"
  //                         titleText="Country*"
  //                         label={useralldata?.UserInfodata.country}
  //                         items={Countries}
  //                         selectedItem={
  //                           useralldata?.UserInfodata.country ? useralldata?.UserInfodata.country : ""
  //                         }
  //                         onChange={({ selectedItem }) =>
  //                           setuseralldata?.UserInfodata({
  //                             ...useralldata?.UserInfodata,
  //                             country: selectedItem === "" ? null : selectedItem,
  //                           })
  //                         }
  //                       />
  //                     </div>

  //                     <div className="add__dropdown">
  //                       <Dropdown
  //                         warn={!useralldata?.UserInfodata.state}
  //                         warnText="State is required"
  //                         id="states"
  //                         light
  //                         direction="top"
  //                         titleText="State*"
  //                         label={useralldata?.UserInfodata.state}
  //                         items={csc
  //                           .getStatesOfCountry(
  //                             `${useralldata?.UserInfodata.country
  //                               ? useralldata?.UserInfodata.country
  //                                 .split("")
  //                                 .reverse()
  //                                 .join("")
  //                                 .slice(0, 2)
  //                                 .split("")
  //                                 .reverse()
  //                                 .join("")
  //                               : "IN"
  //                             }`
  //                           )
  //                           .map((state) => state.name)}
  //                         onChange={({ selectedItem }) =>
  //                           setuseralldata?.UserInfodata({
  //                             ...useralldata?.UserInfodata,
  //                             state: selectedItem === "" ? null : selectedItem,
  //                           })
  //                         }
  //                       />
  //                     </div>
  //                   </div>
  //                   <div className="model-popup-form">
  //                     <TextInput
  //                       warn={!useralldata?.UserInfodata.city}
  //                       warnText="City is required"
  //                       id="5"
  //                       labelText="City*"
  //                       placeholder=""
  //                       value={useralldata?.UserInfodata.city}
  //                       onChange={(e) =>
  //                         setuseralldata?.UserInfodata({
  //                           ...useralldata?.UserInfodata,
  //                           city: e.target.value === "" ? null : e.target.value,
  //                         })
  //                       }
  //                     />
  //                     <TextInput
  //                       required={true}
  //                       invalid={
  //                         useralldata?.UserInfodata.postalCode !== null &&
  //                         !/^[0-9\b]+$/.test(useralldata?.UserInfodata.postalCode)
  //                       }
  //                       invalidText={"Enter a valid postal code"}
  //                       warn={!useralldata?.UserInfodata.postalCode}
  //                       warnText="Postal code is required"
  //                       id="17"
  //                       labelText="Postal code*"
  //                       placeholder="70021"
  //                       value={useralldata?.UserInfodata.postalCode}
  //                       onChange={(e) =>
  //                         setuseralldata?.UserInfodata({
  //                           ...useralldata?.UserInfodata,
  //                           postalCode:
  //                             e.target.value === "" ? null : e.target.value,
  //                         })
  //                       }
  //                     />
  //                   </div>
  //                 </Form>
  //               )}
  //             </Modal>
  //           </div>
  //         </div>
  //       </div>
  //       <div className="bx--col-lg-4 bx--no-gutter--right">
  //         <div className="card">
  //           <div className="title">
  //             <h4>Company Information</h4>
  //           </div>
  //           <div className="details">
  //             <ul>
  //               <li className="list">
  //                 <h6>Company Name: </h6>
  //                 <p>{useralldata?.UserInfodata.companyName}</p>
  //               </li>
  //               {/* <li className="list">
  //                 <h6>Tax Id: </h6>
  //                 <p>{useralldata?.UserInfodata.taxId}</p>
  //               </li> */}
  //             </ul>
  //           </div>
  //           <div className="edit-btn">
  //             {/* <Button
  //             className="btn_height"
  //             kind="secondary"
  //             renderIcon={Edit16}
  //             onClick={() =>
  //               instance.loginRedirect(b2cPolicies.authorities.companyinfo)
  //             }
  //             // onClick={() => setModalset({ ...Modalset, company: "true" })}
  //           >
  //             Edit
  //           </Button> */}

  //             <Modal
  //               open={Modalset.company}
  //               modalLabel="Personal Info"
  //               modalHeading="Edit your company information"
  //               hasForm
  //               primaryButtonText="Submit"
  //               secondaryButtonText="Cancel"
  //               size="sm"
  //               selectorPrimaryFocus="#text-input-2"
  //               // onRequestSubmit={updateinfo}
  //               onRequestClose={() => {
  //                 setModalset({ ...Modalset, company: false });
  //                 cancelmodal();
  //               }}
  //             >
  //               {useralldata?.UserInfodata && (
  //                 <>
  //                   <div className="model-popup-form">
  //                     <TextInput
  //                       required={true}
  //                       id="1"
  //                       invalidText="Invalid error message."
  //                       labelText="Company name"
  //                       placeholder="MyCompany LLC"
  //                       value={useralldata?.UserInfodata.companyName}
  //                       onChange={(e) =>
  //                         setuseralldata?.UserInfodata({
  //                           ...useralldata?.UserInfodata,
  //                           companyName:
  //                             e.target.value === "" ? null : e.target.value,
  //                         })
  //                       }
  //                     />
  //                   </div>
  //                   <div className="model-popup-form">
  //                     <TextInput
  //                       required
  //                       id="234"
  //                       invalidText="Invalid error message."
  //                       labelText="Tax ID"
  //                       placeholder="235465656"
  //                       value={useralldata?.UserInfodata.taxId}
  //                       onChange={(e) =>
  //                         setuseralldata?.UserInfodata({
  //                           ...useralldata?.UserInfodata,
  //                           taxId: e.target.value === "" ? null : e.target.value,
  //                         })
  //                       }
  //                     />
  //                   </div>
  //                 </>
  //               )}
  //             </Modal>
  //           </div>
  //         </div>
  //       </div>

  //     </div>
  //     {/* { useralldata?.useralldata?.UserInfodatadata.newUser == "true" && */}
  //     <div className="btn_design_user">
  //       <Button
  //         disabled={useralldata?.useralldata?.UserInfodatadata.newUser}
  //         className="btn_height"
  //         kind="secondary"
  //         renderIcon={Edit16}
  //         onClick={() => {
  //           instance.loginRedirect(b2cPolicies.authorities.profileUpdate)
  //         }
  //         }
  //       // onClick={() => {
  //       //   setModalset({ ...Modalset, personal: true });
  //       //   setuseralldata?.UserInfodata({ ...useralldata?.UserInfodata, status: "check" });
  //       // }}
  //       >
  //         Profile Edit
  //       </Button>
  //     </div>
  //     {/* } */}
  //   </>
  // );
};

export default PersonalInfo;
