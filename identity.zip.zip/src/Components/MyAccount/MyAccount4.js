import React from "react";
import MyAccount from "./MyAccount";

const MyAccount4 = () => {
  return (
    <div>
      <MyAccount selected={4} />
    </div>
  );
};

export default MyAccount4;
