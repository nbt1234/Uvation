import React, { useContext, useEffect } from "react";
import { Link } from "react-router-dom";

import { Chat24, ChevronRight20 } from "@carbon/icons-react";
import { Tab, Tabs } from "carbon-components-react";
import UiHeader from "../Header/UiHeader";
import SecuritySign from "./SecuritySign";
import Privacy from "./Privacy";
import DeleteAc from "./DeleteAc";
import PersonalInfo from "./PersonalInfo";
import { Companyinfo } from "./Companyinfo";
import { GlobalContext } from "../../ContextApi/GlobalContext";

const MyAccount = ({ selected = 0 }) => {
  const { toggle, settoggle } = useContext(GlobalContext);

  return (
    <>
      <UiHeader />
      <div className="account">
        <div className="bx--grid bx--no-gutter main">
          <div className="bx--row">
            <div className="bx--col banner">
              <div>
                <h5>Welcome to</h5>
              </div>
              <div className="terms">
                <span>
                  <h2> Manage your Account</h2> <ChevronRight20 />
                </span>
                <span>
                  <Link to="/home">Home</Link>
                </span>
              </div>
            </div>
          </div>
          <div className="bx--row b">
            <Tabs className="tabs" selected={selected}>
              <Tab href="account/info" id="tab-1" label="Personal Info">
                <PersonalInfo />
              </Tab>
              <Tab href="/account/companyinfo" id="tab-2" label="Company Info">
                <Companyinfo />
              </Tab>
              <Tab
                href="/account/security"
                id="tab-3"
                label="Security & Sign In"
              >
                <SecuritySign />
              </Tab>
              <Tab
                href="account/security"
                id="tab-4"
                label="Privacy & Contact Preferences"
              >
                <Privacy />
              </Tab>
              <Tab href="#" id="tab-5" label="Deactivate account">
                <DeleteAc />
              </Tab>
            </Tabs>
          </div>
        </div>
      </div>
      <div
        className="chat-bot-icon"
        onClick={() =>
          settoggle({
            ...toggle,
            Support: !toggle.Support,
            tabselect: 1,
          })
        }
      >
        <Chat24 />
      </div>
      <div
        className="chat-bot-icon2"
        onClick={() =>
          settoggle({
            ...toggle,
            Support: !toggle.Support,
            tabselect: 1,
          })
        }
      >
        <Chat24 />
      </div>
    </>
  );
};

export default MyAccount;
