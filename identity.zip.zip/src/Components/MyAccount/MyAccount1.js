import React from "react";
import MyAccount from "./MyAccount";

const MyAccount1 = () => {
  return (
    <div>
      <MyAccount selected={1} />
    </div>
  );
};

export default MyAccount1;
