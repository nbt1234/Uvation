import { useMsal, useAccount } from "@azure/msal-react";
import {
  Edit16,
  Edit20,
  Email16,
  Email20,
  Locked32,
  Login32,
  MobileCheck20,
  QrCode16,
  Close24,
} from "@carbon/icons-react";
import axios from "axios";
import {
  Button,
  ComposedModal,
  Form,
  ModalBody,
  ModalWrapper,
  RadioTile,
  TextInput,
  TileGroup,
  Toggle,
  TooltipDefinition,
  HeaderGlobalAction,
} from "carbon-components-react";
import React, { useState, useContext, useEffect } from "react";
import { Contextprovider } from "../../App";
import { b2cPolicies } from "../../authConfig";
import { GlobalContext } from "../../ContextApi/GlobalContext";

const SecuritySign = () => {
  const {useralldata} = useContext(Contextprovider)
  const { ToggleBtnMode, setToggleBtnMode} =
    useContext(GlobalContext);
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [mfadetail, setmfadetail] = useState(false);
  const styledesign = `${mfadetail == false ? "card" : "card mfa_toggle_btn"}`;
  useEffect(() => {
    if (useralldata?.UserInfodata?.newUser == false) {
      setmfadetail(true);
    }
  }, [account]);

  return (
    <div className="bx--row e">
      <div className="bx--col-lg-4">
        <div className={styledesign}>
          <div className="title">
            <h4>Change Password</h4>
          </div>
          <div className=" password_privacy">
            <div className=" password_privacy_icon" style={{ border: "none" }}>
              <Locked32 />
            </div>
          </div>
          <div className="edit-btn">
            <Button
              kind="secondary"
              renderIcon={Edit16}
              onClick={() =>
                instance.loginRedirect(b2cPolicies.authorities.changePassword)
              }
            >
              Edit
            </Button>
            {/* <ModalWrapper
              modalLabel="Change Password"
              modalHeading="Change your password"
              size="xs"
              buttonTriggerText="Edit"
              triggerButtonKind="secondary"
              renderTriggerButtonIcon={Edit16}
              buttonTriggerClassName="modal-btn"
              hasForm
            >
              <Form style={{ marginBottom: "2rem" }}>
                <div className="mobSecurity">
                  <TextInput.PasswordInput
                    id="test3"
                    invalidText="Invalid error message."
                    labelText="Current Password*"
                    placeholder="***********"
                  />
                  <TextInput.PasswordInput
                    id="test4"
                    invalidText="Invalid error message."
                    labelText="New Password*"
                    placeholder="***********"
                  />
                  <TextInput.PasswordInput
                    id="test5"
                    invalidText="Invalid error message."
                    labelText="Confirm New password*"
                    placeholder="***********"
                  />
                </div>
                <div className="helping-text">
                  <div className="items">
                    <span>- 8characters minimum </span>
                    <span>-One uppercase character</span>
                  </div>
                  <div className="items">
                    <span>-One lowercase characters</span>
                    <span> -One number</span>
                  </div>
                </div>
              </Form>
            </ModalWrapper> */}
          </div>
        </div>
      </div>
      <div className="bx--col-lg-4">
        <div className={styledesign}>
          <div className="title">
            <h4> Multi-Factor Authentication</h4>
          </div>
          <div className="auth">
            <div className="mfa_editing">
              <div className="mfa_editing_heading">
                <h6>Selectd MFA </h6>
              </div>
            </div>
            {mfadetail && (
              <div className="imp_notephn">
                <p>Note: Only preferred phone number can be changed</p>
              </div>
            )}
            {mfadetail && (
              <div className="mfa_editing_btn">
                <HeaderGlobalAction aria-label="MFA can't be turned off or disabled">
                  <Toggle
                    // defaultToggled
                    toggled={true}
                    aria-label="toggle button"
                    id="toggle-1"
                    className="tooltip-trigger"
                    // onToggle={
                    //   ToggleBtnMode.ToggleBtnModeon == true
                    //     ? () =>
                    //         setToggleBtnMode({ ...ToggleBtnMode, CloseModal: true })
                    //     : () =>
                    //         setToggleBtnMode({
                    //           ...ToggleBtnMode,
                    //           ToggleBtnModeon: !ToggleBtnMode.ToggleBtnModeon,
                    //           TileOption: true,
                    //         })
                    // }
                  />
                </HeaderGlobalAction>
              </div>
            )}
            {/* {ToggleBtnMode.SelectedTile !== "" ? (
              <h6>You have selected:</h6>
            ) : (
           
            )} */}
            {
              // ToggleBtnMode.SelectedTile === "sms" ? (
              //   <div className="modal__tile_sm">
              //     <div className="tile__content ">
              //       <MobileCheck20 />
              //     </div>
              //     <div>
              //       <p>Send the code through SMS</p>
              //     </div>
              //     <Edit20
              //       className="tile_edit_btn"
              //       tile__content
              //       onClick={() =>
              //         setToggleBtnMode({
              //           ...ToggleBtnMode,
              //           TileOption: true,
              //           EditTileOption: true,
              //         })
              //       }
              //     />
              //   </div>
              // ) : ToggleBtnMode.SelectedTile === "email" ? (
              //   <div className="modal__tile_sm">
              //     <div className="tile__content ">
              //       <Email16 />
              //     </div>
              //     <div>
              //       <p>Send the code through email</p>
              //     </div>
              //     <Edit20
              //       className="tile_edit_btn"
              //       onClick={() =>
              //         setToggleBtnMode({
              //           ...ToggleBtnMode,
              //           TileOption: true,
              //           EditTileOption: true,
              //         })
              //       }
              //     />
              //   </div>
              // ) : ToggleBtnMode.SelectedTile === "qrcode" ? (
              //   <div className="modal__tile_sm">
              //     <div className="tile__content ">
              //       <QrCode16 />
              //     </div>
              //     <div>
              //       <p>By scanning a QR code</p>
              //     </div>
              //     <Edit20
              //       className="tile_edit_btn"
              //       onClick={() =>
              //         setToggleBtnMode({
              //           ...ToggleBtnMode,
              //           TileOption: true,
              //           EditTileOption: true,
              //         })
              //       }
              //     />
              //   </div>
              // ) :
              useralldata?.UserInfodata?.Preferred_MFA === "phone" ? (
                <div className="modal__tile_sm mt-2">
                  <div className="tile__content ">
                    <MobileCheck20 />
                  </div>
                  <div>
                    {useralldata?.UserInfodata?.New_MFA_PhoneNumber ? (
                      <p>{useralldata?.UserInfodata?.New_MFA_PhoneNumber}</p>
                    ) : (
                      <p>{useralldata?.UserInfodata?.MFA_PhoneNumber}</p>
                    )}
                  </div>
                  {/* <Edit20
                    className="tile_edit_btn"
                    onClick={() =>
                      setToggleBtnMode({
                        ...ToggleBtnMode,
                        TileOption: true,
                        EditTileOption: true,
                      })
                    }
                  /> */}
                </div>
              ) : useralldata?.UserInfodata?.Preferred_MFA === "email" ? (
                <div className="modal__tile_sm mt-2">
                  <div className="tile__content ">
                    <Email16 />
                  </div>
                  <div>
                    <p>{useralldata?.UserInfodata?.email}</p>
                  </div>
                  {/* <Edit20
                  className="tile_edit_btn"
                  onClick={() =>
                    setToggleBtnMode({
                      ...ToggleBtnMode,
                      TileOption: true,
                      EditTileOption: true,
                    })
                  }
                /> */}
                </div>
              ) : (
                <div className="modal__tile_sm">
                  <div>
                    <p>MFA not configured yet !</p>
                  </div>
                  {/* <Edit20
                  className="tile_edit_btn"
                  onClick={() =>
                    setToggleBtnMode({
                      ...ToggleBtnMode,
                      TileOption: true,
                      EditTileOption: true,
                    })
                  }
                /> */}
                </div>
              )
            }
          </div>
          {/* <div className="imp_notephngh">
            <p><span>Note</span>:You Can edit only Prefaired mfa number</p>
          </div> */}
          {mfadetail && (
            <div className="edit-btn">
              <Button
                kind="secondary"
                renderIcon={Edit16}
                onClick={() => {
                  // setToggleBtnMode({
                  //   ...ToggleBtnMode,
                  //   TileOption: true,
                  //   EditTileOption: true,
                  // })

                  instance.loginRedirect(b2cPolicies.authorities.editmfanumber);
                }}
              >
                Edit
              </Button>
            </div>
          )}
        </div>
      </div>

      <ComposedModal
        open={ToggleBtnMode.TileOption}
        size="xs"
        preventCloseOnClickOutside={true}
      >
        <ModalBody hasForm>
          <Button
            //disabled={ToggleBtnMode.EditTileOption}
            className="no__cancel"
            kind="ghost"
            onClick={() =>
              setToggleBtnMode({
                ...ToggleBtnMode,
                ToggleBtnModeon: false,
                TileOption: false,
                SelectedTile: "",
              })
            }
          >
            <Close24 />
          </Button>
          <div className="delete__model">
            <div className="delete__model__header">
              <div
                className="delete__model__header__icon"
                style={{ background: "#ECF5FF" }}
              >
                <Login32 fill="#0F61FD" />
              </div>
            </div>
            <div className="delete__model__heading">
              <h6>Multi-Factor Authentication</h6>
            </div>
            <div className="delete__model__subheading">
              <p>
                Manage your sign in preferences and add an extra security layer
                that verifies a user’s identity by requiring multiple
                credentials. Select where to receive your two-step
                authentication code:
              </p>
              {/* <p className="delete__model_paragraph"><span className="delete__model_span">Note:</span> You Can Edit Only  MFA Number</p> */}
            </div>
            <div className="modal__tiles">
              <TileGroup
                defaultSelected={ToggleBtnMode.SelectedTile}
                onChange={(defaultSelected) =>
                  setToggleBtnMode({
                    ...ToggleBtnMode,
                    SelectedTile: defaultSelected,
                  })
                }
                name="tile-group"
              >
                <RadioTile
                  id="tile-1"
                  name="tiles"
                  tabIndex={0}
                  value="sms"
                  onClick={() => {
                    instance.loginRedirect(
                      b2cPolicies.authorities.editmfanumber
                    );
                  }}
                >
                  <div className="modal__tile">
                    <div className="tile__content ">
                      <MobileCheck20 />
                    </div>
                    <p>Edit The Preferd MFA number</p>
                  </div>
                </RadioTile>
                {/* <RadioTile id="tile-2" name="tiles" tabIndex={0} value="email">
                  <div className="modal__tile">
                    <div className="tile__content ">
                      <Email20 />
                    </div>

                    <p>Send the code through email</p>
                  </div>
                </RadioTile> */}
                {/* <RadioTile id="tile-3" name="tiles" tabIndex={0} value="qrcode">
                  <div className="modal__tile">
                    <div className="tile__content ">
                      <QrCode16 />
                    </div>
                    <p>By scanning a QR code</p>
                  </div>
                </RadioTile> */}
              </TileGroup>
            </div>
            {/* <div className="multifactor__model__btn">
              <Button
                //disabled={ToggleBtnMode.EditTileOption}
                className="no__cancel"
                kind="ghost"
                onClick={() =>
                  setToggleBtnMode({
                    ...ToggleBtnMode,
                    ToggleBtnModeon: false,
                    TileOption: false,
                    SelectedTile: "",
                  })
                }
              >
                Cancel
              </Button>
              <Button
                disabled={ToggleBtnMode.SelectedTile === ""}
                // onClick={() =>
                //   instance.loginRedirect(b2cPolicies.authorities.editmfa)
                // }
                onClick={() =>
                  {
                    instance.loginRedirect(b2cPolicies.authorities.editmfanumber)
                  setToggleBtnMode({
                    ...ToggleBtnMode,
                    ToggleBtnModeon: true,
                    TileOption: false,
                    EditTileOption: false,
                  })
                }
                }
              >
                Save
              </Button>
            </div> */}
          </div>
        </ModalBody>
      </ComposedModal>

      <ComposedModal
        open={ToggleBtnMode.CloseModal}
        size="xs"
        preventCloseOnClickOutside={false}
      >
        <ModalBody hasForm>
          <div className="delete__model">
            <div className="delete__model__header">
              <div
                className="delete__model__header__icon"
                style={{ background: "#FEF8D1" }}
              >
                <Login32 fill="#F0C11B" />
              </div>
            </div>
            <div className="delete__model__heading">
              <h6>Attention!</h6>
            </div>
            <div className="delete__model__subheading">
              <p>
                We do not recommend doing this change. Lorem ipsum dolor sit
                amet, consectetur adipiscing elit. Sed ultricies viverra mi,
                vitae eleifend mi vestibulum sed. In hac habitasse platea
                dictumst.
              </p>
            </div>

            <div className="multifactor__model__btn">
              <Button
                className="no__cancel"
                kind="ghost"
                onClick={() =>
                  setToggleBtnMode({ ...ToggleBtnMode, CloseModal: false })
                }
              >
                Cancel
              </Button>
              <Button
                onClick={() =>
                  setToggleBtnMode({
                    ...ToggleBtnMode,
                    ToggleBtnModeon: false,
                    CloseModal: false,
                    SelectedTile: "",
                  })
                }
                style={{ background: "#F0C11B" }}
              >
                Do it anyway
              </Button>
            </div>
          </div>
        </ModalBody>
      </ComposedModal>
    </div>
  );
};

export default SecuritySign;
