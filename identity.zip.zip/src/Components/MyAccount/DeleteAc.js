import React, { useContext, useEffect, useState } from "react";
import {
  Chat16,
  Delete32,
  Headphones16,
  Phone16,
  WarningAlt24,
} from "@carbon/icons-react";
import { Button, ComposedModal, ModalBody } from "carbon-components-react";
import PhoneNumber from "react-phone-number";
import { Link } from "react-router-dom";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import { useMsal } from "@azure/msal-react";
import { useHistory } from "react-router-dom";
import { b2cPolicies } from "../../authConfig";
import axios from "axios";
const StyleBtn = {
  backgroundColor: "white",
  color: "#515151",
  border: "1px solid #c6c6c6",
  maxHeight: "2.5rem",
};

const DeleteAc = () => {
  const history = useHistory();
  const { instance, inProgress, accounts } = useMsal();
  const {
    toggle,
    settoggle,
    Alldata,
    contactdata,
    contactsalesforce,
    contactinfodata,
  } = useContext(GlobalContext);
  const [Open, setOpen] = useState(false);
  const [Deactivate, setDeactivate] = useState(false);
  const [data, setdata] = useState();

  const useracountdelete = () => {
    axios
      .patch(
        `${contactdata?.instance_url}/services/data/v41.0/sobjects/contact/${contactinfodata?.recordId}`,
        {
          Status__c: "Deactivated",
        },
        {
          headers: {
            Authorization: `Bearer ${contactdata?.access_token}`,
            "Access-Control-Allow-Origin": "*",
            "Content-Type": "application/json",
          },
        }
      )
      .then((res) => {
        if (res?.status == 204) {
          instance.loginRedirect(b2cPolicies.authorities.deactivate);
        }
      });

    //
  };
  return (
    <div className="bx--row deleteac">
      <div className="bx--col-lg-8  bx--col--md-1 bx--no-gutter">
        <div className="warning-col">
          <div className="icon">
            <WarningAlt24 />
          </div>
          <div className="warning">
            <h4>Deactivate account</h4>

            <p>
              If you are having issues with your account or our services, please{" "}
              <span className="deactivate_pageinfochat">chat with us </span>or
              <span className="deactivate_pageinfochat">
                {" "}
                call technical support
              </span>{" "}
              at <span className="deactivate_pageinfochat">+1 8336204702.</span>
            </p>
            <p className="alternatively_account">
              Alternatively, you can{" "}
              <span className="deactivate_pageinfochat">
                open a support ticket.
              </span>
            </p>
            <h5>
              <span>Warning</span>: Deactivating your account will unsubscribe
              you from Uvation’s services and erase all data associated with
              your account.
            </h5>
            <h5>This action cannot be undone.</h5>
            <p>
              You can reactivate your account at a later time, but you cannot
              recover your lost data.
            </p>
          </div>
        </div>
      </div>
      <div className="bx--col-lg-8 bx--col--md-1 btn-col bx--no-gutter--right">
        <div>
          <ComposedModal open={Open} size="xs">
            <ModalBody>
              <div className="delete__model">
                <div className="delete__model__header">
                  <div className="delete__model__header__icon">
                    <Delete32 fill="#FA4D56" />
                  </div>
                </div>
                <div className="delete__model__heading">
                  <h6>You are about to deactivate</h6>
                  <h6>your account</h6>
                </div>
                <div className="delete__model__subheading">
                  <p>
                    Deactivating this account means that all of your information
                    will be permanently erased from our servers in
                    <span> 30 days</span>. Are you sure?
                  </p>
                </div>
                <div className="delete__model__btn">
                  <Button
                    className="no__cancel"
                    kind="ghost"
                    onClick={() => setOpen(!Open)}
                  >
                    No, cancel
                  </Button>
                  <Button kind="danger" className="deactivate">
                    Yes, deactivate it
                  </Button>
                </div>
              </div>
            </ModalBody>
          </ComposedModal>
        </div>

        <div className="btnss filterBlock">
          <Button
            renderIcon={Chat16}
            size="field"
            onClick={() =>
              settoggle({ ...toggle, Support: true, tabselect: 1 })
            }
          >
            Chat
          </Button>
          <Button
            size="field"
            renderIcon={Phone16}
            style={StyleBtn}
            onClick={() =>
              settoggle({ ...toggle, Support: true, tabselect: 2 })
            }
          >
            Call
          </Button>
          <Button
            size="field"
            renderIcon={Headphones16}
            style={StyleBtn}
            onClick={() =>
              settoggle({ ...toggle, Support: true, tabselect: 0 })
            }
          >
            Open ticket
          </Button>
        </div>
        <div className="bx--col">
          <div className="deactive__btn">
            <Button
              size="field"
              kind="danger"
              className="deactivate"
              disabled={Deactivate}
              onClick={() => {
                useracountdelete();
              }}
            >
              Deactivate account
            </Button>
          </div>

          <div className="btnss mob-btn">
            <div style={{ display: "flex", gridGap: "8px" }}>
              <Button
                size="field"
                renderIcon={Headphones16}
                style={StyleBtn}
                onClick={() =>
                  settoggle({ ...toggle, Support: true, tabselect: 0 })
                }
              >
                Open ticket
              </Button>
              <Button
                size="field"
                renderIcon={Phone16}
                style={StyleBtn}
                onClick={() =>
                  settoggle({ ...toggle, Support: true, tabselect: 2 })
                }
              >
                Call
              </Button>
            </div>
            <div className="chat-mob">
              <Button
                renderIcon={Chat16}
                size="field"
                onClick={() =>
                  settoggle({ ...toggle, Support: true, tabselect: 1 })
                }
              >
                Chat
              </Button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DeleteAc;
