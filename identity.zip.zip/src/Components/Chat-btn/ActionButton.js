import React, { Component } from 'react';

class ActionButton extends Component {
  render() {
    return (
      <button
        className={`action-button ${this.props.addClass}`}
        onClick={this.props.onClick}
      >
        {this.props.label}
      </button>
    );
  }
}

ActionButton.displayName = 'ActionButton';

export default ActionButton;
