import React, { useContext, useEffect, useState } from "react";
import {
  Chat24,
  ChevronRight20,
  Close16,
  Purchase20,
} from "@carbon/icons-react";
import {
  DataTable,
  TableContainer,
  TableToolbar,
  TableToolbarContent,
  TableToolbarSearch,
  Button,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  Dropdown,
  Pagination,
  OverflowMenu,
  OverflowMenuItem,
  HeaderPanel,
  TableSelectAll,
  TableSelectRow,
  Loading,
} from "carbon-components-react";
import { Link } from "react-router-dom";
import UiHeader from "../Header/UiHeader";
import {
  msg_rowData,
  msg_headerData,
  userdropdwonitems,
} from "../Data/DataJson";

import { GlobalContext } from "../../ContextApi/GlobalContext";
import { cssNumber } from "jquery";
import axios from "axios";
import { Contextprovider } from "../../App";

const items = [
  {
    id: "option-1",
    label: "Option 1",
  },
  {
    id: "option-2",
    label: "",
  },
  {
    id: "Siginlogs_Info",
    label: "Siginlogs_Info",
  },
];

const NotificationMessage = () => {
  const [isLoading, setIsLoading] = useState(false); 
  const [Toggle, setToggle] = useState(false);
  const [ondata, setondata] = useState();
  const [systemdata, setsystemdata] = useState("Siginlogs Info");
 
  function ToggleON() {
    setToggle(!Toggle);
  }

  const { useralldata , dispatch} =useContext(Contextprovider)
    const {
    toggle,
    settoggle,
    account,
    MsAccessToken,  
  } = useContext(GlobalContext);
  const siginlogsData = useralldata?.UserLogsdata?.data?.user_info?.value;
  const totalItemrow = useralldata?.UserLogsdata?.data?.user_info?.totalItem;
  const systremdata = useralldata?.UserallNotification?.data;
  const totalcount = useralldata?.UserallNotification?.count;

  const userdropdwonitems = [
    {
      id: "option-1",
      label: "System notification",
    },
    {
      id: "option-2",
      label: "Siginlogs Info",
    },
  ];
  const msg_headerData = [
    {
      header: "User Name",
      key: "userDisplayName",
    },
    {
      header: "Date and Time",
      key: "createdDateTime",
    },
    {
      header: "IP Address",
      key: "ipAddress",
    },
    {
      header: "Browser",
      key: "browser",
    },
    {
      header: "Operating System",
      key: "operatingSystem",
    },
  ];
  const msg_headerData5 = [
    {
      header: "Message",
      key: "message",
    },
  ];

  // const uservaluepasss=(e)=>{
  //   setIsLoading(true)
  useEffect(() => {
    setIsLoading(true);

    const headers = new Headers();
    const bearer = `Bearer ${MsAccessToken?.data?.data?.access_token}`;
    headers.append("Authorization", bearer);
    var newData = {
      userid: useralldata?.UserInfodata?.sub,
      firstname: useralldata?.UserInfodata?.given_name,
      lastname: useralldata?.UserInfodata?.family_name,
    };
    axios
      .post("https://appsapi.uvation.com:8080/identity/hello", newData)
      .then((res) => {
        if(res?.data?.status){
        setIsLoading(false);
        dispatch({type:"USER_SIGNIN_LOGS",payload:res?.data})
      }
      });
  }, [account]);

  const handlePageChange = (pagenumber = { page: 1, pageSize: 10 }) => {
    axios
      .post("https://notifications.uvation.com:443/api/show_notification", {
        userid: useralldata?.UserInfodata?.sub,
        platform: "uvation identity",
        page_no: pagenumber.page,
        per_page: pagenumber.pageSize,
      })
      .then((res) => {
        dispatch({type:"USER_All_NOTIFICATION",payload:res?.data})
      });
  };
  useEffect(() => {
    handlePageChange();
  }, [account]);
  return (
    <>
      <Loading active={isLoading} withOverlay />

      <UiHeader />
      <div className="bx--grid--full-width Notification">
        <div className="bx--grid bx--no-gutter">
          <div className="notification-page">
            <div className="bx--row bx--row-padding">
              <div className="bx--col notification-info">
                <h3>Welcome to</h3>
                <h1>
                  Notification & message
                  <span>
                    <ChevronRight20 />
                  </span>
                  <Link to="/home">Home</Link>
                </h1>
              </div>
            </div>
            <div className="bx--row">
              {systemdata == "Siginlogs Info"
                ? siginlogsData &&
                  siginlogsData.length && (
                    <DataTable
                      isSortable
                      rows={siginlogsData}
                      headers={msg_headerData}
                      overflowMenuOnHover={false}
                      render={({
                        rows,
                        headers,
                        getHeaderProps,
                        getTableProps,
                        getToolbarProps,
                        onInputChange,
                        getRowProps,
                        getSelectionProps,
                      }) => (
                        <TableContainer>
                          <TableToolbar
                            {...getToolbarProps()}
                            aria-label="data table toolbar"
                          >
                            <TableToolbarContent>
                              <TableToolbarSearch
                                placeHolderText="Search Message"
                                onChange={onInputChange}
                                expanded
                              />
                            </TableToolbarContent>
                          </TableToolbar>

                          <TableToolbarContent>
                            <Dropdown
                              ariaLabel="Dropdown"
                              id="carbon-dropdown-example"
                              items={userdropdwonitems}
                              label="Signin logs Info"
                              titleText=""
                              value={ondata}
                              onChange={(e) => {
                                setsystemdata(e.selectedItem?.label);
                              }}
                            />

                            <Pagination
                              backwardText="Previous page"
                              forwardText="Next page"
                              itemsPerPageText="Items per page:"
                              page={1}
                              onChange={onInputChange}
                              pageNumberText="Page Number"
                              pageSize={10}
                              pageSizes={[10, 20, 30, 40, 50]}
                              totalItems={totalItemrow}
                            />
                          </TableToolbarContent>

                          <Table {...getTableProps()}>
                            <TableHead>
                              <TableRow>
                                <TableSelectAll {...getSelectionProps()} />
                                {headers.map((header, i) => (
                                  <TableHeader
                                    key={i}
                                    {...getHeaderProps({ header })}
                                  >
                                    {header.header}
                                  </TableHeader>
                                ))}
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {rows.map((row, i) => (
                                <TableRow
                                  key={i}
                                  {...getRowProps({
                                    row,
                                  })}
                                >
                                  <TableSelectRow
                                    {...getSelectionProps({ row })}
                                  />
                                  {row.cells.map((cell) => (
                                    <TableCell
                                      style={{ cursor: "pointer" }}
                                      // onClick={ToggleON}
                                      key={cell.id}
                                    >
                                      {cell.value}
                                    </TableCell>
                                  ))}
                                  <TableCell>
                                    <OverflowMenu flipped>
                                      <OverflowMenuItem>
                                        Action 1
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 2
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 3
                                      </OverflowMenuItem>
                                    </OverflowMenu>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      )}
                    />
                  )
                : systremdata &&
                  systremdata && (
                    <DataTable
                      isSortable
                      rows={systremdata}
                      headers={msg_headerData5}
                      overflowMenuOnHover={false}
                      render={({
                        rows,
                        headers,
                        getHeaderProps,
                        getTableProps,
                        getToolbarProps,
                        onInputChange,
                        getRowProps,
                        getSelectionProps,
                      }) => (
                        <TableContainer>
                          <TableToolbar
                            {...getToolbarProps()}
                            aria-label="data table toolbar"
                          >
                            <TableToolbarContent>
                              <TableToolbarSearch
                                placeHolderText="Search Message"
                                onChange={onInputChange}
                                expanded
                              />
                            </TableToolbarContent>
                          </TableToolbar>

                          <TableToolbarContent>
                            <Dropdown
                              ariaLabel="Dropdown"
                              id="carbon-dropdown-example"
                              items={userdropdwonitems}
                              label="Signin logs Info"
                              titleText=""
                              value={ondata}
                              onChange={(e) => {
                                setsystemdata(e.selectedItem?.label);
                              }}
                            />

                            <Pagination
                              backwardText="Previous page"
                              forwardText="Next page"
                              itemsPerPageText="Items per page:"
                              page={1}
                              // onChange={onInputChange}
                              pageNumberText="Page Number"
                              pageSize={10}
                              pageSizes={[10, 20, 30, 40, 50]}
                              totalItems={totalcount}
                              onChange={handlePageChange}
                            />
                          </TableToolbarContent>

                          <Table {...getTableProps()}>
                            <TableHead>
                              <TableRow>
                                <TableSelectAll {...getSelectionProps()} />
                                {headers.map((header, i) => (
                                  <TableHeader
                                    key={i}
                                    {...getHeaderProps({ header })}
                                  >
                                    {header.header}
                                  </TableHeader>
                                ))}
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {rows.map((row, i) => (
                                <TableRow
                                  key={i}
                                  {...getRowProps({
                                    row,
                                  })}
                                >
                                  <TableSelectRow
                                    {...getSelectionProps({ row })}
                                  />
                                  {row.cells.map((cell) => (
                                    <TableCell
                                      style={{ cursor: "pointer" }}
                                      // onClick={ToggleON}
                                      key={cell.id}
                                    >
                                      {cell.value}
                                    </TableCell>
                                  ))}
                                  <TableCell>
                                    <OverflowMenu flipped>
                                      <OverflowMenuItem>
                                        Action 1
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 2
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 3
                                      </OverflowMenuItem>
                                    </OverflowMenu>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      )}
                    />
                  )}
              {/* {systremdata && ( */}
            </div>
          </div>
        </div>
        <div className="NotificationHeader-panel">
          <HeaderPanel aria-label="Header Panel" expanded={Toggle}>
            <div onClick={ToggleON} className="close-overlay"></div>
            <div class="Notification-panel">
              <div className="heading-banner">
                <div className="invoice-title">
                  <div className="circle c40">
                    <Purchase20 />
                  </div>
                  <div className="title">
                    <h1>You have one invoice waiting</h1>
                    <p>Wednesday, May 26th, 2020 (08:07)</p>
                  </div>
                </div>
                <div className="circle c32">
                  <Close16 onClick={ToggleON} style={{ cursor: "pointer" }} />
                </div>
              </div>
              <div className="panel-content">
                <h3>Hi, Customer Name</h3>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
                  facilisis dui sed quam auctor, sed dictum ex lobortis. Ut et
                  erat vitae nulla scelerisque maximus. Aliquam eget mauris
                  lobortis, hendrerit velit vitae, imperdiet purus. Sed
                  convallis tincidunt dapibus. Nunc nec massa ultrices,
                  hendrerit lectus at, feugiat dui. Vivamus et lacus metus.
                  Integer sed quam in sapien interdum euismod.
                </p>
                <p>
                  Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nulla
                  facilisis dui sed quam auctor, sed dictum ex lobortis. Ut et
                  erat vitae nulla scelerisque maximus. Aliquam eget mauris
                  lobortis, hendrerit velit vitae, imperdiet purus. Sed
                  convallis tincidunt dapibus. Nunc nec massa ultrices,
                  hendrerit lectus at, feugiat dui. Donec varius cursus rutrum.
                </p>
                <div className="btn-set">
                  <Button>Dismiss</Button>
                </div>
              </div>
            </div>
          </HeaderPanel>
        </div>
      </div>
      <div
        className="chat-bot-icon"
        onClick={() =>
          settoggle({
            ...toggle,
            Support: !toggle.Support,
            tabselect: 1,
          })
        }
      >
        <Chat24 />
      </div>
      <div
        className="chat-bot-icon2"
        onClick={() =>
          settoggle({
            ...toggle,
            Support: !toggle.Support,
            tabselect: 1,
          })
        }
      >
        <Chat24 />
      </div>
    </>
  );
};

export default NotificationMessage;
