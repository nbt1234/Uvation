import React, { useContext, useState, useEffect } from "react";
import {
  Headset32,
  Launch16,
  ArrowRight20,
  ShoppingCatalog32,
  SendAlt32,
  Task32,
  Hourglass32,
  InProgress32,
  Chat20,
  Headset20,
  Report20,
  Chat24,
  Information16,
} from "@carbon/icons-react";
import { Link } from "react-router-dom";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import { ModalWrapper, Loading } from "carbon-components-react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";

const RequestCard = ({ RequestTitle, RequestIcon, RequestDesc, onClick }) => (
  <div
    className="bx--col bx--col-md-16 bx--col-sm-16 bx--no-gutter--left"
    onClick={onClick}
  >
    <div className="col-set">
      <div className="circle64">{RequestIcon}</div>
      <h4>{RequestTitle}</h4>
      <p>
        Open a service request ticket to report a technical problem or get
        technical assistance with Uvation’s products and services.
        {RequestDesc}
      </p>
      <div className="btn-aling">
        <Link to="#" className="align">
          Open
          <Launch16 />
        </Link>
      </div>
    </div>
  </div>
);
const RequestCard1 = ({ RequestTitle, RequestIcon, RequestDesc, onClick }) => (
  <div
    className="bx--col bx--col-md-16 bx--col-sm-16 bx--no-gutter--left"
    onClick={onClick}
  >
    <div className="col-set">
      <div className="circle64">{RequestIcon}</div>
      <h4>{RequestTitle}</h4>
      <p>
        Open a service request ticket to get assistance with a quality assurance
        issue or another issue relating to your customer account.
        {RequestDesc}
      </p>
      <div className="btn-aling">
        <Link to="#" className="align">
          Open
          <Launch16 />
        </Link>
      </div>
    </div>
  </div>
);

const SummaryCard = ({ SummaryIcon, SummaryCat, SummaryCatCount, onClick }) => (
  <div
    className="bx--col bx--col-md-4 bx--col-sm-4 bx--no-gutter--left"
    onClick={onClick}
  >
    <Link to="allticket">
      <div className="col-set">
        <div className="circle64">{SummaryIcon}</div>
        <div className="summay-title">
          <h4>{SummaryCat}</h4>
          <h2>{SummaryCatCount}</h2>
        </div>
        <div className="btn-aling">
          <ArrowRight20 />
        </div>
      </div>
    </Link>
  </div>
);
const settings = {
  arrows: false,
  dots: true,
  pauseOnHover: true,
  infinite: true,
  speed: 1000,
  autoplay: true,
  variableWidth: false,
  slidesToShow: 1,
  slidesToScroll: 1,
};

// console.log(signInAuthProvider);

// var url =
//   'https://testuvation.b2clogin.com/abf974f9-e104-46d9-8df6-3f59057043ef/v2.0/me';

// const request = async () => {
//   const token = await signInAuthProvider.getAccessToken();
//   // console.log(token.accessToken);
//   return fetch(url, {
//     method: 'GET',
//     headers: {
//       Authorization: 'Bearer ' + token.accessToken,
//       'Content-Type': 'application/json',
//       'Access-Control-Allow-Origin': '*',
//     },
//   })
//     .then((response) => response.json())
//     .then((response) => {
//       console.log('Web API returned:\n' + JSON.stringify(response));
//     })
//     .catch((error) => {
//       console.log('Error calling the Web api:\n' + error);
//     });
// };

const ScHome = () => {
  const { toggle, settoggle, GlobalState, userInfo, isLoading } =
    useContext(GlobalContext);
  const [mob, setmob] = useState(true);

  useEffect(() => {
    // callApiWithAccessToken();
    // request();
  }, []);

  return (
    <div className=" SC_Homepage">
      <Loading active={isLoading} withOverlay />
      <div className="bx--grid bx--no-gutter">
        <div className="home-page">
          <div className="bx--row bx--row-padding user-name-info">
            <div className="bx--col">
              <h3>Welcome,</h3>
              <h1>
                {userInfo.fullname} {userInfo.surname}
              </h1>
            </div>
            <div className="bx--col bx--no-gutter--right">
              <div className="bx--row support-links">
                <div className="support-type">
                  <Chat20 />
                  <h6>Chat with a support agent.</h6>
                  <Link
                    to="#"
                    onClick={() =>
                      settoggle({
                        ...toggle,
                        Support: !toggle.Support,
                        tabselect: 1,
                      })
                    }
                  >
                    Live chat with support
                  </Link>
                </div>
                <div className="support-type">
                  <Headset20 />
                  <h6>Call us any time.</h6>
                  <Link
                    to="#"
                    onClick={() =>
                      settoggle({
                        ...toggle,
                        Support: !toggle.Support,
                        tabselect: 2,
                      })
                    }
                  >
                    833-620-4702
                  </Link>
                </div>
                <div className="support-type">
                  <Report20 />
                  <h6>Can't find the help you're looking for?</h6>
                  <Link
                    to="#"
                    onClick={() =>
                      settoggle({
                        ...toggle,
                        Support: !toggle.Support,
                        tabselect: 0,
                      })
                    }
                  >
                    create case +
                  </Link>
                </div>
              </div>
              <div className="mob">
                <ModalWrapper
                  buttonTriggerText="Info"
                  size="xs"
                  passiveModal
                  triggerButtonKind="ghost"
                  translate
                  renderTriggerButtonIcon={Information16}
                  onClick={() => setmob(!mob)}
                >
                  <div>
                    <h3>Pick your favorite way of contacting us</h3>
                  </div>
                  <div className="support-type">
                    <Chat20 />
                    <h6>Chat with a support agent.</h6>
                    <Link
                      to="#"
                      onClick={() => {
                        settoggle({
                          ...toggle,
                          Support: !toggle.Support,
                          tabselect: 1,
                        });
                        setmob(!mob);
                      }}
                    >
                      Live chat with support
                    </Link>
                  </div>
                  <div className="support-type">
                    <Headset20 />
                    <h6>Call us any time.</h6>
                    <Link to="#">833-620-4702</Link>
                  </div>
                  <div className="support-type">
                    <Report20 />
                    <h6>Can't find the help you're looking for?</h6>
                    <Link
                      to="#"
                      onClick={(e) => {
                        settoggle({
                          ...toggle,
                          Support: !toggle.Support,
                          tabselect: 0,
                        });
                        setmob(!mob);
                      }}
                      className={mob ? "is-visible" : ""}
                    >
                      create case +
                    </Link>
                  </div>
                </ModalWrapper>
              </div>
            </div>
          </div>
          <div className="home-page-submit-summary">
            <div className="bx--col bx--col-padding">
              <h2>SUBMIT</h2>
              <div className="bx--row bx--row-padding filterBlock ">
                <RequestCard
                  onClick={() =>
                    settoggle({
                      ...toggle,
                      Support: !toggle.Support,
                      tabselect: 0,
                    })
                  }
                  RequestIcon={<Headset32 />}
                  RequestTitle="Technical Service Request"
                />
                <RequestCard1
                  onClick={() =>
                    settoggle({
                      ...toggle,
                      Support: !toggle.Support,
                      tabselect: 0,
                    })
                  }
                  RequestIcon={<ShoppingCatalog32 />}
                  RequestTitle="Customer Service Request"
                />
              </div>
              <Slider {...settings}>
                <div className="bx--row bx--row-padding ">
                  <RequestCard
                    onClick={() =>
                      settoggle({
                        ...toggle,
                        Support: !toggle.Support,
                        tabselect: 0,
                      })
                    }
                    RequestIcon={<Headset32 />}
                    RequestTitle="Technical Service Request"
                  />
                </div>
                <div className="bx--row bx--row-padding ">
                  <RequestCard
                    onClick={() =>
                      settoggle({
                        ...toggle,
                        Support: !toggle.Support,
                        tabselect: 0,
                      })
                    }
                    RequestIcon={<ShoppingCatalog32 />}
                    RequestTitle="Customer Service Request"
                  />
                </div>
              </Slider>
            </div>
            <div className="bx--col">
              <h2>summary</h2>
              <div className="bx--row bx--row-padding ">
                <SummaryCard
                  SummaryIcon={<SendAlt32 />}
                  SummaryCat="Open"
                  SummaryCatCount={
                    Number(GlobalState.newCount) < 10
                      ? `0${GlobalState.newCount}`
                      : GlobalState.newCount
                  }
                />

                <SummaryCard
                  SummaryIcon={<Hourglass32 />}
                  SummaryCat="ASSIGNED"
                  SummaryCatCount={
                    Number(GlobalState.newCount) < 10
                      ? `0${GlobalState.newCount}`
                      : GlobalState.newCount
                  }
                />
                <SummaryCard
                  SummaryIcon={<InProgress32 />}
                  SummaryCat="IN PROGRESS"
                  SummaryCatCount={
                    Number(GlobalState.pendingCount) < 10
                      ? `0${GlobalState.pendingCount}`
                      : GlobalState.pendingCount
                  }
                />
                <SummaryCard
                  SummaryIcon={<Task32 />}
                  SummaryCat="CLOSED"
                  SummaryCatCount={
                    Number(GlobalState.closedCount) < 10
                      ? `0${GlobalState.closedCount}`
                      : GlobalState.closedCount
                  }
                />
              </div>
            </div>
            <div
              className="chat-bot-icon"
              onClick={() =>
                settoggle({
                  ...toggle,
                  Support: !toggle.Support,
                  tabselect: 1,
                })
              }
            >
              <Chat24 />
            </div>
            <div
              className="chat-bot-icon2"
              onClick={() =>
                settoggle({
                  ...toggle,
                  Support: !toggle.Support,
                  tabselect: 1,
                })
              }
            >
              <Chat24 />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ScHome;
