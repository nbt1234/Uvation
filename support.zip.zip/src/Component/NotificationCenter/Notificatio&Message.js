import React, { useContext, useEffect, useState } from "react";
import {
  ChevronRight20,
  Chat24,
  Settings16,
  User16,
  Purchase16,
  Catalog16,
} from "@carbon/icons-react";
import {
  DataTable,
  TableContainer,
  TableToolbar,
  TableToolbarContent,
  TableToolbarSearch,
  Table,
  TableHead,
  TableRow,
  TableSelectAll,
  TableHeader,
  TableBody,
  TableSelectRow,
  TableCell,
  Dropdown,
  Pagination,
  OverflowMenu,
  OverflowMenuItem,
} from "carbon-components-react";
import // msg_rowData,
// msg_headerData,
// userdropdwonitems,
"../Data/DataJson";
import { Link } from "react-router-dom";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import axios from "axios";
const NotificationCenter = () => {
  const {
    toggle,
    settoggle,
    account,
    MsAccessToken,
    setsiginlogs,
    setuserInfo,
    siginlogs,
    userInfo,
    systemnotificationuser,
    setsystemnotificationuser,
  } = useContext(GlobalContext);
  const [systemdata, setsystemdata] = useState("Siginlogs Info");
  const [isLoading, setIsLoading] = useState(false);
  const [ondata, setondata] = useState();

  const siginlogsData = siginlogs?.value;
  const totalItemrow = siginlogs?.totalItem;
  const systremdata = systemnotificationuser;
  const userdropdwonitems = [
    {
      id: "option-1",
      label: "System notification",
    },
    {
      id: "option-2",
      label: "Siginlogs Info",
    },
  ];
  const msg_headerData = [
    {
      header: "User Name",
      key: "userDisplayName",
    },
    {
      header: "Date and Time",
      key: "createdDateTime",
    },
    {
      header: "IP Address",
      key: "ipAddress",
    },
    {
      header: "Browser",
      key: "browser",
    },
    {
      header: "Operating System",
      key: "operatingSystem",
    },
  ];
  const msg_headerData5 = [
    {
      header: "Message",
      key: "message",
    },
  ];
  useEffect(() => {
    axios
      .post("https://notifications.uvation.com:443/api/show_notification", {
        userid: account?.idTokenClaims?.sub,
        platform: "uvation support",
      })
      .then((res) => {
        setsystemnotificationuser(res?.data?.data);
      });
  }, [account]);
  useEffect(() => {
    setIsLoading(true);

    const headers = new Headers();
    const bearer = `Bearer ${MsAccessToken?.data?.data?.access_token}`;
    headers.append("Authorization", bearer);
    var newData = {
      userid: userInfo?.userid,
      firstname: userInfo.fullname,
      lastname: userInfo.surname,
    };
    axios
      .post("https://appsapi.uvation.com:8080/identity/hello", newData)
      .then((res) => {
        setsiginlogs(res?.data?.data?.user_info);
        setIsLoading(false);
      });
  }, [userInfo]);
  return (
    <>
      <div className="bx--grid--full-width Notification">
        <div className="bx--grid bx--no-gutter notification-page">
          <div className="">
            <div className="bx--row bx--row-padding">
              <div className="bx--col notification-info">
                <h3>Welcome to</h3>
                <h1>
                  Notification & message
                  <span>
                    <ChevronRight20 />
                  </span>
                  <Link to="/">Home</Link>
                </h1>
              </div>
            </div>

            <div className="bx--row">
              {systemdata == "Siginlogs Info"
                ? siginlogsData &&
                  siginlogsData.length && (
                    <DataTable
                      isSortable
                      rows={siginlogsData}
                      headers={msg_headerData}
                      overflowMenuOnHover={false}
                      render={({
                        rows,
                        headers,
                        getHeaderProps,
                        getTableProps,
                        getToolbarProps,
                        onInputChange,
                        getRowProps,
                        getSelectionProps,
                      }) => (
                        <TableContainer>
                          <TableToolbar
                            {...getToolbarProps()}
                            aria-label="data table toolbar"
                          >
                            <TableToolbarContent>
                              <TableToolbarSearch
                                placeHolderText="Search Message"
                                onChange={onInputChange}
                                expanded
                              />
                            </TableToolbarContent>
                          </TableToolbar>

                          <TableToolbarContent>
                            <Dropdown
                              ariaLabel="Dropdown"
                              id="carbon-dropdown-example"
                              items={userdropdwonitems}
                              label="Signin logs Info"
                              titleText=""
                              value={ondata}
                              onChange={(e) => {
                                setsystemdata(e.selectedItem?.label);
                              }}
                            />

                            <Pagination
                              backwardText="Previous page"
                              forwardText="Next page"
                              itemsPerPageText="Items per page:"
                              page={1}
                              onChange={onInputChange}
                              pageNumberText="Page Number"
                              pageSize={10}
                              pageSizes={[10, 20, 30, 40, 50]}
                              totalItems={totalItemrow}
                            />
                          </TableToolbarContent>

                          <Table {...getTableProps()}>
                            <TableHead>
                              <TableRow>
                                <TableSelectAll {...getSelectionProps()} />
                                {headers.map((header, i) => (
                                  <TableHeader
                                    key={i}
                                    {...getHeaderProps({ header })}
                                  >
                                    {header.header}
                                  </TableHeader>
                                ))}
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {rows.map((row, i) => (
                                <TableRow
                                  key={i}
                                  {...getRowProps({
                                    row,
                                  })}
                                >
                                  <TableSelectRow
                                    {...getSelectionProps({ row })}
                                  />
                                  {row.cells.map((cell) => (
                                    <TableCell
                                      style={{ cursor: "pointer" }}
                                      // onClick={ToggleON}
                                      key={cell.id}
                                    >
                                      {cell.value}
                                    </TableCell>
                                  ))}
                                  <TableCell>
                                    <OverflowMenu flipped>
                                      <OverflowMenuItem>
                                        Action 1
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 2
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 3
                                      </OverflowMenuItem>
                                    </OverflowMenu>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      )}
                    />
                  )
                : systremdata &&
                  systremdata && (
                    <DataTable
                      isSortable
                      rows={systremdata}
                      headers={msg_headerData5}
                      overflowMenuOnHover={false}
                      render={({
                        rows,
                        headers,
                        getHeaderProps,
                        getTableProps,
                        getToolbarProps,
                        onInputChange,
                        getRowProps,
                        getSelectionProps,
                      }) => (
                        <TableContainer>
                          <TableToolbar
                            {...getToolbarProps()}
                            aria-label="data table toolbar"
                          >
                            <TableToolbarContent>
                              <TableToolbarSearch
                                placeHolderText="Search Message"
                                onChange={onInputChange}
                                expanded
                              />
                            </TableToolbarContent>
                          </TableToolbar>

                          <TableToolbarContent>
                            <Dropdown
                              ariaLabel="Dropdown"
                              id="carbon-dropdown-example"
                              items={userdropdwonitems}
                              label="Signin logs Info"
                              titleText=""
                              value={ondata}
                              onChange={(e) => {
                                setsystemdata(e.selectedItem?.label);
                              }}
                            />

                            <Pagination
                              backwardText="Previous page"
                              forwardText="Next page"
                              itemsPerPageText="Items per page:"
                              page={1}
                              onChange={onInputChange}
                              pageNumberText="Page Number"
                              pageSize={10}
                              pageSizes={[10, 20, 30, 40, 50]}
                              totalItems={totalItemrow}
                            />
                          </TableToolbarContent>

                          <Table {...getTableProps()}>
                            <TableHead>
                              <TableRow>
                                <TableSelectAll {...getSelectionProps()} />
                                {headers.map((header, i) => (
                                  <TableHeader
                                    key={i}
                                    {...getHeaderProps({ header })}
                                  >
                                    {header.header}
                                  </TableHeader>
                                ))}
                              </TableRow>
                            </TableHead>
                            <TableBody>
                              {rows.map((row, i) => (
                                <TableRow
                                  key={i}
                                  {...getRowProps({
                                    row,
                                  })}
                                >
                                  <TableSelectRow
                                    {...getSelectionProps({ row })}
                                  />
                                  {row.cells.map((cell) => (
                                    <TableCell
                                      style={{ cursor: "pointer" }}
                                      // onClick={ToggleON}
                                      key={cell.id}
                                    >
                                      {cell.value}
                                    </TableCell>
                                  ))}
                                  <TableCell>
                                    <OverflowMenu flipped>
                                      <OverflowMenuItem>
                                        Action 1
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 2
                                      </OverflowMenuItem>
                                      <OverflowMenuItem>
                                        Action 3
                                      </OverflowMenuItem>
                                    </OverflowMenu>
                                  </TableCell>
                                </TableRow>
                              ))}
                            </TableBody>
                          </Table>
                        </TableContainer>
                      )}
                    />
                  )}
              {/* {systremdata && ( */}
            </div>

            <div className="chat-bot-icon">
              <Chat24 />
            </div>
            <div className="chat-bot-icon2">
              <Chat24 />
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default NotificationCenter;
