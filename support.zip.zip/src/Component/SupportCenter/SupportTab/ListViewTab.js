import React, { useContext, useState } from 'react';
import {
  Pagination,
  DataTable,
  TableContainer,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  TableToolbarContent,
  TableToolbarSearch,
  TableToolbar,
} from 'carbon-components-react';
import { Link } from 'react-router-dom';
import { Launch16, LetterUu16 } from '@carbon/icons-react';
import { ticheaders } from '../../Data/DataJson';
import { GlobalContext } from '../../../ContextApi/GlobalContext';

export const SerchData = ({ onChange }) => (
  <TableToolbarSearch
    searchContainerClass='listMode'
    placeHolderText='Search ticket by keyword or ID'
    onChange={onChange}
  />
);

const ListViewTab = () => {
  const {
    toggle,
    settoggle,
    GlobalState,
    setGlobalState,
    Alldata,
    AlldataWidget,
    TablePagination,
    setTablePagination,
    Fillter,
    setFillter,
 } = useContext(GlobalContext);

  return (
    <div className='bx--grid--full-width'>
      <div className='bx--row'>
        <div className='ListData'>
          <DataTable
            rows={Alldata}
            headers={ticheaders}
            overflowMenuOnHover={false}
            //stickyHeader={true}
          >
            {({
              rows,
              headers,
              getHeaderProps,
              getTableProps,
              getRowProps,
              onInputChange,
            }) => (
              <TableContainer>
                <TableToolbarContent>
                  <Pagination
                    backwardText='Previous page'
                    forwardText='Next page'
                    itemsPerPageText='Items per page:'
                    page={Pagination.page}
                    pageNumberText='Page Number'
                    pageSize={Pagination.per_page}
                    pageSizes={[10, 15, 20, 30, 40, 50]}
                    totalItems={TablePagination.totalrow}
                    onChange={({ page, pageSize }) => {
                      if (
                        pageSize !== Pagination.per_page ||
                        page !== Pagination.page
                      ) {
                        setTablePagination({
                          ...TablePagination,
                          per_page: pageSize,
                          page: page,
                        });
                      }
                    }}
                  />
                  {/* <SerchData onChange={onInputChange} /> */}
                </TableToolbarContent>

                <Table {...getTableProps()} size='normal' stickyHeader>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => (
                        <TableHeader
                          key={header.key}
                          {...getHeaderProps({
                            header,
                          })}
                        >
                          {header.header}
                        </TableHeader>
                      ))}
                      <TableHeader />
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow
                        key={row.id}
                        {...getRowProps({
                          row,
                        })}
                      >
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                        <TableCell className='bx--table-column-menu'>
                          <div className='align-openticket'>
                            <Link
                              to={`/support/ticketdetail/`+row.id}
                              onClick={() =>
                                localStorage.setItem('ticidstore', row.id)
                              }
                            >
                              <p>Open ticket</p>
                            </Link>
                            <Launch16 />
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
        </div>
        <div className='mobTable'>
          <DataTable rows={Alldata} headers={headerData} size='tall'>
            {({
              rows,
              headers,
              getHeaderProps,
              getRowProps,
              getTableProps,
              onInputChange,
            }) => (
              <TableContainer>
                <TableToolbar>
                  <TableToolbarContent>
                    {/* pass in `onInputChange` change here to make filtering work */}
                    <TableToolbarSearch onChange={onInputChange} expanded />
                  </TableToolbarContent>
                </TableToolbar>
                <Table {...getTableProps()}>
                  <TableHead>
                    <TableRow>
                      {headers.map((header) => (
                        <TableHeader
                          key={header.key}
                          {...getHeaderProps({ header })}
                        >
                          {header.header}
                        </TableHeader>
                      ))}
                      <TableHeader />
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {rows.map((row) => (
                      <TableRow key={row.id} {...getRowProps({ row })}>
                        {row.cells.map((cell) => (
                          <TableCell key={cell.id}>{cell.value}</TableCell>
                        ))}
                        <TableCell>
                          <Link
                           to={`/support/ticketdetail/`+ row.id}
                            onClick={() =>
                              localStorage.setItem('ticidstore', row.id)
                            }
                          >
                            <Launch16 />
                          </Link>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </DataTable>
        </div>
      </div>
    </div>
  );
};

export default ListViewTab;
const headerData = [
  {
    header: 'Ticket #',
    key: 'id',
  },
  {
    header: 'Date created/Subject',
    key: 'datesubject',
  },
];
