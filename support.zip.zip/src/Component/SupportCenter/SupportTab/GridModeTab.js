import React, { useContext } from 'react';
import { ArrowLeft16 } from '@carbon/icons-react';
import { GlobalContext } from '../../../ContextApi/GlobalContext';

const GridModeTab = () => {
  const { toggle, settoggle, GlobalState, setGlobalState } = useContext(
    GlobalContext
  );


  return (
    <div className='bx--grid--full-width'>
      <div className='bx--row'>
        <div
          className='bx--col-lg-4 bx--col-md-4 bx--col-sm-4 border--right'
          style={{ display: toggle.openShow ? 'none' : '' }}
        >
          <div className='support-col-title'>
            <h2>Open ({GlobalState.newCount})</h2>
            <span className='align-icon'>
              |<ArrowLeft16 />
            </span>
          </div>
          <div className='GridTicket'>{GlobalState.fetchnew}</div>
          {/* <div>{props.OpenData}</div> */}
        </div>

        <div
          className='bx--col-lg-4 bx--col-md-4 bx--col-sm-4 border--right'
          style={{ display: toggle.newShow ? 'none' : '' }}
        >
          <div className='support-col-title'>
            <h2>Assigned ({GlobalState.newCount})</h2>
            <span className='align-icon'>
              |<ArrowLeft16 />
            </span>
          </div>
          <div className='GridTicket'>{GlobalState.fetchnew}</div>
          {/* <div>{props.NewData}</div> */}
        </div>
        <div
          className='bx--col-lg-4 bx--col-md-4 bx--col-sm-4 border--right'
          style={{
            display: toggle.pendingShow ? 'none' : '',
          }}
        >
          <div className='support-col-title'>
            <h2>In progress ({GlobalState.pendingCount})</h2>
            <span className='align-icon'>
              |<ArrowLeft16 />
            </span>
          </div>
          <div className='GridTicket'>{GlobalState.fetchpending}</div>
          {/* <div>{props.PendingData}</div> */}
        </div>
        <div
          className='bx--col-lg-4 bx--col-md-4 bx--col-sm-4 border--right'
          style={{
            display: toggle.closedShow ? 'none' : '',
          }}
        >
          <div className='support-col-title'>
            <h2>Closed ({GlobalState.closedCount})</h2>
            <span className='align-icon'>
              |<ArrowLeft16 />
            </span>
          </div>
          <div className='GridTicket'>{GlobalState.fetchclosed}</div>
          {/* <div>{props.CloseData}</div> */}
        </div>
      </div>
    </div>
  );
};

export default GridModeTab;
