import React, { useContext, useState } from "react";
import {
  Button,
  Header,
  HeaderGlobalAction,
  HeaderGlobalBar,
  HeaderName,
  HeaderPanel,
} from "carbon-components-react";
import UvationLogo25 from "../../assets/UvationLogo/logo.png";
import {
  Notification20,
  Settings20,
  User20,
  User32,
  Logout20,
  Close20,
  Headset20,
  Switcher20,
  Home20,
  ChevronDown20,
} from "@carbon/icons-react";
import QuickSetting from "./HeaderPanel/QuickSetting";
import SupportHelp from "./HeaderPanel/SupportHelp";
import Notification from "./HeaderPanel/Notification";
import { Link } from "react-router-dom";
import { GlobalContext } from "../../ContextApi/GlobalContext";
import proimg from "../../assets/UvationLogo/profile.png";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
  useMsal,
  useIsAuthenticated,
} from "@azure/msal-react";
import { msalConfig } from "../../authConfig";

const ScHeader = () => {
  const { instance, inProgress, accounts } = useMsal();
  const {
    helloData,
    toggle,
    settoggle,
    userInfo,
    photo,
    notificationuser,
    setphoto,
    socketdata,
    base64Prefix,
  } = useContext(GlobalContext);
  const [account, setAccount] = useState(false);
  const [home, setHome] = useState(true);

  const ShowLogout = () => {
    setAccount(!account);
    setHome(false);
  };

  function QuickOpen() {
    settoggle({
      ...toggle,
      Quick: !toggle.Quick,
      Support: false,
      Notification: false,
      Account: false,
      switcher: false,
      viewSummary: false,
    });
  }
  function SupportOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: !toggle.Support,
      Notification: false,
      Account: false,
      tabselect: 0,
      switcher: false,
      viewSummary: false,
    });
  }
  function NotificationOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: false,
      Notification: !toggle.Notification,
      Account: false,
      switcher: false,
      viewSummary: false,
    });
  }
  function AcconutOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: false,
      Notification: false,
      Account: !toggle.Account,
      swicher: false,
      viewSummary: false,
    });
  }
  function SwitcherOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: false,
      Notification: false,
      Account: false,
      switcher: !toggle.switcher,
      viewSummary: false,
    });
  }
  //   const url = new URL(AadEndSessionEndpoint);
  // url.searchParams.append('post_logout_redirect_uri', SPAUrl);
  // function signOutClickHandler(instance) {
  //   const logoutRequest = {
  //     account: instance.getAccountByHomeId(account?.homeAccountId),
  //     mainWindowRedirectUri: "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/b2c_1a_demo1_progressive_profiling_signup_signin/oauth2/v2.0/authorize?client_id=70047577-a5d1-4487-b960-8d3abbf2d5e0&scope=openid%20profile%20offline_access%20https%3A%2F%2Fuvationidp.onmicrosoft.com%2Ftasks-api%2Ftasks.write&redirect_uri=https%3A%2F%2Fidentity.uvation.com&client-request-id=e8ff05bf-9120-461a-95c2-cf1fe94547ab&response_mode=fragment&response_type=code&x-client-SKU=msal.js.browser&x-client-VER=2.28.0&client_info=1&code_challenge=F9K8SiguxVMvWRLDcztm7sUtujik0qdNVKpAnt9RMNQ&code_challenge_method=S256&nonce=cbc2ea9e-e44e-4bab-acf9-a4091d9bab2c&state=eyJpZCI6IjFiYmViYWJjLTM2NjctNDM1Ni1hMDA4LWQ5NmQyMDUwOGU5YyIsIm1ldGEiOnsiaW50ZXJhY3Rpb25UeXBlIjoicmVkaXJlY3QifX0%3D",
  //     postLogoutRedirectUri: "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/b2c_1a_demo1_progressive_profiling_signup_signin/oauth2/v2.0/authorize?client_id=70047577-a5d1-4487-b960-8d3abbf2d5e0&scope=openid%20profile%20offline_access%20https%3A%2F%2Fuvationidp.onmicrosoft.com%2Ftasks-api%2Ftasks.write&redirect_uri=https%3A%2F%2Fidentity.uvation.com&client-request-id=e8ff05bf-9120-461a-95c2-cf1fe94547ab&response_mode=fragment&response_type=code&x-client-SKU=msal.js.browser&x-client-VER=2.28.0&client_info=1&code_challenge=F9K8SiguxVMvWRLDcztm7sUtujik0qdNVKpAnt9RMNQ&code_challenge_method=S256&nonce=cbc2ea9e-e44e-4bab-acf9-a4091d9bab2c&state=eyJpZCI6IjFiYmViYWJjLTM2NjctNDM1Ni1hMDA4LWQ5NmQyMDUwOGU5YyIsIm1ldGEiOnsiaW50ZXJhY3Rpb25UeXBlIjoicmVkaXJlY3QifX0%3D",
  //   };
  //   instance.logoutRedirect(logoutRequest);
  // }
  return (
    <>
      <div className="SC_header">
        <Header aria-label="IBM Platform Name">
          <div className="header">
            <div className="logo">
              <Link to="/">
                <img src={UvationLogo25} alt="" />
                <p>Support Center</p>
              </Link>
            </div>
          </div>

          {/* <div className='header'>
            <div className='logo'>
              <Link to='/'>
                <img src={UvationLogo25} alt='' />
                <p>Uvation Support Center</p>
              </Link>
            </div>
          </div> */}
          <HeaderGlobalBar>
            <div className="user-account">
              {userInfo.fullname} {userInfo.surname}'s Account
            </div>
            <HeaderGlobalAction
              isActive={toggle.Quick}
              aria-label="Settings"
              onClick={QuickOpen}
            >
              <Settings20 />
            </HeaderGlobalAction>
            <HeaderGlobalAction
              isActive={toggle.Support}
              aria-label="Support"
              onClick={SupportOpen}
            >
              <Headset20 />
            </HeaderGlobalAction>

            <HeaderGlobalAction
              aria-label="Coming Soon"
              isActive={toggle.Notification}
              onClick={NotificationOpen}
            >
              <Notification20 />
              {notificationuser?.length && (
                <span className="notification_count">
                  {notificationuser?.length}
                </span>
              )}
            </HeaderGlobalAction>

            <div className="tooltip_switcherbtn">
              <HeaderGlobalAction
                aria-label="User Account"
                isActive={toggle.Account}
                onClick={AcconutOpen}
              >
                <User20 />
              </HeaderGlobalAction>
            </div>
          </HeaderGlobalBar>
        </Header>

        <div className="Account-notificaton-panel-width">
          <HeaderPanel
            aria-label="Notification"
            aria-labelledby="Notification"
            className="notification-header-panel"
            expanded={toggle.Notification}
          >
            <div
              className="close"
              onClick={() => settoggle({ Notification: !toggle.Notification })}
            ></div>
            <Notification />
          </HeaderPanel>

          <HeaderPanel
            className="account-header-panel"
            aria-label="Account-panel"
            aria-labelledby="Account-panel"
            expanded={toggle.Account}
          >
            <div
              className="close"
              onClick={() => settoggle({ Account: !toggle.Account })}
            ></div>
            <div className="account-panel">
              <div className="user-info-panel">
                <div className="bx--row ">
                  <div className="in-flex-all">
                    <div>
                      <h2>
                        {userInfo.fullname} {userInfo.surname}
                      </h2>
                      <p>{userInfo.email}</p>
                    </div>

                    <div className="panel-circle48">
                      <div className="user_img">
                        <img
                          src={
                            photo?.data?.base64
                              ? `${base64Prefix}${photo?.data?.base64}`
                              : proimg
                          }
                          className="user-photo"
                        />
                      </div>
                    </div>
                  </div>
                </div>
                <ul>
                  <Link
                    to=""
                    onClick={() => {
                      window.open(
                        "https://identity.uvation.com/account/info",
                        "_blank"
                      );
                    }}
                  >
                    <li>My Account</li>
                  </Link>
                  {/* <Link to='/account/privacy'>
                        <li>Settings</li>
                      </Link> */}
                </ul>
              </div>

              <div className="butn-footer">
                <Button
                  className="butn-width"
                  kind="secondary"
                  renderIcon={Logout20}
                  onClick={() => {
                    socketdata.emit("logout", {
                      userid: userInfo?.userid,
                      time: new Date(),
                    });
                    localStorage.clear();
                    sessionStorage.clear();
                    instance.logoutRedirect(
                      msalConfig.auth.postLogoutRedirectUri
                    );
                  }}
                >
                  Log Out
                </Button>
              </div>
            </div>
          </HeaderPanel>
        </div>

        <div className="HomeHeader-Panel">
          <HeaderPanel aria-label="Header Panel" expanded={toggle.Quick}>
            <div
              onClick={() => settoggle({ Quick: !toggle.Quick })}
              className="close-overlay"
            ></div>
            <div className="Quick-support-panel">
              <div className="QuickSetting">
                <div className="quick-title">
                  <h4>Quick Setting</h4>
                  <Close20
                    className="close-icon-color"
                    onClick={() => settoggle({ Quick: !toggle.Quick })}
                  />
                </div>
                <QuickSetting />
              </div>
            </div>
          </HeaderPanel>

          <HeaderPanel aria-label="Header Panel" expanded={toggle.Support}>
            <div onClick={SupportOpen} className="close-overlay"></div>
            <div className=" Quick-support-panel">
              <div className="SupportHelp">
                <div className="support-title">
                  <h4>Support & Help</h4>
                  <Close20 className="close-icon-color" onClick={SupportOpen} />
                </div>
                <SupportHelp selectvalue={toggle.tabselect} />
              </div>
            </div>
          </HeaderPanel>

          <div>
            <HeaderPanel
              aria-label="Switcher"
              expanded={toggle.switcher}
              className="mobSwitcher"
            >
              <div onClick={SwitcherOpen} className="close-overlay"></div>
              <div className="mob-switcher">
                <div className="switcher-Content">
                  <ul>
                    <Link to="/">
                      <li
                        onClick={() =>
                          settoggle({
                            ...toggle,
                            Quick: false,
                            Support: false,
                            Notification: false,
                            Account: false,
                            switcher: false,
                          })
                        }
                        className={home ? "active" : ""}
                      >
                        <Home20 /> <span>Home</span>
                      </li>
                    </Link>
                    <li onClick={() => settoggle({ Quick: !toggle.Quick })}>
                      <Settings20 /> <span> Setting </span>
                    </li>

                    <div
                      style={{ position: "relative" }}
                      onClick={ShowLogout}
                      onMouseLeave={() => (setAccount(!account), setHome(true))}
                    >
                      <User20 /> <span> My Account</span>
                      <ChevronDown20
                        className="arow"
                        style={{ float: "right" }}
                      />
                      {account ? (
                        <div
                          style={{
                            position: "absolute",
                            top: "2.5rem ",
                            left: "2.3rem",
                          }}
                          className="logout"
                          onClick={() => {
                            document.cookie
                              .split(";")
                              .forEach(
                                (cookie) =>
                                  (document.cookie = cookie
                                    .replace(/^ +/, "")
                                    .replace(
                                      /=.*/,
                                      `=;expires=${new Date(
                                        0
                                      ).toUTCString()};path=/`
                                    ))
                              );
                            sessionStorage.clear();
                            instance.logoutRedirect(
                              msalConfig.auth.postLogoutRedirectUri
                            );
                          }}
                        >
                          Logout
                        </div>
                      ) : null}
                    </div>
                  </ul>
                </div>
              </div>
            </HeaderPanel>
          </div>
        </div>
      </div>
      <div
        className="SC_header mobHeader
      "
      >
        <Header aria-label="IBM Platform Name">
          <div className="header">
            <div className="logo">
              <Link to="/">
                <img src={UvationLogo25} alt="" />
                <p>Uvation Support Center</p>
              </Link>
            </div>
          </div>
          <HeaderGlobalBar>
            <HeaderGlobalAction
              isActive={toggle.Support}
              aria-label="Headset"
              onClick={SupportOpen}
            >
              <Headset20 />
            </HeaderGlobalAction>

            <HeaderGlobalAction
              aria-label="Notifications"
              isActive={toggle.Notification}
              onClick={NotificationOpen}
            >
              <Notification20 />
              {notificationuser?.length && (
                <span className="notification_count">
                  {notificationuser?.length}
                </span>
              )}
            </HeaderGlobalAction>

            <HeaderGlobalAction
              aria-label="Switcher"
              isActive={toggle.switcher}
              onClick={SwitcherOpen}
            >
              <Switcher20 />
            </HeaderGlobalAction>
          </HeaderGlobalBar>
        </Header>
      </div>
    </>
  );
};

export default ScHeader;
