import React, { useState, useContext, useEffect } from "react";
import axios from "axios";
import {
  Tabs,
  Tab,
  FormGroup,
  TextInput,
  TextArea,
  Dropdown,
  RadioButtonGroup,
  RadioButton,
  Pagination,
  Button,
  FileUploaderButton,
  ContentSwitcher,
  Switch,
  Loading,
  DatePicker,
  DatePickerInput,
  TimePicker,
  ProgressStep,
  ProgressIndicator,
  Table,
  TableHead,
  TableRow,
  TableHeader,
  TableBody,
  TableCell,
  TableToolbarSearch,
  ButtonSet,
  DataTable,
  TableContainer,
  TableToolbar,
  TableToolbarContent,
  FileUploader,
  FileUploaderItem,
} from "carbon-components-react";
import {
  Help24,
  Chat24,
  Headset24,
  RequestQuote24,
  Launch16,
  Phone32,
  MobileAudio32,
} from "@carbon/icons-react";
import timezonesJson from "timezones.json";
import moment from "moment";
import { countrycode, SeverityList, ServiceList } from "../../Data/DataJson";
import { GlobalContext } from "../../../ContextApi/GlobalContext";
import Widget from "../../Chat-btn/Widget";
import { Link, useHistory } from "react-router-dom";
// import { Dialogue } from '@carbon/pictograms';
// import Page from 'twilio/lib/base/Page';

const SupportHelp = () => {
  const {
    toggle,
    settoggle,
    userInfo,
    GlobalState,
    setGlobalState,
    Alldata,
    AlldataWidget,
    TablePagination,
    setTablePagination,
    Fillter,
    setFillter,
    photo,
    setloadingnotification,
    setphoto,
    ticket_id,
    setticket_id,
  } = useContext(GlobalContext);
  const usernameinfo = "zendesk_admin@uvation.com";
  const passwordinfo = "H9dh0DH72gF";
  const history = useHistory();
  const [datavalue, setdatavalue] = useState();
  const usernotification_token = localStorage.getItem("notification_token");

  const [Data, setData] = useState({
    loading: "",
    loadingCall: false,
    Subject: "",
    Description: "",
    switchValue: "",
    phone: "",
    postalCode: "+1",
    chooseService: "",
    servity: "",
    conframEmail: "",
    contactMethod: "",
    timeZone: "",
    ScheduleDate: "",
    ScheduleTime: "",
    attachFile: "",
    call: "",
  });
  const [attachmentToken, setattachmentToken] = useState("");

  const [resdata, setresdata] = useState([
    {
      id: "",
      timezone: "",
      status: "",
    },
  ]);

  const handleChange = (e) => {
    const value = e.target.value;
    setData({
      ...Data,
      [e.target.name]: value,
    });
  };

  const makeCall = async (e) => {
    e.preventDefault();
    setData({ ...Data, loadingCall: true });
    const token = Buffer.from(
      `${process.env.REACT_APP_ACCOUNT_SID}:${process.env.REACT_APP_AUTH_TOKEN}`,
      "utf8"
    ).toString("base64");

    const fd = new FormData();
    fd.append("From", process.env.REACT_APP_TWILIO_PHONE_NUMBER);
    fd.append("To", `${Data.postalCode + Data.call}`);
    fd.append("Url", "http://demo.twilio.com/docs/voice.xml");

    const call = await axios.post(
      `https://appsapi.uvation.com:8080/identity/support_call`,
      fd,
      {
        headers: {
          "Content-Type": "",
          authorization: `Basic ${token}`,
        },
      }
    );
  };
  function attachmentFile(e) {
    if (e) {
      const file = e.target.files[0];
      axios
        .post(
          `https://uvation.zendesk.com/api/v2/uploads?filename=${file.name}`,
          file,
          {
            headers: {
              Authorization: "Basic " + btoa(`${usernameinfo}:${passwordinfo}`),
              "Content-Type": "application/binary",
            },
          }
        )
        .then((res) => {
          setattachmentToken(res.data.upload.token);
        })

        .catch((err) => console.log(err));
    }
  }

  const handleSubmit = async (e) => {
    e.preventDefault();

    setData({
      ...Data,
      loading: true,
    });
    const body = {
      ticket: {
        subject: Data.Subject,
        comment: { body: Data.Description, uploads: [`${attachmentToken}`] },
        requester: {
          name: userInfo.fullname,
          email: userInfo.email,
        },
        custom_fields: [
          // {
          //   id: 360019118233,
          //   value: "nbt1",
          // },
          {
            id: 360007343594,
            value: userInfo.fullname,
          },
          {
            id: 360029033513,
            value: Data.ScheduleTime,
          },
          {
            id: 360007135793,
            value: Data.postalCode + Data.phone,
          },
          {
            id: 360007135813,
            value: Data.chooseService,
          },
          {
            id: 360029045834,
            value: Data.timeZone,
          },
          {
            id: 360028569473,
            value: Data.contactMethod,
          },
          {
            id: 360029045634,
            value: Data.ScheduleDate,
          },
          {
            id: 360028555173,
            value: Data.servity,
          },
          {
            id: 360029033673,
            value: userInfo.email,
          },
        ],
        ticket_form_id: Data.switchValue,
      },
    };
    const bodydata1 = new FormData();
    bodydata1.append("body", JSON.stringify(body));
    const postres = await axios.post(
      "https://appsapi.uvation.com:8080/identity/create_ticket",
      bodydata1
    );

    if (postres?.statusText == "OK") {
      axios
        .post("https://notifications.uvation.com:443/api/action_notification", {
          userid: userInfo.userid,
          zendesk_id: postres?.data?.audit?.ticket_id,

          zendesk_id_time: postres?.data?.audit?.created_at,
          platform: "uvation support",
          token: usernotification_token,
        })
        .then((res) => {
          setloadingnotification(true);
        });
    }
    const data = postres.data.ticket;
    setresdata({
      id: postres.data.ticket.id,
      timezone: postres.data.ticket.created_at,
      status: postres.data.ticket.status,
    });
    setData({
      ...Data,
      loading: false,
    });
  };
  const userticketparsing = (row) => {
    history.push(`/support/ticketdetail/${row.id}`);
  };

  return (
    <>
      <div className="divfortabs">
        <Tabs className="tabs-div" selected={toggle.tabselect}>
          <Tab className="tab-div" href="#" id="tab-1" label={<Help24 />}>
            {Data.loading === false ? (
              <div>
                <div className="submit-ticket">
                  <h2>Service request #{resdata.id}</h2>
                  <div className="ticStatus">
                    <h5>{Data.Subject}</h5>
                    <p>open</p>
                  </div>

                  <p className="p_design">
                    Created by {userInfo.fullname} on
                    {moment(resdata.timeZone).format("LLLL")}
                  </p>
                  <div className="bx--col bx--no-gutter">
                    <ProgressIndicator
                      vertical
                      currentIndex={
                        resdata.status === "open"
                          ? 1
                          : 0 || resdata.status === "pending"
                          ? 2
                          : 0 || resdata.status === "closed"
                          ? 4
                          : 0
                      }
                    >
                      <ProgressStep
                        label="Service request opened"
                        description="Step 1: Getting started with Carbon Design System"
                        secondaryLabel={moment(resdata.timeZone).format("LLLL")}
                      />
                      <ProgressStep
                        label="Agent assigned"
                        description="Step 3: Getting started with Carbon Design System"
                      />
                      <ProgressStep
                        label="Issue resolved"
                        description="Step 4: Getting started with Carbon Design System"
                      />
                    </ProgressIndicator>
                  </div>

                  <div className="details">
                    <div className="line"></div>
                    <h5>Services request details</h5>
                    <div className="detail-item ">
                      <li>
                        <p>Name</p>
                      </li>
                      <li>
                        <p>{userInfo.fullname}</p>
                      </li>
                    </div>
                    <div className="detail-item ">
                      <li>
                        <p>Phone</p>
                      </li>
                      <li>
                        <p>{Data.postalCode + Data.phone}</p>
                      </li>
                    </div>

                    <div className="detail-item ">
                      <li>
                        <p>Email</p>
                      </li>
                      <li>
                        <p>{userInfo.email}</p>
                      </li>
                    </div>
                    <div className="detail-item ">
                      <li>
                        <p>Service</p>
                      </li>
                      <li>
                        <p>{Data.chooseService}</p>
                      </li>
                    </div>
                    <div className="detail-item ">
                      <li>
                        <p>Severity</p>
                      </li>
                      <li>
                        <p>{Data.servity}</p>
                      </li>
                    </div>
                    <div className="detail-item ">
                      <li>
                        <p>Timezone</p>
                      </li>
                      <li>
                        <p>{Data.timeZone}</p>
                      </li>
                    </div>
                    <ButtonSet stacked>
                      <Button
                        // target="_blank"
                        kind="primary"
                        as={Link}
                        to={`/support/ticketdetail/` + resdata.id}
                        onClick={() => {
                          setticket_id(resdata.id);
                          settoggle({
                            ...toggle,
                            Quick: false,
                            Support: !toggle.Support,
                            Notification: false,
                            Account: false,
                            tabselect: 0,
                            switcher: false,
                            viewSummary: false,
                          });
                          // localStorage.setItem('ticidstore', resdata.id);
                        }}
                      >
                        View case page
                      </Button>
                      <Button
                        kind="tertiary"
                        onClick={() => setData({ loading: null })}
                      >
                        Open new ticket
                      </Button>
                    </ButtonSet>
                  </div>
                </div>
              </div>
            ) : Data.loading === true ? (
              <div className="box-block">
                <Loading
                  withOverlay={false}
                  small
                  style={{ width: "100px", height: "100px" }}
                />
              </div>
            ) : (
              <div className="support-tab-content">
                <div className="bx--telephone">
                  <h2>Open new ticket</h2>
                  <FormGroup legendText="">
                    <div className="Switcher">
                      {/* <ContentSwitcher   selectionMode="manual"   onChange={(obj) => {
    let { index, name, text, value } = obj;
    alert(`index: ${index} ||  name: ${name} || text: ${text} || value:${value}`);
  }} value="tech"> */}
                      <ContentSwitcher
                        selectionMode="manual"
                        onChange={(obj) => {
                          let { index, name, text, value } = obj;
                          setData({
                            ...Data,
                            switchValue: `${name}`,
                          });
                        }}
                      >
                        <Switch
                          name="360001970193"
                          text="Technical Request"
                          value="tech"
                        />
                        <Switch name="1500000007241" text="Customer Request" />
                      </ContentSwitcher>
                    </div>

                    <div className="spacing-inner">
                      <TextInput
                        id="test1"
                        invalidText="A valid value is required"
                        required
                        labelText="Subject*"
                        placeholder="Add a subject"
                        name="Subject"
                        onChange={handleChange}
                      />
                    </div>
                    <div className="spacing-inner">
                      <TextArea
                        cols={50}
                        id="test14"
                        invalidText="A valid value is required"
                        labelText="Description*"
                        placeholder="Describe your issue in detail"
                        rows={4}
                        name="Description"
                        onChange={handleChange}
                      />
                    </div>
                    <div className="spacing-inner">
                      <div
                        className="bx--row"
                        style={{ alignItems: "flex-end" }}
                      >
                        <div className="bx--col-1 bx--no-gutter">
                          <Dropdown
                            label="+ 91 "
                            ariaLabel="Dropdown"
                            id="carbon-dropdown-example"
                            value="+1"
                            items={countrycode}
                            itemToElement={(countrycode) =>
                              countrycode ? (
                                <>
                                  <span style={{ marginRight: "0.5rem" }}>
                                    {countrycode.dial_code}
                                  </span>
                                  <span>{countrycode.code}</span>
                                </>
                              ) : (
                                ""
                              )
                            }
                            titleText="Telephone*"
                            selectedItem={Data.postalCode}
                            onChange={({ selectedItem }) =>
                              setData({
                                ...Data,
                                postalCode: selectedItem.dial_code,
                              })
                            }
                          />
                        </div>
                        <div className="bx--col bx--no-gutter">
                          <TextInput
                            labelText=""
                            id="test3"
                            invalidText="A valid value is required"
                            placeholder="Enter your telephone number"
                            name="phone"
                            onChange={handleChange}
                          />
                        </div>
                      </div>
                    </div>

                    <div className="form-divider"></div>

                    <h2>Choose options</h2>

                    <div className="spacing-inner">
                      <Dropdown
                        id="drop-1"
                        ariaLabel="Dropdown"
                        items={ServiceList}
                        label="Choose a service...."
                        titleText="Choose service"
                        selectedItem={Data.chooseService}
                        onChange={({ selectedItem }) =>
                          setData({
                            ...Data,
                            chooseService: selectedItem.label,
                          })
                        }
                      />
                    </div>
                    <div className="spacing-inner">
                      <Dropdown
                        id="drop-2"
                        ariaLabel="Dropdown"
                        items={SeverityList}
                        label="Select a severity...."
                        titleText="Severity"
                        selectedItem={Data.servity}
                        onChange={({ selectedItem }) =>
                          setData({ ...Data, servity: selectedItem.label })
                        }
                      />
                    </div>
                    <div className="spacing-inner">
                      <TextInput
                        labelText={
                          <>
                            <legend>Confirm your email*</legend>
                            <legend style={{ fontSize: "11px" }}>
                              (use semicolons to separate multiple email
                              addresses)
                            </legend>
                          </>
                        }
                        id="test16"
                        invalidText="A valid value is required"
                        required
                        value={userInfo.email}
                        placeholder="serbantudorvlad@gmail.com"
                        name="conframEmail"
                        onChange={handleChange}
                      />
                    </div>

                    <FormGroup legendText="Prefered contact method:">
                      <RadioButtonGroup
                        className="radio_btn"
                        orientation="vertical"
                        labelPosition="right"
                        legend="Group Legend"
                        name="radio-button-group"
                        valueSelected={Data.contactMethod}
                        onChange={(valueSelected) =>
                          setData({ ...Data, contactMethod: valueSelected })
                        }
                      >
                        <RadioButton
                          id="radio-1"
                          labelText="Phone"
                          value="Phone"
                        />
                        <RadioButton
                          id="radio-2"
                          labelText="Email"
                          value="Email"
                        />
                        <RadioButton
                          id="radio-3"
                          labelText="Schedule a call"
                          value="Callback"
                        />
                      </RadioButtonGroup>
                    </FormGroup>
                    <div
                      className="DateTimepicker"
                      style={{
                        display:
                          Data.contactMethod === "Callback" ? "" : "none",
                      }}
                    >
                      <DatePicker
                        dateFormat="m/d/Y"
                        datePickerType="single"
                        id="date-picker"
                        locale="en"
                        short={true}
                      >
                        <DatePickerInput
                          className="some-class"
                          iconDescription="Date Calendar icon"
                          id="date-picker-input"
                          invalid={false}
                          invalidText="A valid due date is required"
                          labelText=""
                          pattern="\d{1,2}/\d{1,2}/\d{4}"
                          placeholder="mm/dd/yyyy"
                          type="date"
                          name="ScheduleDate"
                          value={Data.ScheduleDate}
                          valueSelected={Data.ScheduleDate}
                          onInput={(e) =>
                            setData({
                              ...Data,
                              ScheduleDate: e.target.value,
                            })
                          }
                        ></DatePickerInput>
                      </DatePicker>
                      <TimePicker
                        labelText=""
                        id="time-picker"
                        placeholder="HH:MM"
                        type="time"
                        name="ScheduleTime"
                        onChange={handleChange}
                      />
                    </div>
                    <div className="spacing-inner">
                      <Dropdown
                        ariaLabel="Dropdown"
                        label="Select a time zone"
                        id="drop-3"
                        items={timezonesJson}
                        itemToElement={(timezonesJson) =>
                          timezonesJson ? timezonesJson.text : ""
                        }
                        titleText="Choose a new time zone"
                        selectedItem={Data.timeZone}
                        onChange={({ selectedItem }) =>
                          setData({ ...Data, timeZone: selectedItem.text })
                        }
                      />
                    </div>
                  </FormGroup>

                  <div className="form-divider"></div>
                  <div className="div-row-center spacing-inner-second">
                    <div className="bx--col bx--no-gutter--left">
                      <h3>Attach files</h3>
                      <p>Files must be less than 5MB in size.</p>
                    </div>
                    <div className="bx--col bx--no-gutter">
                      <FileUploader
                        labelText="Attach File"
                        id="file-01"
                        buttonLabel="Attach File"
                        accept={[".jpg", ".png", ".jpeg"]}
                        buttonKind="tertiary"
                        size="field"
                        role="button"
                        disableLabelChanges={true}
                        filenameStatus={
                          attachmentToken !== "" ? "complete" : `uploading`
                        }
                        onChange={(e) => attachmentFile(e)}
                      />
                    </div>
                  </div>
                </div>
                <div style={{ marginTop: "4.5rem" }}>
                  <Button
                    className="btnwidth"
                    onClick={handleSubmit}
                    kind="primary"
                  >
                    Submit request
                  </Button>
                </div>
              </div>
            )}
          </Tab>
          <Tab className="tab-div" href="#" id="tab-2" label={<Chat24 />}>
            <div className="support-tab-content">
              <div className="bx--telephone">
                <h2>Chat with an agent</h2>
                <p>
                  Our Support staff is available 24/7/365 to assist you via chat
                  with any services related questions.
                </p>
                <div className="box-block">
                  <div className="column">
                    {/* <div className='circle74'>
                    <Chat24 />
                  </div> */}
                  </div>
                </div>
              </div>
              <Widget />
              <div className="btn-down">
                {/* <Button className="btnwidth" kind="primary">
                Start Chat
              </Button> */}
              </div>
            </div>
          </Tab>
          <Tab className="tab-div" href="#" id="tab-3" label={<Headset24 />}>
            <div className="support-tab-content">
              <div className="bx--telephone">
                <h2>Talk with an agent</h2>
                <p>
                  Our Support staff is available 24/7/365 to assist you via
                  phone with any services related questions.
                </p>
                <div className="box-block">
                  {Data.loadingCall ? (
                    <div class="call-animation">
                      <Phone32 fill="#fff" />
                    </div>
                  ) : (
                    <div className="circle74">
                      <MobileAudio32 fill="#555" />
                    </div>
                  )}
                </div>
                <div
                  style={{
                    position: "absolute",
                    bottom: "2.5rem",
                    right: "1.5rem",
                    left: "1.5rem",
                  }}
                >
                  <div className="spacing-inner-one">
                    <p>Telephone*</p>
                  </div>
                  <div className="bx--row spacing-inner">
                    <div className="bx--col-1 bx--no-gutter">
                      <Dropdown
                        label="+ 00"
                        ariaLabel="Dropdown"
                        id="drop-4"
                        direction="top"
                        initialSelectedItem={countrycode[5]}
                        items={countrycode}
                        itemToElement={(countrycode) =>
                          countrycode ? (
                            <>
                              <span style={{ marginRight: "0.5rem" }}>
                                {countrycode.dial_code}
                              </span>
                              <span>{countrycode.code}</span>
                            </>
                          ) : (
                            ""
                          )
                        }
                        selectedItem={Data.postalCode}
                        onChange={({ selectedItem }) =>
                          setData({
                            ...Data,
                            postalCode: selectedItem.dial_code,
                          })
                        }
                      />
                    </div>
                    <div className="bx--col bx--no-gutter">
                      <TextInput
                        labelText=""
                        id="test17"
                        invalidText="A valid value is required"
                        placeholder="Enter your telephone number"
                        name="call"
                        onChange={handleChange}
                      />
                    </div>
                  </div>
                </div>
              </div>
              <div className="btn-down">
                <Button className="btnwidth" kind="primary" onClick={makeCall}>
                  Initiate a phone call
                </Button>
              </div>
            </div>
          </Tab>
          <Tab
            className="tab-div"
            href="#"
            id="tab-3"
            label={<RequestQuote24 />}
          >
            <div className="support-tab-content">
              <div className="bx--telephone">
                <h2>My requests</h2>
                <DataTable
                  rows={AlldataWidget}
                  headers={headerData}
                  size="tall"
                >
                  {({
                    rows,
                    headers,
                    getHeaderProps,
                    getRowProps,
                    getTableProps,
                    onInputChange,
                  }) => (
                    <TableContainer>
                      <TableToolbar>
                        <TableToolbarContent>
                          {/* pass in `onInputChange` change here to make filtering work */}
                          <TableToolbarSearch
                            onChange={onInputChange}
                            expanded
                          />
                        </TableToolbarContent>
                      </TableToolbar>
                      <Table {...getTableProps()} useZebraStyles>
                        <TableHead>
                          <TableRow>
                            {headers.map((header) => (
                              <TableHeader
                                key={header.key}
                                {...getHeaderProps({ header })}
                              >
                                {header.header}
                              </TableHeader>
                            ))}
                            <TableHeader />
                          </TableRow>
                        </TableHead>
                        <TableBody>
                          {rows.map((row) => (
                            <TableRow key={row.id} {...getRowProps({ row })}>
                              {row.cells.map((cell) => (
                                <TableCell key={cell.id}>
                                  {cell.value}
                                </TableCell>
                              ))}
                              <TableCell className="bx--table-column-menu">
                                <div
                                  style={{
                                    paddingTop: "1rem",
                                  }}
                                  // onClick={()=>userticketparsing(row)

                                  // }
                                >
                                  <Link
                                    to={`/support/ticketdetail/${row.id}`}

                                    // onClick={() =>{
                                    //   localStorage.setItem(
                                    //     'ticidstore',
                                    //     row.id
                                    //   )
                                    // }}
                                  >
                                    <Launch16 />
                                  </Link>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </TableContainer>
                  )}
                </DataTable>
              </div>
              <div className="pagination-set">
                <Pagination
                  backwardText="Previous page"
                  forwardText="Next page"
                  // pageNumberText='enteries'
                  page={TablePagination.widget_page}
                  pageNumberText="Page Number"
                  pageSize={TablePagination.widget_per_page}
                  pageSizes={[
                    window.innerHeight <= 800
                      ? Math.ceil((window.innerHeight - 350) / 80)
                      : window.innerHeight > 800
                      ? Math.ceil((window.innerHeight - 350) / 76)
                      : 10,
                  ]}
                  totalItems={TablePagination.totalrow}
                  onChange={({ page }) => {
                    if (page !== Pagination.widget_page) {
                      setTablePagination({
                        ...TablePagination,
                        widget_page: page,
                      });
                    }
                  }}
                />
              </div>
            </div>
          </Tab>
        </Tabs>
      </div>
    </>
  );
};

export default SupportHelp;

const headerData = [
  {
    header: "Request#",
    key: "id",
  },
  {
    header: "Subject/Date created",
    key: "datesubject",
  },
];
