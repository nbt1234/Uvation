import { Launch20 } from "@carbon/icons-react";
import { Button, Toggle } from "carbon-components-react";
import React, { useContext } from "react";
import { Link, useHistory } from "react-router-dom";
import axios from "axios";

import { GlobalContext } from "../../../ContextApi/GlobalContext";

const CardForSection = ({ title, describe }) => (
  <>
    <div className="in-flex-all">
      <div className="heading-banner">
        <h5>{title}</h5>
        <p>{describe}</p>
      </div>
      <Launch20 />
    </div>
  </>
);

const Notification = () => {
  const history = useHistory();
  const {
    toggle,
    settoggle,
    notificationuser,
    userInfo,
    setnotificationuser,
    setloadingnotification,
    systemnotificationuser,
  } = useContext(GlobalContext);

  const notificationcheck = (value) => {
    axios
      .post("https://notifications.uvation.com:443/api/read", {
        userid: userInfo?.userid,
        notification_id: value?.id,
      })
      .then((res) => {
        setloadingnotification(true);
      });
  };
  return (
    <div className="notificationBoxMain">
      <div className="div position-relative">
        <div className="Notification-panel">
          <div className="notification-content">
            <h4>Latest notifications</h4>

            {notificationuser?.map((value, index) => {
              return (
                <>
                  {value?.zendesk_id !== null ||
                  value?.image_change_time !== null ? (
                    <>
                      {value?.zendesk_id && (
                        <div
                          className="in-flex-all"
                          onClick={() => notificationcheck(value)}
                        >
                          <div className="heading-banner">
                            <h5>System Notification</h5>
                            <p
                              onClick={() =>
                                history.push(
                                  `/support/ticketdetail/${value.zendesk_id}`
                                )
                              }
                            >
                              Your Zendesk ticket create successfully at :
                              {value?.notification_time}
                            </p>
                          </div>
                          <Launch20 />
                        </div>
                      )}

                      {value?.image_change_time && (
                        <div
                          className="in-flex-all"
                          onClick={() => notificationcheck(value)}
                        >
                          <div className="heading-banner">
                            <h5>System Notification</h5>
                            <p>
                              Your Profile Image Change successfully at:{" "}
                              {value?.image_change_time}
                            </p>
                          </div>
                          <Launch20 />
                        </div>
                      )}
                    </>
                  ) : (
                    <div
                      className="in-flex-all"
                      onClick={() => notificationcheck(value)}
                    >
                      <div className="heading-banner ">
                        <h5>System Notification</h5>
                        <p>{value?.message}</p>
                      </div>
                      <Launch20 />
                    </div>
                  )}
                </>
              );
            })}

            {/* <CardForSection
            title="System Notification"
            describe={notificationuser?.message}
          /> */}
            {/* <CardForSection
            title="Payments & billing"
            describe="Please check your latest payment, it seems that your..."
          /> */}
            {/* <div className="divider"></div> */}
            {/* <CardForSection
            title="Access granted"
            describe="Access for Vlad Serban was granted, he is now part of yo..."
          />
          <div className="divider"></div>
          <CardForSection
            title="Notification title"
            describe="Lorem ipsum dolor sit amet, consectetur adipiscing elit..."
          /> */}
          </div>
        </div>
        <div
          className="bx--row"
          style={{
            position: "absolute",
            bottom: 0,
            right: 0,
            left: 0,
          }}
        >
          <Button
            className="btn-footer"
            kind="secondary"
            onClick={() => {
              axios
                .post("https://notifications.uvation.com:443/api/dismiss_all", {
                  userid: userInfo?.userid,
                })
                .then((res) => {
                  setloadingnotification(true);
                });
              settoggle({ ...toggle, Notification: !toggle.Notification });
            }}
          >
            Dismiss all
          </Button>
          <Button
            className="btn-footer"
            as={Link}
            to="/notification"
            kind="primary"
            // onClick={() => {
            //   axios
            //     .post(
            //       "https://notifications.uvation.com:443/api/show_notification",
            //       {
            //         userid: userInfo?.userid,
            //         platform: "uvation identity",
            //       }
            //     )
            //     .then((res) => {});
            // }}
          >
            See all
            {systemnotificationuser?.length
              ? ` (${systemnotificationuser?.length})`
              : ""}
          </Button>
        </div>
      </div>
    </div>
  );
};

export default Notification;
