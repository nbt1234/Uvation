import React, { useEffect, useState, useContext } from 'react';
import {
  ArrowLeft20,
  SendAltFilled24,
  User24,
  Reply16,
  Close20,
} from '@carbon/icons-react';
import {
  ProgressIndicator,
  ProgressStep,
  TextArea,
  Button,
  FileUploaderButton,
  ModalWrapper,
  HeaderPanel,
  ButtonSet,
} from 'carbon-components-react';
import { Link, Redirect , useLocation } from 'react-router-dom';
import axios from 'axios';
import moment from 'moment';

import { GlobalContext } from '../../ContextApi/GlobalContext';

const TicketInfo = () => {
  const {
    toggle,
    settoggle,
    GlobalState,
    setGlobalState,
    Alldata,
    AlldataWidget,
    TablePagination,
    setTablePagination,
    Fillter,
    setFillter,
    photo,
    setphoto,
    ticket_id,
    setticket_id,
 } = useContext(GlobalContext);
 const usernameinfo ="zendesk_admin@uvation.com";
 const passwordinfo ="H9dh0DH72gF";
 const location = useLocation();

  const [ticketdata, setticketdata] = useState({
    id: ticket_id,
    subject: '',
    time: '',
    status: '',
    assignee_id: '',
    requester_id: '',
    message: '',
    name: '',
    email: '',
    phone: '',
    service: '',
    serverity: '',
    timeZone: '',
  });

  const [attachmentToken, setattachmentToken] = useState('');
  const [refresh, setrefresh] = useState('');

  const [reply, setreply] = useState(false);
  const [btn, setbtn] = useState(true);

  const Reply = () => {
    setreply(!reply);
    setbtn(!btn);
  };
  const Hidebtn = () => {
    setreply(!reply);
    setbtn(!btn);
  };

  const [user, setuser] = useState([
    {
      user_id: '',
      user_name: '',
      user_img: '',
    },
    {
      user_id: '',
      user_name: '',
      user_img: '',
    },
    {
      user_id: '',
      user_name: '',
      user_img: '',
    },
    {
      user_id: '',
      user_name: '',
      user_img: '',
    },
    {
      user_id: '',
      user_name: '',
      user_img: '',
    },
  ]);

  const [comment, setcomment] = useState([]);
  // {
  //   id: '',
  //   name: '',
  //   service: '',
  //   time: '',
  //   message: '',
  //   attachUrl: '',
  // },
  var ticketId = window.location.pathname.split('ticketdetail/').pop();

  const Fetchurl = async () => {
    const response = await  axios.post(
      "https://appsapi.uvation.com:8080/identity/ticket_detatil_show",
      {
        ticketId
      }
    );

    setticketdata({
      ...ticketdata,
      id: response?.data?.ticket?.id,
      subject: response?.data?.ticket?.subject,
      time: response?.data?.ticket?.created_at,
      status: response?.data?.ticket?.status,
      requester_id: response?.data?.ticket?.requester_id,
      assignee_id: response?.data?.ticket?.assignee_id,
      name: response?.data?.ticket?.custom_fields[1].value,
      email: response?.data?.ticket?.custom_fields[10].value,
      phone: response?.data?.ticket?.custom_fields[3].value,
      service: response?.data.ticket?.custom_fields[5].value,
      serverity: response?.data?.ticket?.custom_fields[9].value,
      timeZone: response?.data?.ticket?.custom_fields[6].value,
    });
  };

  const getComment = async () => {
    await axios
    .post(
      "https://appsapi.uvation.com:8080/identity/ticket_data",
      {ticketId}
    )
      .then((response) => {
        setcomment(
          response.data.comments.map((tic) => ({
            ...comment,
            id: tic.id,
            name: tic.author_id,
            service: tic.author_id,
            time: moment(tic.created_at).format('LLL'),
            message: tic.body,
            attachUrl: tic.attachments.map((data) => {
              return data.content_url;
            }),
          }))
        );

        setuser(
          response.data.users.map((usr) => ({
            user_id: usr.id,
            user_name: usr.name,
            user_img: usr.photo,
          }))
        );
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const UpdateComment = async (e) => {
    const body1 = {
      ticket: {
        comment: {
          body: ticketdata.message,
          uploads: [`${attachmentToken}`],
          author_id: ticketdata.requester_id,
        },
      },
    };
    const updatebodydata= new FormData();
    updatebodydata.append("body1",JSON.stringify(body1))
    updatebodydata.append("ticketId",ticketId)
    await axios
    .post(
      `https://appsapi.uvation.com:8080/identity/ticket_image`,updatebodydata,
    )
      .then((response) => {
        setrefresh(response.data.ticket.updated_at);
        setticketdata({
          ...ticketdata,
          message: '',
        });
       
      });
  };

  function attachmentFile(e) {
    if (e) {
      const file = e.target.files[0];
      axios
        .post(
          `https://uvation.zendesk.com/api/v2/uploads?filename=${file.name}`,
          file,
          {
            headers: {
              'Authorization': 'Basic ' + btoa(`${usernameinfo}:${passwordinfo}`),
              'Content-Type': 'application/binary',
            },
          }
        )
        .then((res) => {
          setattachmentToken(res.data.upload.token);
        })

        .catch((err) => console.log(err));
    }
  }

  useEffect(() => {
    getComment();
  }, [refresh, ticket_id ,location]);

  useEffect(() => {
    Fetchurl();
  }, [ticket_id ,location]);

  function SummaryOpen() {
    settoggle({
      ...toggle,
      Quick: false,
      Support: false,
      Notification: false,
      Account: false,
      tabselect: 0,
      switcher: false,
      viewSummary: !toggle.viewSummary,
    });
  }

  const ChatCard = ({
    img,
    name,
    service,
    time,
    message,
    classes,
    attachUrl,
  }) => (
    <div className={classes}>
      <div className='bx--grid bx--grid--full-width'>
        <div className='bx--row space-date'>
          <div className='icn-name'>
            <div className='circle32'>{img}</div>
            <div className='usertext'>
              <p className='name'>{name}</p>
              <p className='service'>{service}</p>
            </div>
          </div>
          <div className='chat-time'>
            <h6>{time}</h6>
          </div>
        </div>
        <div className='chat-desc'>
          <p>{message}</p>
          <span>
            {attachUrl != '' ? (
              <a href={attachUrl} target='_blank'>
                <img
                  src={attachUrl}
                  style={{
                    width: '200px',
                    height: '125px',
                    marginTop: '1rem',
                    borderRadius: '5px 5px',
                  }}
                />
              </a>
            ) : (
              ''
            )}
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <>
      <div className='bx--grid--full-width TicketInfo '>
        <div className='HomeHeader-Panel'>
          <HeaderPanel aria-label='Header Panel' expanded={toggle.viewSummary}>
            <div onClick={SummaryOpen} className='close-overlay'></div>
            <div className=' Quick-support-panel'>
              <div className='SupportHelp'>
                <div className='support-title'>
                  <div className='summary__title'>
                    <h2>Ticket Summary</h2>
                    {/* <Close20
                      className='close-icon-color'
                      onClick={SummaryOpen}
                    /> */}
                  </div>

                  <div className='divfortabs'>
                    <div className='submit-ticket'>
                      <h2>Service request #{ticketdata.id}</h2>
                      <div className='ticStatus'>
                        <h5>{ticketdata.subject}</h5>
                        <p>{ticketdata.status}</p>
                      </div>

                      <p className='p_design'>
                        Created by {ticketdata.name} on{}
                        {moment(ticketdata.time).format('LLLL')}
                      </p>
                      <div className='bx--col bx--no-gutter'>
                        <ProgressIndicator
                          vertical
                          currentIndex={
                            ticketdata.status === 'open'
                              ? 1
                              : 0 || ticketdata.status === 'pending'
                              ? 2
                              : 0 || ticketdata.status === 'closed'
                              ? 4
                              : 0
                          }
                        >
                          <ProgressStep
                            label='Service request opened'
                            description='Step 1: Getting started with Carbon Design System'
                            secondaryLabel={moment(ticketdata.timeZone).format(
                              'LLLL'
                            )}
                          />
                          <ProgressStep
                            label='Agent assigned'
                            description='Step 3: Getting started with Carbon Design System'
                          />
                          <ProgressStep
                            label='Issue resolved'
                            description='Step 4: Getting started with Carbon Design System'
                          />
                        </ProgressIndicator>
                      </div>

                      <div className='details'>
                        <div className='line'></div>
                        <h5>Services request details</h5>
                        <div className='detail-item '>
                          <li>
                            <p>Name</p>
                          </li>
                          <li>
                            <p>{ticketdata.name}</p>
                          </li>
                        </div>
                        <div className='detail-item '>
                          <li>
                            <p>Phone</p>
                          </li>
                          <li>
                            <p>{ticketdata.phone}</p>
                          </li>
                        </div>

                        <div className='detail-item '>
                          <li>
                            <p>Email</p>
                          </li>
                          <li>
                            <p>{ticketdata.email}</p>
                          </li>
                        </div>
                        <div className='detail-item '>
                          <li>
                            <p>Service</p>
                          </li>
                          <li>
                            <p>{ticketdata.service}</p>
                          </li>
                        </div>
                        <div className='detail-item '>
                          <li>
                            <p>Severity</p>
                          </li>
                          <li>
                            <p>{ticketdata.serverity}</p>
                          </li>
                        </div>
                        <div className='detail-item '>
                          <li>
                            <p>Timezone</p>
                          </li>
                          <li>
                            <p>{ticketdata.timeZone}</p>
                          </li>
                        </div>
                        <ButtonSet stacked>
                          <Button
                            kind='primary'
                            as={Link}
                            to={`/support/ticketdetail/`+ ticketdata.id}
                            onClick={() => {
                              setticket_id(ticketdata.id);
                              settoggle({
                                viewSummary: !toggle.viewSummary,
                              });
                            }}
                          >
                            View case page
                          </Button>
                          {/* <Button
                            kind='tertiary'
                            // onClick={() => setData({ loading: null })}
                          >
                            Open new ticket
                          </Button> */}
                        </ButtonSet>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </HeaderPanel>
        </div>
        <div className='bx--grid bx--no-gutter ticketinfo-page'>
          <div className=''>
            <div className='bx--col'>
              <div className='bx--row center-all'>
                <Link to='/allticket'>
                  <ArrowLeft20 fill='#000000' />
                </Link>
                <Link to='/allticket'>
                  <h5>Back to Support Center</h5>
                </Link>
              </div>
              <div className='ticket-heading'>
                <div>
                  <h1>
                    Ticket #{ticketdata.id} - "{ticketdata.subject}"
                  </h1>
                  <p>{moment(ticketdata.time).format('LLLL')}</p>
                </div>
                <div>
                  <Button onClick={SummaryOpen}> View summary</Button>
                </div>
              </div>
            </div>
            <div className='progressbar-line'>
              <div className='progress-container'>
                <ProgressIndicator
                  currentIndex={
                    ticketdata.status === 'open'
                      ? 1
                      : 0 || ticketdata.status === 'pending'
                      ? 2
                      : 0 || ticketdata.status === 'closed'
                      ? 4
                      : 0
                  }
                >
                  <ProgressStep
                    label='Ticket opened'
                    secondaryLabel={ticketdata.time}
                  />
                  <ProgressStep
                    label='Agent assigned'
                    secondaryLabel='A support agent has been assigned to your request.'
                  />
                  <ProgressStep
                    label='In progress'
                    secondaryLabel="The request has been received and it's in progress."
                  />
                  <ProgressStep
                    label='Ticket resolved'
                    secondaryLabel='The request has been solved and the ticked closed.'
                  />
                </ProgressIndicator>
              </div>
            </div>
            <div className='ticket-chat'>
              {comment.map((chat) => (
                <ChatCard
                  classes={
                    chat.service === user[0].user_id
                      ? 'chat-box-blue'
                      : 'chat-box'
                  }
                  key={chat.id}
                  img={
                    chat.service === user[0].user_id ? (
                      user[0].user_img ? (
                        <img
                          src={user[0].user_img.content_url}
                          style={{
                            height: 'inherit',
                            backgroundColor: 'white',
                          }}
                        />
                      ) : user[0].user_name.split(' ').length >= 2 ? (
                        user[0].user_name.split(' ')[0][0] +
                        user[0].user_name.split(' ')[1][0]
                      ) : (
                        user[0].user_name.slice(0, 2).toUpperCase()
                      )
                    ) : chat.service === user[1].user_id ? (
                      user[1].user_img ? (
                        <img
                          src={user[1].user_img.content_url}
                          style={{
                            height: 'inherit',
                            backgroundColor: 'white',
                          }}
                        />
                      ) : user[1].user_name.split(' ').length >= 2 ? (
                        user[1].user_name.split(' ')[0][0] +
                        user[1].user_name.split(' ')[1][0]
                      ) : (
                        user[1].user_name.slice(0, 2).toUpperCase()
                      )
                    ) : (
                      ''
                    )
                  }
                  name={
                    chat.name === user[0].user_id
                      ? user[0].user_name
                      : '' || chat.name === user[1].user_id
                      ? user[1].user_name
                      : '' || chat.name === user[2].user_id
                      ? user[2].user_name
                      : ''
                  }
                  service={
                    chat.service === user[0].user_id
                      ? 'Customer Support Specialist'
                      : 'Client'
                  }
                  time={chat.time}
                  message={chat.message}
                  attachUrl={chat.attachUrl}
                />
              ))}
            </div>
            <div></div>
            <div className='ticket-response'>
              <div className='bx--grid bx--no-gutter'>
                <div className='bx--row align-all-col '>
                  <div className='bx--col-lg-10 bx--no-gutter'>
                    <TextArea
                      light
                      aria-label='response here'
                      labelText='Enter your response here*'
                      placeholder='Reply'
                      rows={4}
                      value={ticketdata.message}
                      onChange={(e) =>
                        setticketdata({
                          ...ticketdata,
                          message: e.target.value,
                        })
                      }
                    />
                  </div>
                  <div className='bx--col bx--no-gutter'>
                    <h6>Attach files</h6>
                    <p>Files must be less than 5MB in size.</p>
                  </div>
                  <div className='bx--col bx--no-gutter'>
                    <FileUploaderButton
                      accept={['.jpg', '.png']}
                      buttonKind='tertiary'
                      labelText='Attach File'
                      onChange={(e) => {
                        attachmentFile(e);
                      }}
                    />
                  </div>
                  <div className='bx--col bx--no-gutter--right'>
                    <Button
                      onClick={UpdateComment}
                      className='btn-set'
                      kind='primary'
                      renderIcon={SendAltFilled24}
                    >
                      Send
                    </Button>
                  </div>
                </div>
              </div>
            </div>
            {
              <div className='reply-btn'>
                {btn ? (
                  <Button onClick={Reply}>
                    Reply <Reply16 />
                  </Button>
                ) : null}
                {reply ? (
                  <div>
                    <div className='overlay'></div>
                    <div style={{ background: 'rgb(89 94 94)' }}>
                      <div className='ticket-reply'>
                        <div className='title-text'>
                          <h3>Reply to ticket</h3>
                          <div className='close'>
                            <Close20 onClick={Hidebtn} />
                          </div>
                        </div>
                        <div className='text-area'>
                          <TextArea
                            style={{ paddingTop: '1rem' }}
                            aria-label='response here'
                            labelText='Enter your response here*'
                            placeholder='Reply'
                            value={ticketdata.message}
                            rows={window.innerHeight > 600 ? 12 : 6}
                            onChange={(e) => {
                              attachmentFile(e);
                            }}
                          />
                        </div>
                        <div className='attach-file'>
                          <div>
                            <h6>Attach files</h6>
                            <p>Files must be less than 5MB in size.</p>
                          </div>
                          <div style={{ minWidth: '10rem' }}>
                            <FileUploaderButton
                              className='file-upload-btn'
                              accept={['.jpg', '.png']}
                              buttonKind='tertiary'
                              labelText='Attach File'
                              size='field'
                              renderIcon={Reply16}
                              onChange={(e) => {
                                attachmentFile(e);
                              }}
                            />
                          </div>
                        </div>
                        <div className='send'>
                          <Button
                            onClick={UpdateComment}
                            kind='primary'
                            renderIcon={SendAltFilled24}
                            className='send-btn'
                          >
                            Send
                          </Button>
                        </div>
                      </div>
                    </div>
                  </div>
                ) : null}
              </div>
            }
          </div>
        </div>
      </div>
    </>
  );
};

export default TicketInfo;
