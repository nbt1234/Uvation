import React, { createContext, useState, useEffect } from "react";
import axios from "axios";
import { SupportServiceCard } from "../Component/SupportCenter/SupportCenter";
import moment from "moment";
import {
  InteractionRequiredAuthError,
  InteractionType,
} from "@azure/msal-browser";
import {
  MsalAuthenticationTemplate,
  useMsal,
  useAccount,
} from "@azure/msal-react";
import { loginRequest, protectedResources } from "../authConfig";
// import { userInfo.email, USER_NAME } from '../config';
import { Form, Tag } from "carbon-components-react";
import qs from "qs";
import { io } from "socket.io-client";

export const GlobalContext = createContext();

export const GlobalProvider = (props) => {
  const [isLoading, setIsLoading] = useState(true);
  const [socketdata, setsocketdata] = useState();
  const [contactinfodata, setcontactinfodata] = useState();
  const [contactdata, setcontactdata] = useState();
  const [fetchdata, setfetchdata] = useState();
  const [base64Prefix, setBase64Prefix] = useState("data:image/png;base64,");
  const [imagedata, setimagedata] = useState(false);
  const CLIENT_ID = process.env.REACT_APP_CLIENT_ID;
  const CLIENT_SECERET = process.env.REACT_APP_CLIENT_SECERET;
  const AUTH_TOKEN = process.env.REACT_APP_ZEN_AUTH_TOKEN;
  const { instance, accounts, inProgress } = useMsal();
  const account = useAccount(accounts[0] || {});
  const [notificationuser, setnotificationuser] = useState();
  const [loadingnotification, setloadingnotification] = useState(false);
  const [systemnotificationuser, setsystemnotificationuser] = useState([]);
  const [getsalesforcedata, setgetsalesforcedata] = useState(false);

  localStorage.setItem("supportusermail", account?.idTokenClaims?.email);

  localStorage.setItem("supportusername", account?.idTokenClaims?.given_name);
  const [helloData, setHelloData] = useState(null);
  const [supportdata, setsupportdata] = useState();

  useEffect(() => {
    if (account && inProgress === "none" && !helloData) {
      instance
        .acquireTokenSilent({
          scopes: protectedResources.apiHello.scopes,
          account: account,
        })
        .then((response) => {
          setsupportdata(response);
          // callApiWithToken(response.accessToken, protectedResources.apiHello.endpoint)
          //     .then(response => setHelloData(response));
        })
        .catch((error) => {
          // in case if silent token acquisition fails, fallback to an interactive method
          if (error instanceof InteractionRequiredAuthError) {
            if (account && inProgress === "none") {
              instance
                .acquireTokenPopup({
                  scopes: protectedResources.apiHello.scopes,
                })
                .then((response) => {
                  callApiWithToken(
                    response.accessToken,
                    protectedResources.apiHello.endpoint
                  ).then((response) => setHelloData(response));
                })
                .catch((error) => console.log(error));
            }
          }
        });
    }
  }, [account, inProgress, instance]);
  const [Fillter, setFillter] = useState({
    applyFilter: false,
    startDate: "",
    endDate: "",
    search: "",
  });

  useEffect(() => {
    axios
      .post("https://appsapi.uvation.com:8080/identity/access_token")
      .then((res) => {
        setMsAccessToken(res);
      });
  }, []);
  const [toggle, settoggle] = useState({
    Quick: false,
    Support: false,
    Notification: false,
    Account: false,
    openShow: "",
    closedShow: "",
    pendingShow: "",
    newShow: "",
    tabselect: "",
    FillterToggle: false,
    ListActive: false,
    viewSummary: false,
  });

  const [userInfo, setuserInfo] = useState({
    userid: null,
    fullname: null,
    email: null,
  });

  const [Alldata, setAlldata] = useState([
    {
      id: "",
      ticket: "",
      date: "",
      subject: "",
      status: "",
      datesubject: "",
    },
  ]);
  const [AlldataWidget, setAlldataWidget] = useState([
    {
      id: "",
      datesubject: "",
    },
  ]);

  const [ticket_id, setticket_id] = useState(null);

  const [TablePagination, setTablePagination] = useState({
    totalrow: "",
    page: 1,
    per_page: 8,
    widget_page: 1,
    widget_per_page: 9,
  });

  const [GlobalState, setGlobalState] = useState({
    loading: true,
    onInputChange: "",
    openCount: "",
    closedCount: "",
    pendingCount: "",
    newCount: "",
    fetchopen: "",
    fetchclosed: "",
    fetchnew: "",
    fetchpending: "",
  });

  const [photo, setphoto] = useState(null);
  const [MsAccessToken, setMsAccessToken] = useState(null);
  const getAccessTokenGraph = async () => {
    const data = qs.stringify({
      APP_ID: CLIENT_ID,
      APP_SECERET: CLIENT_SECERET,
    });
  };
  // useEffect(()=>{
  //   axios.post("https://appsapi.uvation.com:8080/identity/access_token").then((res) => {
  //     setMsAccessToken(res);
  //   },[]);
  // })
  // useEffect(()=>{
  //   const updata=new FormData();
  //   axios(configdata).then((res) => {
  //     setMsAccessToken(res);
  //   });
  // })

  // const callUser = async () => {
  //   axios
  //     .get(`https://graph.microsoft.com/beta/users/${userInfo.userid}`, {
  //       headers: {
  //         "Content-Type": "application/json",
  //         authorization: `Bearer ${MsAccessToken?.data?.data?.access_token}`,
  //       },
  //     })
  //     .then((response) => {
  //       console.log("ankit",response);
  //       setuserInfo({
  //         ...userInfo,
  //         email: response.data.identities[0].issuerAssignedId,
  //       });
  //     });
  // };
  useEffect(() => {
    setuserInfo({
      ...userInfo,
      email: account?.idTokenClaims?.email,
      fullname: account?.idTokenClaims?.given_name,
      surname: account?.idTokenClaims?.family_name,

      userid: account?.idTokenClaims?.sub,
    });
  }, [account]);
  const [siginlogs, setsiginlogs] = useState({
    loading: "",
    loadingCall: false,
  });
  const usernameinfo = "zendesk_admin@uvation.com";
  const passwordinfo = "H9dh0DH72gF";
  localStorage.setItem("newuser_d", account?.idTokenClaims?.newUser);
  const headers = {
    Authorization: "Basic " + btoa(`${usernameinfo}:${passwordinfo}`),
  };
  const countFetch = async () => {
    setIsLoading(true);
    const supporticket = new FormData();
    supporticket.append("email", userInfo?.email);
    supporticket.append("page", TablePagination?.page);
    supporticket.append("per_page", TablePagination.per_page);
    const responeall = await axios.post(
      "https://appsapi.uvation.com:8080/support/delay1",
      supporticket
    );

    const supporticket1 = new FormData();
    supporticket1.append("email", userInfo?.email);
    supporticket1.append("widget_page", TablePagination.widget_page);
    supporticket1.append("widget_per_page", TablePagination.widget_per_page);
    const responeallWidget = await axios.post(
      "https://appsapi.uvation.com:8080/support/delay2",
      supporticket1
    );
    const supporticket2 = new FormData();
    supporticket2.append("email", userInfo?.email);
    const countOpen = await axios.post(
      "https://appsapi.uvation.com:8080/support/ticket_open",
      supporticket2
    );
    const supporticket3 = new FormData();
    supporticket3.append("email", userInfo?.email);
    const countClose = await axios.post(
      "https://appsapi.uvation.com:8080/support/ticket_closed",
      supporticket3
    );
    const supporticket4 = new FormData();
    supporticket4.append("email", userInfo?.email);
    const countNew = await axios.post(
      "https://appsapi.uvation.com:8080/support/ticket_new",
      supporticket4
    );
    const supporticket5 = new FormData();
    supporticket5.append("email", userInfo?.email);
    const countPending = await axios.post(
      "https://appsapi.uvation.com:8080/support/ticket_pending",
      supporticket5
    );
    setTablePagination({
      ...TablePagination,
      totalrow: responeall?.data?.count,
    });
    setIsLoading(false);

    // console.log(responeall.data);

    setAlldata(
      responeall.data.results
        .filter((tic) =>
          Fillter.search
            ? tic.subject.toLowerCase().includes(Fillter.search) ||
              tic.id.toString().toLowerCase().includes(Fillter.search) ||
              moment(tic.created_at)
                .format("LLLL")
                .toLowerCase()
                .includes(Fillter.search)
            : Fillter.startDate == "" && Fillter.endDate == ""
            ? moment(tic.created_at).format("L")
            : moment(tic.created_at).format("L") >= Fillter.startDate &&
              moment(tic.created_at).format("L") <= Fillter.endDate
        )
        .map((tic) => ({
          id: `${tic.id}`,
          date: moment(tic.created_at).format("LLLL"),
          subject: (
            <p
              style={{
                display: "flex",
                alignItems: "center",
                fontSize: "14px",
                fontWeight: "500",
                lineHeight: "18px",
              }}
            >
              <Tag type="cool-gray" title="Clear Filter">
                {tic.ticket_form_id == 360001970193
                  ? "Technical Request"
                  : "Customer Request"}
              </Tag>
              {tic.subject}
            </p>
          ),
          status: tic.status,
          datesubject: (
            <div>
              <p
                style={{
                  fontSize: "14px",
                  lineHeight: "18px",
                  fontWeight: "500",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  color: "#383838",
                  paddingRight: "0",
                }}
              >
                {tic.subject}
              </p>
              <p
                style={{
                  width: "155px",
                  fontSize: "12px",
                  lineHeight: "15px",
                  fontWeight: "300",
                  overflow: "hidden",
                  textOverflow: "ellipsis",
                  whiteSpace: "nowrap",
                  color: "#383838",
                  paddingRight: "0",
                }}
              >
                {moment(tic.created_at).format("llll")}
              </p>
            </div>
          ),
        }))
    );
    setAlldataWidget(
      responeallWidget.data.results.map((tic) => ({
        id: `${tic.id}`,
        datesubject: (
          <div>
            <p
              style={{
                fontSize: "14px",
                lineHeight: "18px",
                fontWeight: "500",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                color: "#383838",
                paddingRight: "0",
              }}
            >
              {tic.subject}
            </p>
            <p
              style={{
                width: "130px",
                maxWidth: "155px",
                fontSize: "12px",
                lineHeight: "15px",
                fontWeight: "300",
                overflow: "hidden",
                textOverflow: "ellipsis",
                whiteSpace: "nowrap",
                paddingRight: "0",
              }}
            >
              {moment(tic.created_at).format("llll")}
            </p>
          </div>
        ),
      }))
    );
    setGlobalState({
      ...GlobalState,
      pendingCount: countPending.data.count,
      closedCount: countClose.data.count,
      newCount: countNew.data.count,
      openCount: countOpen.data.count,
      fetchopen: countOpen.data.results
        .filter((tic) =>
          Fillter.search
            ? tic.subject.toLowerCase().includes(Fillter.search) ||
              tic.id.toString().toLowerCase().includes(Fillter.search) ||
              moment(tic.created_at)
                .format("LLLL")
                .toLowerCase()
                .includes(Fillter.search)
            : Fillter.startDate == "" && Fillter.endDate == ""
            ? moment(tic.created_at).format("L")
            : moment(tic.created_at).format("L") >= Fillter.startDate &&
              moment(tic.created_at).format("L") <= Fillter.endDate
        )
        .map((tic) => (
          <SupportServiceCard
            key={tic.id}
            id={tic.id}
            servicename={
              tic.ticket_form_id == 360001970193
                ? "Technical Request"
                : "Customer Request"
            }
            serviceabout={tic.subject}
            created={moment(tic.created_at).format("LLLL")}
            onClick={() => setticket_id(tic.id)}
          />
        )),
      fetchclosed: countClose.data.results
        .filter((tic) =>
          Fillter.search
            ? tic.subject.toLowerCase().includes(Fillter.search) ||
              tic.id.toString().toLowerCase().includes(Fillter.search) ||
              moment(tic.created_at)
                .format("LLLL")
                .toLowerCase()
                .includes(Fillter.search)
            : Fillter.startDate == "" && Fillter.endDate == ""
            ? moment(tic.created_at).format("L")
            : moment(tic.created_at).format("L") >= Fillter.startDate &&
              moment(tic.created_at).format("L") <= Fillter.endDate
        )
        .map((tic) => (
          <SupportServiceCard
            key={tic.id}
            id={tic.id}
            servicename={
              tic.ticket_form_id == 360001970193
                ? "Technical Request"
                : "Customer Request"
            }
            serviceabout={tic.subject}
            created={moment(tic.created_at).format("LLLL")}
            onClick={() => setticket_id(tic.id)}
          />
        )),
      fetchpending: countPending.data.results
        .filter((tic) =>
          Fillter.search
            ? tic.subject.toLowerCase().includes(Fillter.search) ||
              tic.id.toString().toLowerCase().includes(Fillter.search) ||
              moment(tic.created_at)
                .format("LLLL")
                .toLowerCase()
                .includes(Fillter.search)
            : Fillter.startDate == "" && Fillter.endDate == ""
            ? moment(tic.created_at).format("L")
            : moment(tic.created_at).format("L") >= Fillter.startDate &&
              moment(tic.created_at).format("L") <= Fillter.endDate
        )
        .map((tic) => (
          <SupportServiceCard
            key={tic.id}
            id={tic.id}
            servicename={
              tic.ticket_form_id == 360001970193
                ? "Technical Request"
                : "Customer Request"
            }
            serviceabout={tic.subject}
            created={moment(tic.created_at).format("LLLL")}
            onClick={() => setticket_id(tic.id)}
          />
        )),
      fetchnew: countNew.data.results
        .filter((tic) =>
          Fillter.search
            ? tic.subject.toLowerCase().includes(Fillter.search) ||
              tic.id.toString().toLowerCase().includes(Fillter.search) ||
              moment(tic.created_at)
                .format("LLLL")
                .toLowerCase()
                .includes(Fillter.search)
            : Fillter.search
            ? tic.subject.toLowerCase().includes(Fillter.search) ||
              tic.id.toString().toLowerCase().includes(Fillter.search) ||
              moment(tic.created_at)
                .format("LLLL")
                .toLowerCase()
                .includes(Fillter.search)
            : Fillter.startDate == "" && Fillter.endDate == ""
            ? moment(tic.created_at).format("L")
            : moment(tic.created_at).format("L") >= Fillter.startDate &&
              moment(tic.created_at).format("L") <= Fillter.endDate
        )
        .map((tic) => (
          <SupportServiceCard
            key={tic.id}
            id={tic.id}
            servicename={
              tic.ticket_form_id == 360001970193
                ? "Technical Request"
                : "Customer Request"
            }
            serviceabout={tic.subject}
            created={moment(tic.created_at).format("LLLL")}
            onClick={() => setticket_id(tic.id)}
          />
        )),
      loading: false,
    });
  };
  useEffect(() => {
    if (userInfo.userid) {
      getAccessTokenGraph();
    }
  }, [userInfo.userid]);

  // useEffect(() => {
  //   if (userInfo.userid) {
  //     GetPhoto();
  //     // callUser();
  //   }
  // }, [MsAccessToken, userInfo.userid]);
  useEffect(() => {
    if (userInfo.userid) {
      countFetch();
    }
  }, [
    TablePagination.per_page,
    TablePagination.page,
    TablePagination.widget_page,
    TablePagination.widget_per_page,
    Fillter.applyFilter,
    Fillter.search,
    userInfo.email,
  ]);
  useEffect(() => {
    var socket = io.connect("https://notifications.uvation.com:443/");
    socket.on("connected", (i) => {
      // alert("awdaiwdhawuigdahiwd");
    });
    socket.emit("join", { userid: account?.idTokenClaims?.sub });
    setsocketdata(socket);
  }, [account]);

  let userdaat = {};

  const daass = accounts.map((value) => {
    if (value.idTokenClaims.isForgotPassword) {
      userdaat.isForgotPasswords = value.idTokenClaims.isForgotPassword;
    }
    return <></>;
  });
  const usernotification_token = localStorage.getItem("notification_token");
  useEffect(() => {
    if (userdaat) {
      axios
        .post("https://notifications.uvation.com:443/api/user_signup", {
          userid: account?.idTokenClaims?.sub,
          login_time: userdaat?.login,
          forgot_password_time: userdaat?.ForgotPasswordDateTime,
          change_password_time: userdaat?.PasswordResetDateTimeu,
          change_mfa_time: userdaat?.ChangeMFAphnNo_DateTimeuser,
          profile_edit_time: userdaat?.profile_edit_time,
          new_user: account?.idTokenClaims?.newUser,
          platform: "uvation support",
          forgot_password: userdaat.isForgotPasswords,
          token: usernotification_token,
        })
        .then((res) => {
          axios
            .post(
              "https://notifications.uvation.com:443/api/all_notifications",
              {
                userid: account?.idTokenClaims?.sub,
                platform: "uvation identity",
              }
            )
            .then((res) => {
              setloadingnotification(false);
              setnotificationuser(res?.data?.data);
            });
        });
    }
  }, [account, loadingnotification]);

  let fetchtime;
  let timeout;
  let fetchtimeset;

  const rewardCreateContact = (response) => {
    axios
      .post("https://appsapi.uvation.com:8080/reward/contact", {
        azureId: account?.idTokenClaims?.sub,
        firstName: account?.idTokenClaims?.given_name,
        lastName: account?.idTokenClaims?.family_name,
        email: account?.idTokenClaims?.email,
        ssContactId: response?.id,
        referral: account?.idTokenClaims?.extension_referralCode,
        phoneNo: `${account?.idTokenClaims?.extension_CountryCode}${account?.idTokenClaims?.MobileNumber}`,
      })
      .then((res) => {});
  };

  const createSalesforceContact = (response, timeout) => {
    axios
      .post(
        `${response?.response?.instance_url}/services/data/v43.0/sobjects/Contact`,
        {
          FirstName: account?.idTokenClaims?.given_name,
          LastName: account?.idTokenClaims?.family_name,
          Phone: "",
          email: account?.idTokenClaims?.email,
          MailingCity: "",
          MailingCountry: "",
          MailingState: "",
          MailingStreet: "",
          MailingPostalCode: "",
          Company_Name__c: "",
          Azure_User_ID__c: account?.idTokenClaims?.sub,
        },
        {
          headers: {
            Authorization: `Bearer ${response?.response?.access_token}`,
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        if (res?.status == 201) {
          clearInterval(timeout);
          fetchtimeset = setInterval(() => {
            setgetsalesforcedata(true);
          }, 5000);
          rewardCreateContact(res?.data);
        }
      });
  };

  const checkUserExists = (response1) => {
    axios
      .get(
        `${response1?.response?.instance_url}/services/apexrest/userExists?azureId=${account?.idTokenClaims?.sub}`,
        {
          headers: {
            Authorization: `Bearer ${response1?.response?.access_token}`,
            "Access-Control-Allow-Origin": "*",
          },
        }
      )
      .then((res) => {
        if (res?.data?.Exists == false) {
          timeout = setInterval(() => {
            createSalesforceContact(response1, timeout);
          }, 5000);
        }
      });
  };
  const salesforcetoken = () => {
    axios
      .post("https://appsapi.uvation.com:8080/identity/sftoken")
      .then((res) => {
        setfetchdata(res.data);
        checkUserExists(res.data);
        // createSalesforceContact(res.data);
      });
  };

  useEffect(() => {
    if (account) {
      salesforcetoken();
    }
  }, [account]);

  useEffect(() => {
    if (fetchdata) {
      axios
        .get(
          `${fetchdata?.response?.instance_url}/services/apexrest/ContactInfo?azureId=${account?.idTokenClaims?.sub}`,
          {
            headers: {
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              "Access-Control-Allow-Origin": "*",
            },
          }
        )
        .then((res) => {
          if (res?.data?.status == "Success") {
            clearInterval(fetchtime);
            clearInterval(fetchtimeset);
            setcontactinfodata(res?.data?.contactInfo);
            setcontactsalesforce(res?.data?.companyInfo);
          }
        });
    }
  }, [fetchdata, account, getsalesforcedata]);

  const rewarddat_edit = () => {
    axios
      .post("https://appsapi.uvation.com:8080/reward/edit_contact", {
        azureId: account?.idTokenClaims?.sub,
        firstName: account?.idTokenClaims?.given_name,
        lastName: account?.idTokenClaims?.family_name,
        email: account?.idTokenClaims?.email,
        phoneNo: `${account?.idTokenClaims?.extension_CountryCode}${account?.idTokenClaims?.MobileNumber}`,
      })
      .then(() => {});
  };
  useEffect(() => {
    if (contactinfodata?.recordId && fetchdata) {
      axios
        .patch(
          `${fetchdata?.response?.instance_url}/services/data/v41.0/sobjects/contact/${contactinfodata?.recordId}`,
          {
            FirstName: account?.idTokenClaims?.given_name,
            LastName: account?.idTokenClaims?.family_name,
            Email: account?.idTokenClaims?.email,
            Phone: account?.idTokenClaims?.MobileNumber,
            MailingStreet: account?.idTokenClaims?.streetAddress,
            MailingCity: account?.idTokenClaims?.city,
            MailingState: account?.idTokenClaims?.state,
            MailingCountry: account?.idTokenClaims?.country,
            MailingPostalCode: account?.idTokenClaims?.postalCode,
          },
          {
            headers: {
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              "Access-Control-Allow-Origin": "*",
            },
          }
        )
        .then((res) => {});
    }
  }, [contactinfodata, fetchdata, account]);
  useEffect(() => {
    if (contactinfodata?.recordId !== undefined) {
      axios
        .get(
          `${fetchdata?.response?.instance_url}/services/apexrest/ProfileImage?contactId=${contactinfodata?.recordId}`,
          {
            headers: {
              "Content-Type": "application/json",
              Authorization: `Bearer ${fetchdata?.response?.access_token}`,
              "Access-Control-Allow-Origin": "*",
            },
          }
        )
        .then((res) => {
          setphoto(res);
          setBase64Prefix("data:image/png;base64,");
        });
    }
    // }
  }, [contactinfodata, fetchdata, imagedata]);
  return (
    <GlobalContext.Provider
      value={{
        setBase64Prefix,
        base64Prefix,
        notificationuser,
        systemnotificationuser,
        setsystemnotificationuser,
        setloadingnotification,
        socketdata,
        supportdata,
        isLoading,
        helloData,
        toggle,
        settoggle,
        siginlogs,
        setsiginlogs,
        GlobalState,
        setGlobalState,
        userInfo,
        setuserInfo,
        Alldata,
        AlldataWidget,
        TablePagination,
        setTablePagination,
        Fillter,
        setFillter,
        photo,
        setphoto,
        ticket_id,
        setticket_id,
      }}
    >
      {props.children}
    </GlobalContext.Provider>
  );
};
