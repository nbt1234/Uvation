/*
 * Copyright (c) Microsoft Corporation. All rights reserved.
 * Licensed under the MIT License.
 */

import { LogLevel } from "@azure/msal-browser";

const data_newuser = localStorage.getItem("newuser_d");

export const b2cPolicies = {
  names: {
    signUpSignIn: "B2C_1A_DEMO1_PROGRESSIVE_SIGNUP_SIGNIN_REFERRAL",
    // signUpSignIn: "B2C_1A_DEMO1_PROGRESSIVE_PROFILING_SIGNUP_SIGNIN",
    forgotPassword: "B2C_1A_PASSWORD_RESET",
    editProfile: "B2C_1A_PROFILE_EDI",
  },
  authorities: {
    signUpSignIn: {
      authority:
        // "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROGRESSIVE_PROFILING_SIGNUP_SIGNIN",
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROGRESSIVE_SIGNUP_SIGNIN_REFERRAL",
    },
    forgotPassword: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_PASSWORD_RESET",
    },
    editProfile: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_PROFILE_EDIT",
    },
    changePassword: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_PASSWORD_RESET",
    },
    deactivate: {
      authority:
        "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DELETE_MY_ACCOUNT",
    },
  },
  authorityDomain: "uvationidp.b2clogin.com",
};

export const msalConfig = {
  auth: {
    clientId: "70047577-a5d1-4487-b960-8d3abbf2d5e0", // This is the ONLY mandatory field that you need to supply.
    authority: b2cPolicies.authorities.signUpSignIn.authority, // Use a sign-up/sign-in user-flow as a default authority
    knownAuthorities: [b2cPolicies.authorityDomain], // Mark your B2C tenant's domain as trusted.
    redirectUri: window.location.origin,
    // redirectUri:window.location.origin, // Points to window.location.origin. You must register this URI on Azure Portal/App Registration.
    postLogoutRedirectUri:
      "https://uvationidp.b2clogin.com/uvationidp.onmicrosoft.com/B2C_1A_DEMO1_PROGRESSIVE_PROFILING_SIGNUP_SIGNIN/oauth2/v2.0/logout?post_logout_redirect_uri=https://support.uvation.com/", // Indicates the page to navigate after logout.
    navigateToLoginRequestUrl: true, // If "true", will navigate back to the original request location before processing the auth code response.
  },
  cache: {
    cacheLocation: "sessionStorage", // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
    storeAuthStateInCookie: true, // Set this to "true" if you are having issues on IE11 or Edge
  },
  system: {
    allowRedirectInIframe: true,

    loggerOptions: {
      loggerCallback: (level, message, containsPii) => {
        if (containsPii) {
          return;
        }
        switch (level) {
          case LogLevel.Error:
            console.error(message);
            return;
          case LogLevel.Info:
            console.info(message);
            return;
          case LogLevel.Verbose:
            console.debug(message);
            return;
          case LogLevel.Warning:
            console.warn(message);
            return;
        }
      },
    },
  },
};

/**
 * Scopes you add here will be prompted for user consent during sign-in.
 * By default, MSAL.js will add OIDC scopes (openid, profile, email) to any login request.
 * For more information about OIDC scopes, visit:
 * https://docs.microsoft.com/en-us/azure/active-directory/develop/v2-permissions-and-consent#openid-connect-scopes
 */

export const loginRequest = {
  scopes: [
    "openid",
    "profile",
    "offline_access",
    "https://uvationidp.onmicrosoft.com/api/demo.read",
  ],
};

// export const options = {
//   loginType: LoginType.Redirect,
//   tokenRefreshUri: window.location.origin + "/auth.html",
// };

/**
 * An optional silentRequest object can be used to achieve silent SSO
 * between applications by providing a "login_hint" property.
 */

export const silentRequest = {
  scopes: ["openid", "profile", "offline_access"],
  loginHint: "example@domain.net",
};

export const protectedResources = {
  apiHello: {
    endpoint: "https://azb2c.uvation.com/hello",
    scopes: ["https://uvationidp.onmicrosoft.com/tasks-api/tasks.read"], // e.g. api://xxxxxx/access_as_user
  },
};
