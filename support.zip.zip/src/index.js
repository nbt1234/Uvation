import React from "react";
import ReactDOM from "react-dom";
import { PublicClientApplication } from "@azure/msal-browser";
import { MsalProvider } from "@azure/msal-react";
import { msalConfig } from "./authConfig";
import App from "./App.js";
import { Provider } from "react-redux";
import ChatStore from "./stores/chatStore";
import "./index.scss";
import { GlobalContext, GlobalProvider } from "./ContextApi/GlobalContext";

const msalInstance = new PublicClientApplication(msalConfig);

ReactDOM.render(
  <React.StrictMode>
    <MsalProvider instance={msalInstance}>
      <Provider store={ChatStore}>
        <GlobalProvider>
          <App />
        </GlobalProvider>
      </Provider>
    </MsalProvider>
  </React.StrictMode>,
  document.getElementById("root")
);

// REACT_APP_AUTH_TOKEN = f8b18d0e9849191e143cf9ae41d3eb59
