import React from 'react'
import Header from './Header';
import Footer from './Footer';
import bannerring from "./images/banner-ring.png";
import prveprotl from "./images/image-removebg-preview.png";
import seicon1 from "./images/icon3.png";
import seicon2 from "./images/icon1.png";
import seicon3 from "./images/icon2.png";
import laptopicon from "./images/laptop.png";
import gamechart from "./images/Group-arow.png";
import quarterlisticon from "./images/image-removebg-previ.png";
import teamicon1 from "./images/Polygon1.png";
import teamicon2 from "./images/Polygon2.png";
import teamicon3 from "./images/Polygon3.png";
import teamicon4 from "./images/Polygon4.png";
import teamicon5 from "./images/Polygon5.png";
import Slider from "react-slick";



import { Link } from 'react-router-dom';


const Homapage = () => {


    
/////
  // var marqueeone = {
  //   className: "marqueeloop  maplop",
  //   speed: 5000,
  //   autoplay: true,
  //   autoplaySpeed: 0,
  //   centerMode: true,
  //   cssEase: 'linear',
  //   slidesToShow: 1,
  //   slidesToScroll: 1,
  //   variableWidth: true,
  //   infinite: true,
  //   initialSlide: 1,
  //   arrows: false,
  //   buttons: false
  // };

  // var marqueetwo = {
  //   className: "marqueeloop play_nft",
  //   speed: 5000,
  //   autoplay: true,
  //   autoplaySpeed: 0,
  //   centerMode: true,
  //   cssEase: 'linear',
  //   slidesToShow: 1,
  //   slidesToScroll: 1,
  //   variableWidth: true,
  //   infinite: true,
  //   initialSlide: 1,
  //   arrows: false,
  //   buttons: false
  // };


  // var marqueethre = {
  //   //className: "marqueeloop play_nft",
  //   speed: 5000,
  //   autoplay: true,
  //   autoplaySpeed: 0,
  //   centerMode: true,
  //   cssEase: 'linear',
  //   slidesToShow: 1,
  //   slidesToScroll: 1,
  //   variableWidth: true,
  //   infinite: true,
  //   initialSlide: 1,
  //   arrows: false,
  //   buttons: false

  // };

  var settingsquarter = {
    className: "quarter-box",
    dots: true,
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 4,
    responsive: [
      {
      breakpoint: 1025,
      settings: {
       slidesToShow: 3,
       slidesToScroll: 1
      
      }
      },
      {
      breakpoint: 767,
      settings: {
       slidesToShow: 2,
       slidesToScroll: 1
      }
      },
      {
      breakpoint: 480,
      settings: {
       slidesToShow: 1,
       slidesToScroll: 1
      }
      }
      
      ]
  };

  var settingportalteam = {
    className: "portal-team",
    dots: false,
    infinite: true,
    slidesToShow: 4,
    slidesToScroll: 4,
    responsive: [
      {
      breakpoint: 1025,
      settings: {
       slidesToShow: 3,
       slidesToScroll: 1
      
      }
      },
      {
      breakpoint: 767,
      settings: {
       slidesToShow: 2,
       slidesToScroll: 1
      }
      },
      {
      breakpoint: 480,
      settings: {
       slidesToShow: 1,
       slidesToScroll: 1
      }
      }
      
      ]
  };



  return (
    <>
    <div className='home_page_waspper'>
    <Header/>
    <section className="banner-outer" id="bannerid">
    <div className="container_rows">
     <div className="banner-box">
        <div className="banner-text">
            <h1>Powerful <br /> Hybrid Ecosystem <span>PORTAL</span></h1>
           <p>Portal connects metaverses, play-to-earn games and NFT’s, all in one hybrid ecosystem. </p>
           <div className="banner-btn"><Link to={"/metaverses"} className="open-btn">Open App</Link> <Link to="#" className="whitepaper-btn">Whitepaper</Link></div>
        </div>
        <div className="banner-img"><img  src={bannerring} alt="banner"/></div> 
        <div className="clear"></div>
    </div>
    </div>
    </section>
 

		<div className="menu_marwu">
			<div className="menu_marq_item">
			
				<div className="marquee">
					<div className="marquee_inner" aria-hidden="true">
		    <p className="split">PLAY TO EARN GAMING ECOSYSTEM</p>
    <p className="split">NFT DEVELOPMENT AND REWARD SYSTEM</p>
    <p className="split">HYBRID SOCIAL METAVERSE PLATFROM</p>
        <p className="split">PLAY TO EARN GAMING ECOSYSTEM</p>
    <p className="split">NFT DEVELOPMENT AND REWARD SYSTEM</p>
    <p className="split">HYBRID SOCIAL METAVERSE PLATFROM</p>
        <p className="split">PLAY TO EARN GAMING ECOSYSTEM</p>
    <p className="split">NFT DEVELOPMENT AND REWARD SYSTEM</p>
    <p className="split">HYBRID SOCIAL METAVERSE PLATFROM</p>
        <p className="split">PLAY TO EARN GAMING ECOSYSTEM</p>
    <p className="split">NFT DEVELOPMENT AND REWARD SYSTEM</p>
    <p className="split">HYBRID SOCIAL METAVERSE PLATFROM</p>
					</div>
				</div>
			</div>
			
			
		</div>


    <section className="cxplore-portal-outer" id="whatprtsl">
    <div className="container_rows"> <div className="cxplore-portal-box">
        <div className="cxplore-portal-img"><img  src={prveprotl} alt="banner"/></div>
        <div className="cxplore-portal-text">
            <h2>PORTAL</h2>
           <div className="cxplore-text"><p>Portal is the first hybrid social metaverse platform providing metaverses, play-to-earn games and NFT development all within one interconnected ecosystem and easy accessible through your personal Portal: discover <span className="red-mre">Read More</span></p>
           <div className="red-hide"><p>Portal is the first hybrid social metaverse platform providing metaverses, play-to-earn games and NFT development all within one interconnected ecosystem and easy accessible through your personal.</p><p>Portal is the first hybrid social metaverse platform providing metaverses, play-to-earn games and NFT development all within one interconnected ecosystem and easy accessible through your personal.</p></div></div>
           <div className="cxplore-btn"><Link to={"/metaverses"} className="exp-btn">Explore Portal</Link></div>
        </div>
        
        <div className="clear"></div>
       </div>
    </div>
</section>
    


<section className="metaverse-outer">
   <div className="container_rows">
<div className="metaverse-list">

<div className="list-item-bx">
<div className="item-title">
<div className="title-text">Metaverse Land Revenue</div>
</div>
<div className="item-contenty">
<div className="item-imgy">
<img src={seicon1} alt=""/>
</div>
<div className="metavr-text">
<p>Portal buys land and structures to generate revenue + rewards for token holders.</p>
</div>
</div>
</div>


<div className="list-item-bx">
<div className="item-title">
<div className="title-text">Portal Headquaters</div>
</div>
<div className="item-contenty">
<div className="item-imgy">
<img src={seicon2} alt=""/>
</div>
<div className="metavr-text">
<p>Portal builds headquaters in multiple metaverses, forming a direct connecting between these projects.</p>
</div>
</div>
</div>



<div className="list-item-bx">
<div className="item-title">
<div className="title-text">NFT Development & Rewards</div>
</div>
<div className="item-contenty">
<div className="item-imgy">
<img src={seicon3} alt=""/>
</div>
<div className="metavr-text">
<p>Portal NFT sales generate revenue to reward the Portal ecosystem and Portal token holders.</p>
</div>
</div>
</div>

</div>
</div>
</section>






<section className="platform-outer" id="platformid">
    <div className="platform-itm">
    <div className="menu_marwu3">
    <div className="menu_marq_item3">
    
      <div className="marquee3">
        <div className="marquee_inner3" aria-hidden="true">
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        <p>PORTAL  INTERFACE</p>
        
        </div>
      </div>
    </div>
    </div>


    </div>
   <div className="platform-laptop"> <div className="container_rows">
  <div className="platform-img"><img  src={laptopicon} alt="laptop"/></div>

</div>
</div>
</section>


<section className="overview-portal-outer" id="portaloverview">
    <h2>Portal Overview</h2>
    <div className="container_rows"> 

        <div className="overview-portal-box">
        <div className="overview-portal-img"><img  src={gamechart} alt="" /></div>
        <div className="overview-portal-text">
            
           <div className="overview-text"><p>Portal forms a hybrid connection between metaverses, play-to-earn gaming and NFT's.</p>
           <p>On the Portal platform $PRTL will be used as it's currency. Demand for $PRTL is driven by it's platform ecosystem and attractive rewards. Token holders receive rewards from various aspects of the Portal ecosystem. </p><p>Portal is built in such a way that the platform strengthens all mutual elements but also grows as individual sectors develop. $PRTL token holders will benefit and $PRTL will gain value when these Overall sectors develop and continue to grow.</p></div>
         
        </div>
        
        <div className="clear"></div>
    </div></div>
</section>














<div className="menu_marwu2" id="roadmapid">
<div className="menu_marq_item2">

  <div className="marquee2">
    <div className="marquee_inner2" aria-hidden="true">
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    <p className="split">road map</p>
    </div>
  </div>
</div>


</div>


<section className="quarter-outer">
<div className="container_rows"> 
<div className="quarter-logo"><img  src={quarterlisticon} alt=""/></div>
<Slider {...settingsquarter}>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2021</div>
<div className="quarter-list"><p>Initial platform development</p><p>Setting up smart contracts</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q1 2022</div>
<div className="quarter-list"><p>Team expansion </p><p>Whitepaper released</p><p>First projects for connection with Portal</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q2 2022 </div>
<div className="quarter-list"><p>First land bought in metaverses</p><p>More investors on board</p><p>Building more connections with projects</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q3 2022</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 1</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 2</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 3</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 4</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>


<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 12</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 22</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 33</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>
<div className="quarter-loop"><div className="quarter-loop-innr">
<div className="quarter-year">Q4 2022 44</div>
<div className="quarter-list"><p>Portal token sale</p><p>Boosting Portal marketing</p><p>Staking tokens on Portal platform</p></div>
</div></div>



</Slider>
</div>
</section>


<section className="portal-team-outer" id="ourteamid">
<div className="container_rows"> 
<div className="portal-team-hed"><h2>Portal Team</h2></div>


<Slider {...settingportalteam}>


<div className="portal-loop">
<div className="portal-img"><img  src={teamicon1} alt="icon"/></div>
<div className="portal-tile">Rien</div>
<div className="portal-fondr"><p>Founder<br />Marketing <br />Creative <br />Blockchain</p></div>
</div>

<div className="portal-loop">
<div className="portal-img"><img  src={teamicon2} alt="icon"/></div>
<div className="portal-tile">Yor</div>
<div className="portal-fondr"><p>CTO<br />Full Stack<br />Blockchain<br />Developer</p></div>
</div>


<div className="portal-loop">
<div className="portal-img"><img  src={teamicon3} alt="icon"/></div>
<div className="portal-tile">Adri</div>
<div className="portal-fondr"><p>CMO<br />Business Builder<br /> Blockchain<br />Start-ups</p></div>
</div>

<div className="portal-loop">
<div className="portal-img"><img  src={teamicon4} alt="icon"/></div>
<div className="portal-tile">Benji</div>
<div className="portal-fondr"><p>Marketing<br />GROWTH<br />Hacker<br />Community+</p></div>
</div>

<div className="portal-loop">
<div className="portal-img"><img  src={teamicon5} alt="icon"/></div>
<div className="portal-tile">Dan</div>
<div className="portal-fondr"><p>Marketing<br />Community+<br />NFT Specialist<br />Partnerships</p></div>
</div>


<div className="portal-loop">
<div className="portal-img"><img  src={teamicon1} alt="icon"/></div>
<div className="portal-tile">Rien 1</div>
<div className="portal-fondr"><p>Founder<br />Marketing <br />Creative <br />Blockchain</p></div>
</div>

<div className="portal-loop">
<div className="portal-img"><img  src={teamicon2} alt="icon"/></div>
<div className="portal-tile">Yor 2</div>
<div className="portal-fondr"><p>CTO<br />Full Stack<br />Blockchain<br />Developer</p></div>
</div>


<div className="portal-loop">
<div className="portal-img"><img  src={teamicon3} alt="icon"/></div>
<div className="portal-tile">Adri 3</div>
<div className="portal-fondr"><p>CMO<br />Business Builder<br /> Blockchain<br />Start-ups</p></div>
</div>

<div className="portal-loop">
<div className="portal-img"><img  src={teamicon4} alt="icon"/></div>
<div className="portal-tile">Benji 4</div>
<div className="portal-fondr"><p>Marketing<br />GROWTH<br />Hacker<br />Community+</p></div>
</div>

<div className="portal-loop">
<div className="portal-img"><img  src={teamicon5} alt="icon"/></div>
<div className="portal-tile">Dan 5</div>
<div className="portal-fondr"><p>Marketing<br />Community+<br />NFT Specialist<br />Partnerships</p></div>
</div>


</Slider>
</div>
</section>



      <Footer/>
    </div>
    </>
  )
}

export default Homapage
