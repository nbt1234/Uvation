import React,{useState} from 'react'
import { Link } from 'react-router-dom';

import logo from "./images/logo.png";
import searchbtn from "./images/arowinpt.png";

const Loginpage = () => {
  const [inputval ,setInputVal] = useState('')
  const changeHandler = (event) =>{
    setInputVal(event.target.value);
    // console.log(event.target.value)
  }
  return (
    <div className='login_page_waspper'>
    <div className="home-content-outer">

    <div className="portal-box">
    <div className="home-portal">
   <img src={logo} alt="logo"/>
   
           <div className="typeaccescode_box">
                      <div className="typeacces_itm">
                   <form className="typeacces_exaple" action="#">
                    <input type="text" placeholder="Type Acces Code" name="typeaccescode" onChange={(e)=>changeHandler(e)}/>
                  { inputval && <Link to="/homapage"><img  src={searchbtn} alt="search"/></Link>}
                    
                   </form>
                        </div>
             </div>
   </div>
   </div>
   
   </div>
    </div>
  )
}

export default Loginpage
