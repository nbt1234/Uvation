import React from 'react';
import { Link } from 'react-router-dom';
import logo from "./images/logo.png";
import metavers1 from "./images/metavers1.svg";
import metavers2 from "./images/metavers2.svg";
import metavers3 from "./images/metavers3.svg";
import Slider from "react-slick";


const Metaverses = () => {

    var settingmetaves = {
        className: "metavers_sliderlop metavers_slider_team",
        dots: false,
        infinite: true,
        centerMode: true,
        centerPadding: '0',
        slidesToShow: 3,
        slidesToScroll: 1,
        responsive: [
 
          {
          breakpoint: 767,
          settings: {
            centerMode: false,
           slidesToShow: 1,
           slidesToScroll: 1
          }
          },
          {
          breakpoint: 480,
          settings: {
            centerMode: false,
           slidesToShow: 1,
           slidesToScroll: 1
          }
          }
          
          ]
      };



  return (
    <div className='metavers_page_waspper'>
    <header className="site-header head_same">
        
    <div className="container_rows">
        <div className="siteheader">
        <div className="logo_box">
        <div className="logo_icon">
            <Link to={"/homapage"}> <img  src={logo} alt="logo"/></Link>
        </div>
        </div>





<div className="wallet_box_outer">
        <ul className="menu-nev">
        <li><Link to={"/profile"}> Profile</Link></li>
        <li><Link to={"/games"}> Games</Link></li>
        <li className='actve'><Link to={"/metaverses"}> Metaverses</Link></li>
        <li><Link to="#"> Connect Wallet</Link></li>
        </ul>


</div>      

<div className="clear"></div>


    </div>
</div>


</header>


<section className="metavers_slider">
<div className="container_rows"> 

<Slider {...settingmetaves}>


<div className="metavers-loop"><div className="metavers-loop-iiner">
<div className="metavers-img"><img  src={metavers1} alt="icon"/></div>
<div className="metavers-tile">Otherside</div>
<div className="metavers-fondr"><p><i class="fa fa-circle" aria-hidden="true"></i> 30k Players Online</p> <Link to="#"> More Info <i class="fa fa-long-arrow-right" aria-hidden="true"></i></Link></div>
</div></div>

<div className="metavers-loop"><div className="metavers-loop-iiner">
<div className="metavers-img"><img  src={metavers2} alt="icon"/></div>
<div className="metavers-tile">NetVRK</div>
<div className="metavers-fondr"><p><i class="fa fa-circle" aria-hidden="true"></i> 30k Players Online</p> <Link to="#"> More Info <i class="fa fa-long-arrow-right" aria-hidden="true"></i></Link></div>
</div></div>


<div className="metavers-loop"><div className="metavers-loop-iiner">
<div className="metavers-img"><img  src={metavers3} alt="icon"/></div>
<div className="metavers-tile">Illuvium</div>
<div className="metavers-fondr"><p><i class="fa fa-circle" aria-hidden="true"></i> 30k Players Online</p> <Link to="#"> More Info <i class="fa fa-long-arrow-right" aria-hidden="true"></i></Link></div>
</div></div>


<div className="metavers-loop"><div className="metavers-loop-iiner">
<div className="metavers-img"><img  src={metavers1} alt="icon"/></div>
<div className="metavers-tile">Otherside 1</div>
<div className="metavers-fondr"><p><i class="fa fa-circle" aria-hidden="true"></i> 30k Players Online</p> <Link to="#"> More Info <i class="fa fa-long-arrow-right" aria-hidden="true"></i></Link></div>
</div></div>

<div className="metavers-loop"><div className="metavers-loop-iiner">
<div className="metavers-img"><img  src={metavers2} alt="icon"/></div>
<div className="metavers-tile">NetVRK 1</div>
<div className="metavers-fondr"><p><i class="fa fa-circle" aria-hidden="true"></i> 30k Players Online</p> <Link to="#"> More Info <i class="fa fa-long-arrow-right" aria-hidden="true"></i></Link></div>
</div></div>


<div className="metavers-loop"><div className="metavers-loop-iiner">
<div className="metavers-img"><img  src={metavers3} alt="icon"/></div>
<div className="metavers-tile">Illuvium 1</div>
<div className="metavers-fondr"><p><i class="fa fa-circle" aria-hidden="true"></i> 30k Players Online</p> <Link to="#"> More Info <i class="fa fa-long-arrow-right" aria-hidden="true"></i></Link></div>
</div></div>


</Slider>
</div>
</section>

















    </div>
  )
}

export default Metaverses
