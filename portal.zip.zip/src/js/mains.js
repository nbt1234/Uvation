$(document).ready(function() {
    ({
        init: function() {
            this.getOverlayLoad(),
            this.getSlick(),
            this.getSplit(),  
            this.getScrollto(),
            this.getTweenMax(),
            this.resize(); 
        }, 
 
        getTweenMax: function () {

            $(".play_nft").append($(".play_nft .split").clone());
            TweenMax.to($(".play_nft"), 15, {
                x: -500,  
                repeat: -1,  
                ease: Power0.easeNone, 
            });

            $(".maplop").append($(".maplop .split").clone());
            TweenMax.to($(".maplop"), 15, {
                x: -500, 
                repeat: -1, 
                ease: Power0.easeNone,
            });

            
            $(".platform-itm").append($(".platform-itm p").clone());
            TweenMax.to($(".platform-itm"), 15, {
                x: -500, 
                repeat: -1, 
                ease: Power0.easeNone,
            });

        },
        getScrollto: function () {
            $(".scrollto").click(function () {
                var t = $(this).attr("data-pos");
                if (void 0 === t) {
                    var i = $(this).attr("data-id");
                    $("#" + i).length && $("html,body").animate({
                        scrollTop: $("#" + i).offset().top
                    }, 500)
                } else "" != t && $("html,body").animate({
                    scrollTop: parseInt(t)
                }, 500);
                return !1
            }), $('a[href^="#"]').click(function () {
                var t = $(this).attr("href");
                if ($(t).length) return $("html,body").animate({
                    scrollTop: $(t).offset().top
                }, 500), !1
            })
        },

        getSplit: function() {

            $('.split').each(function( index ) {

                var allSplit = $(this);
                var wordList = $(this).text().split("");
                $(this).text(""); 
                $.each(wordList, function (idx, elem) {
 
                    allSplit.append('<span style=--i:'+idx+'>'+elem+'</span>');

                });
            });
            
        },
        getSlick: function() {

            var slick_roadmap = $('.slick-roadmap');
            var effect_controller = $('.effect-controller');

            slick_roadmap.slick({
                infinite: true, 
                slidesToScroll: 1,
                arrows: false ,
                variableWidth: true,
                responsive: [
                    {
                        breakpoint: 580,
                        settings: {
                            slidesToShow: 1,
                            slidesToScroll: 1,
                            variableWidth: false, 
                        }
                    }
                ]
            });

            slick_roadmap.on('beforeChange', function(event, slick, currentSlide, nextSlide){
                console.log('before');
            });

            slick_roadmap.on('afterChange', function(event, slick, currentSlide, nextSlide){
                console.log('after');

                effect_controller.removeClass('rotateLeft');
                effect_controller.removeClass('rotateRight');

            });

            slick_roadmap.parent().find('.prev').click(function () {
                slick_roadmap.slick('slickPrev');
                effect_controller.addClass('rotateLeft');
            });
 
            slick_roadmap.parent().find('.next').click(function () {
                slick_roadmap.slick('slickNext');
                effect_controller.addClass('rotateRight');
            });

            var slick_platform = $('.slick-platform');

            slick_platform.slick({
                infinite: true,
                slidesToShow: 1, 
                slidesToScroll: 1,
                dots: true,
                customPaging : function(slider, i) {
                    return '';
                },
                appendArrows: $('.slick-custom-arrows'),
                appendDots: $('.slick-custom-dots'),
                prevArrow: "<div class='arrow prev'></div>",
                nextArrow: "<div class='arrow next'></div>",
            });

            var slick_token = $('.slick-token');

            slick_token.slick({
                infinite: true,
                slidesToShow: 1, 
                slidesToScroll: 1,
                arrows: false,
            });
            
            slick_token.on('beforeChange', function(event, slick, currentSlide, nextSlide){
                $('.tokens-item').removeClass('active');
                $('.tokens-item').eq(nextSlide).addClass('active');
            });

            $('.tokens-item').click(function(){ 
                slick_token.slick('slickGoTo', $(this).attr('data-slide'));
            }) 

            $('.main-game-tokens').find('.prev').click(function () {
                slick_token.slick('slickPrev');
            });
   
            $('.main-game-tokens').find('.next').click(function () {
                slick_token.slick('slickNext');  
            }); 

        },
        getOverlayLoad: function() { 
            $("#overlay-load").fadeOut();
        },
        load: function() {
            
        },
        resize: function() {
            var t = this;
            // $(window).resize(function() {
            //     t.getRellax();  
            // })
        }
    }).init()
});