$(document).ready(function () {

    const main_banner = $(".main-banner");
    main_banner.on("mousemove", function (e) {
        var w = $(window).width();
        var h = $(window).height();
        var offsetX = 0.5 - e.pageX / w;
        var offsetY = 0.2 - e.pageY / h;
        $(".main-banner [data-offset]").each(function (i, el) {
            var offset = parseInt($(el).data("offset"));
            var translate =
                "translate3d(" +
                Math.round(offsetX * offset) +
                "px," +
                Math.round(offsetY * offset) +
                "px, 0px)";
            $(el).css({
                "-webkit-transform": translate,
                transform: translate,
                "moz-transform": translate,
            });
        });
    });

    const main_what_is = $(".main-what-is");
    main_what_is.on("mousemove", function (e) {
        var w = $(window).width();
        var h = $(window).height();
        var offsetX = 0.5 - e.pageX / w;
        var offsetY = 0.2 - e.pageY / h;
        $(".main-what-is [data-offset]").each(function (i, el) {
            var offset = parseInt($(el).data("offset"));
            var translate =
                "translate3d(" +
                Math.round(offsetX * offset) +
                "px," +
                Math.round(offsetY * offset) +
                "px, 0px)";
            $(el).css({
                "-webkit-transform": translate,
                transform: translate,
                "moz-transform": translate,
            });
        });
    });

    // const container2 = $(".main-token-predict");
    // container2.on("mousemove", function (e) {
    //     var w = $(window).width();
    //     var h = $(window).height();
    //     var offsetX = 0.5 - e.pageX / w;
    //     var offsetY = 0.2 - e.pageY / h;
    //     $(".main-token-predict [data-offset]").each(function (i, el) {
    //         var offset = parseInt($(el).data("offset"));
    //         var translate =
    //             "translate3d(" +
    //             Math.round(offsetX * offset) +
    //             "px," +
    //             Math.round(offsetY * offset) +
    //             "px, 0px)";
    //         $(el).css({
    //             "-webkit-transform": translate,
    //             transform: translate,
    //             "moz-transform": translate,
    //         });
    //     });
    // });

    // const token = $(".section-token");
    // token.on("mousemove", function (e) {
    //     var w = $(window).width();
    //     var h = $(window).height();
    //     var offsetX = 0.2 - e.pageX / w;
    //     var offsetY = 0.2 - e.pageY / h;
    //     $(".section-token [data-offset]").each(function (i, el) {
    //         var offset = parseInt($(el).data("offset"));
    //         var translate =
    //             "translate3d(" +
    //             Math.round(offsetX * offset) +
    //             "px," +
    //             Math.round(offsetY * offset) +
    //             "px, 0px)";
    //         $(el).css({
    //             "-webkit-transform": translate,
    //             transform: translate,
    //             "moz-transform": translate,
    //         });
    //     });
    // });
     
});
